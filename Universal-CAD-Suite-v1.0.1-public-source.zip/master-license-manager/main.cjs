'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {app,BrowserWindow,ipcMain,dialog}=require('electron');
const {MASTER_SCHEMA,decryptPrivateKey}=require('../license-core/master-key.cjs');
const {PRODUCT_ID}=require('../license-core/license-format.cjs');
const {parseEnrollmentCode,sealForHost}=require('../license-core/host-seal.cjs');
const {createSignedEntitlement,serializeEntitlement}=require('../license-core/entitlement-format.cjs');
const {SUITE_VERSION,ENGINE_VERSION,FEATURE_CATALOG,EDITION_PRESETS,resolveEdition}=require('../license-core/feature-catalog.cjs');
const {createOwnerLicense,serializeOwnerLicense}=require('../license-core/owner-license.cjs');
let win;
function keyStorePath(){return path.join(app.getPath('userData'),'issuer-key','master-key.enc.json');}
function readMasterDocument(){const p=keyStorePath();if(!fs.existsSync(p))throw new Error('Master Key is not installed.');let doc;try{doc=JSON.parse(fs.readFileSync(p,'utf8'));}catch{throw new Error('The installed Master Key is corrupted.');}if(!doc||doc.schema!==MASTER_SCHEMA)throw new Error('Unsupported Master Key format.');return doc;}
function createWindow(){win=new BrowserWindow({width:1180,height:940,minWidth:940,minHeight:760,show:false,backgroundColor:'#07111f',autoHideMenuBar:true,title:'Universal CAD Master License Manager',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,devTools:!app.isPackaged,spellcheck:false}});win.loadFile(path.join(__dirname,'ui','index.html'));win.once('ready-to-show',()=>win.show());}
ipcMain.handle('master:key-status',()=>({installed:fs.existsSync(keyStorePath())}));
ipcMain.handle('master:import-key',async()=>{const pick=await dialog.showOpenDialog(win,{title:'Import Universal CAD Master Key',properties:['openFile'],filters:[{name:'Encrypted Master Key',extensions:['json']}]});if(pick.canceled||!pick.filePaths[0])return{canceled:true};let doc;try{doc=JSON.parse(fs.readFileSync(pick.filePaths[0],'utf8'));}catch{throw new Error('Unable to read the Master Key file.');}if(!doc||doc.schema!==MASTER_SCHEMA)throw new Error('Unsupported Master Key file.');const target=keyStorePath();fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,JSON.stringify(doc),{encoding:'utf8',mode:0o600});return{canceled:false,installed:true};});

ipcMain.handle('master:remove-key', async () => {
  const target = keyStorePath();
  if (!fs.existsSync(target)) return { canceled:false, removed:false };
  const answer = await dialog.showMessageBox(win, {
    type:'warning', buttons:['Remove Key','Cancel'], defaultId:1, cancelId:1,
    title:'Remove Master Key',
    message:'Remove the Master Key from this computer?',
    detail:'This does not delete your external backup file.'
  });
  if (answer.response !== 0) return { canceled:true, removed:false };
  fs.unlinkSync(target);
  try { const dir=path.dirname(target); if (fs.existsSync(dir) && fs.readdirSync(dir).length===0) fs.rmdirSync(dir); } catch {}
  return { canceled:false, removed:true };
});

ipcMain.handle('master:catalog',()=>({suiteVersion:SUITE_VERSION,engineVersion:ENGINE_VERSION,features:FEATURE_CATALOG,editions:Object.values(EDITION_PRESETS).map(x=>({id:x.id,name:x.name,displayName:x.displayName,features:x.features}))}));
ipcMain.handle('master:generate',(_e,input)=>{const customerName=String(input?.customerName||'').trim();const customerId=String(input?.customerId||'').trim();const entitlementLabel=String(input?.entitlementLabel||'').trim();const seats=Number(input?.seats||0);const validFrom=String(input?.validFrom||'');const validUntil=String(input?.validUntil||'');const password=String(input?.masterPassword||'');if(!customerName)throw new Error('Enter a customer name.');if(!Number.isInteger(seats)||seats<1)throw new Error('Invalid seat count.');if(!/^\d{4}-\d{2}-\d{2}$/.test(validFrom)||!/^\d{4}-\d{2}-\d{2}$/.test(validUntil)||validUntil<validFrom)throw new Error('Invalid validity period.');const enrollment=parseEnrollmentCode(input?.enrollmentCode);const edition=resolveEdition(input?.editionId,input?.features,input?.productDisplayName);const masterPrivate=decryptPrivateKey(readMasterDocument(),password);const delegated=crypto.generateKeyPairSync('ed25519');const delegatedPrivatePem=delegated.privateKey.export({type:'pkcs8',format:'pem'});const delegatedPublicPem=delegated.publicKey.export({type:'spki',format:'pem'});const sealedIssuer=sealForHost(delegatedPrivatePem,enrollment.publicKeyPem);const payload={entitlementId:crypto.randomUUID(),product:PRODUCT_ID,suiteVersion:SUITE_VERSION,engineVersion:ENGINE_VERSION,customerName,customerId,entitlementLabel:entitlementLabel||`${edition.name} ${seats} Seats`,licenseHostId:enrollment.hostId,licenseHostKeyFingerprint:enrollment.fingerprint,seats,validFrom,validUntil,editionId:edition.id,editionName:edition.name,productDisplayName:edition.displayName,features:edition.features,delegatedPublicKeyPem:delegatedPublicPem,issuedAt:new Date().toISOString(),issuer:'Universal CAD Master License Manager',nonce:crypto.randomBytes(18).toString('base64url')};return createSignedEntitlement(payload,sealedIssuer,masterPrivate);});
ipcMain.handle('master:save',async(_e,doc)=>{const p=doc?.payload||{};const safe=String(p.customerName||'customer').replace(/[^\p{L}\p{N}_-]+/gu,'_');const out=await dialog.showSaveDialog(win,{title:'Save Universal CAD Entitlement',defaultPath:`UCAD-${safe}-${p.editionName||'Edition'}-${p.seats||1}Seats.ucadent`,filters:[{name:'Universal CAD Entitlement',extensions:['ucadent']}]});if(out.canceled||!out.filePath)return{canceled:true};fs.writeFileSync(out.filePath,serializeEntitlement(doc),{encoding:'utf8',mode:0o600});return{canceled:false,filePath:out.filePath};});

ipcMain.handle('master:generate-owner',(_e,input)=>{const ownerName=String(input?.ownerName||'Owner').trim()||'Owner';const validFrom=String(input?.validFrom||'');const validUntil=String(input?.validUntil||'');const password=String(input?.masterPassword||'');if(!/^\d{4}-\d{2}-\d{2}$/.test(validFrom)||!/^\d{4}-\d{2}-\d{2}$/.test(validUntil)||validUntil<validFrom)throw new Error('Invalid Owner Universal License validity period.');const masterPrivate=decryptPrivateKey(readMasterDocument(),password);return createOwnerLicense({licenseId:crypto.randomUUID(),ownerName,productDisplayName:'Universal CAD Studio Owner',editionName:'Owner Universal',validFrom,validUntil,suiteVersion:SUITE_VERSION,engineVersion:ENGINE_VERSION,issuedAt:new Date().toISOString(),issuer:'Universal CAD Master License Manager',nonce:crypto.randomBytes(18).toString('base64url')},masterPrivate);});
ipcMain.handle('master:save-owner',async(_e,doc)=>{const p=doc?.payload||{};const out=await dialog.showSaveDialog(win,{title:'Save Owner Universal License',defaultPath:`UCAD-OWNER-UNIVERSAL-${p.validUntil||'license'}.ucadlic`,filters:[{name:'Universal CAD Owner License',extensions:['ucadlic']}]});if(out.canceled||!out.filePath)return{canceled:true};fs.writeFileSync(out.filePath,serializeOwnerLicense(doc),{encoding:'utf8',mode:0o600});return{canceled:false,filePath:out.filePath};});

ipcMain.handle('master:info',()=>({version:app.getVersion(),suiteVersion:SUITE_VERSION,engineVersion:ENGINE_VERSION,ownerUniversalLicense:true}));
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
