'use strict';
const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');const ROOT=path.join(__dirname,'..');
const files=['desktop/activation.html','desktop/activation.js','customer-license-tool/ui/index.html','customer-license-tool/ui/app.js','customer-license-tool/main.cjs','customer-license-tool/recovery.cjs','customer-license-tool/host-identity.cjs','master-license-manager/ui/index.html','master-license-manager/ui/app.js','master-license-manager/main.cjs'];
for(const rel of files){const text=fs.readFileSync(path.join(ROOT,rel),'utf8');assert.ok(!/[\u0E00-\u0E7F]/.test(text),`${rel} must be English-only`);}
const machine=fs.readFileSync(path.join(ROOT,'desktop/machine-id.cjs'),'utf8');assert.match(machine,/COMMAND_TIMEOUT_MS = 2500/);assert.match(machine,/collectMachineIdentity/);
const service=fs.readFileSync(path.join(ROOT,'desktop/license-service.cjs'),'utf8');assert.match(service,/const identity = collectMachineIdentity\(\)/);assert.ok(!service.includes('computeMachineId();\n    this.legacyMachineId = computeLegacyMachineId()'));
const master=fs.readFileSync(path.join(ROOT,'master-license-manager/main.cjs'),'utf8');assert.match(master,/master:remove-key/);
console.log('v1.0.1 product UI/hardware compatibility tests: PASS');
