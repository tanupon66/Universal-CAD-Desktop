'use strict';

const crypto = require('node:crypto');
const os = require('node:os');
const { execFileSync } = require('node:child_process');

const COMMAND_TIMEOUT_MS = 2500;

function tryCommand(command, args, timeout = COMMAND_TIMEOUT_MS) {
  try {
    return String(execFileSync(command, args, {
      windowsHide: true,
      encoding: 'utf8',
      timeout,
      maxBuffer: 256 * 1024,
      stdio: ['ignore', 'pipe', 'ignore'],
    }) || '').trim();
  } catch { return ''; }
}

function normalizeHardwareValue(value) {
  const text = String(value || '').trim().toUpperCase().replace(/\s+/g, ' ');
  if (!text) return '';
  const compact = text.replace(/[\s-]/g, '');
  const blocked = new Set([
    'TOBEFILLEDBYOEM', 'DEFAULTSTRING', 'SYSTEMSERIALNUMBER', 'NONE', 'UNKNOWN',
    'NOTSPECIFIED', 'NOTAPPLICABLE', '0000000000000000', '00000000000000000000000000000000',
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF',
  ]);
  if (blocked.has(compact)) return '';
  return text;
}

function powershellJson(script) {
  const out = tryCommand('powershell.exe', [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
    `$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='SilentlyContinue'; ${script} | ConvertTo-Json -Compress`,
  ]);
  if (!out) return {};
  try { return JSON.parse(out); } catch { return {}; }
}

function windowsHardwareFacts() {
  // One bounded PowerShell process only. Older systems with slow/broken WMI are
  // allowed to time out and fall back instead of blocking application startup.
  const facts = powershellJson(`
    $csp = Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue;
    $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1;
    $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue | Select-Object -First 1;
    $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1;
    [PSCustomObject]@{
      systemUuid = $csp.UUID;
      baseboardSerial = $bb.SerialNumber;
      biosSerial = $bios.SerialNumber;
      processorId = $cpu.ProcessorId
    }
  `);
  const result = {
    systemUuid: normalizeHardwareValue(facts.systemUuid),
    baseboardSerial: normalizeHardwareValue(facts.baseboardSerial),
    biosSerial: normalizeHardwareValue(facts.biosSerial),
    processorId: normalizeHardwareValue(facts.processorId),
  };
  if (Object.values(result).filter(Boolean).length < 2) {
    const uuidOut = tryCommand('wmic.exe', ['csproduct', 'get', 'uuid', '/value'], 900);
    const boardOut = tryCommand('wmic.exe', ['baseboard', 'get', 'serialnumber', '/value'], 900);
    const uuid = uuidOut.match(/UUID=([^\r\n]+)/i);
    const board = boardOut.match(/SerialNumber=([^\r\n]+)/i);
    if (!result.systemUuid && uuid) result.systemUuid = normalizeHardwareValue(uuid[1]);
    if (!result.baseboardSerial && board) result.baseboardSerial = normalizeHardwareValue(board[1]);
  }
  return result;
}

function windowsMachineGuid() {
  const out = tryCommand('reg.exe', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'], 1200);
  const match = out.match(/MachineGuid\s+REG_\w+\s+([^\r\n]+)/i);
  return match ? normalizeHardwareValue(match[1]) : '';
}

function fallbackFacts() {
  const macs = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const item of list || []) {
      if (item && !item.internal && item.mac && item.mac !== '00:00:00:00:00:00') macs.push(item.mac.toLowerCase());
    }
  }
  return {
    hostname: normalizeHardwareValue(os.hostname()),
    arch: normalizeHardwareValue(os.arch()),
    platform: normalizeHardwareValue(os.platform()),
    macs: macs.sort(),
  };
}

function machineSeedFromFacts(facts, machineGuid = '') {
  const stable = [
    ['UUID', normalizeHardwareValue(facts?.systemUuid)],
    ['BOARD', normalizeHardwareValue(facts?.baseboardSerial)],
    ['BIOS', normalizeHardwareValue(facts?.biosSerial)],
    ['CPU', normalizeHardwareValue(facts?.processorId)],
  ].filter(([, value]) => value);
  if (stable.length >= 2) return `win-hwv2|${stable.map(([k, v]) => `${k}:${v}`).join('|')}`;
  if (stable.length === 1) {
    const guid = normalizeHardwareValue(machineGuid);
    if (guid) return `win-hwv2-fallback|${stable[0][0]}:${stable[0][1]}|GUID:${guid}`;
    return `win-hwv2-single|${stable[0][0]}:${stable[0][1]}`;
  }
  const guid = normalizeHardwareValue(machineGuid);
  if (guid) return `win-guid-fallback|GUID:${guid}`;
  const f = fallbackFacts();
  return `fallback|${f.platform}|${f.arch}|${f.hostname}|${f.macs.join(',')}`;
}

function legacySeedFromSnapshot(snapshot) {
  const guid = normalizeHardwareValue(snapshot?.machineGuid);
  const uuid = normalizeHardwareValue(snapshot?.facts?.systemUuid);
  return `win|${guid}|${uuid}`;
}

function formatMachineIdFromSeed(seed) {
  const hash = crypto.createHash('sha256').update(String(seed)).digest('hex').toUpperCase();
  const body = hash.slice(0, 24).match(/.{1,4}/g).join('-');
  return `UCAD-${body}`;
}

function collectMachineIdentity() {
  if (process.platform !== 'win32') {
    const f = fallbackFacts();
    const seed = `fallback|${f.platform}|${f.arch}|${f.hostname}|${f.macs.join(',')}`;
    const id = formatMachineIdFromSeed(seed);
    return { machineId:id, legacyMachineId:id, source:'fallback', facts:f, machineGuid:'' };
  }
  const startedAt = Date.now();
  const facts = windowsHardwareFacts();
  const machineGuid = windowsMachineGuid();
  const seed = machineSeedFromFacts(facts, machineGuid);
  const legacySeed = legacySeedFromSnapshot({ facts, machineGuid });
  return {
    machineId: formatMachineIdFromSeed(seed),
    legacyMachineId: formatMachineIdFromSeed(legacySeed),
    source: Object.values(facts).filter(Boolean).length >= 2 ? 'hardware' : (machineGuid ? 'fallback' : 'system'),
    elapsedMs: Date.now() - startedAt,
    facts,
    machineGuid,
  };
}

function machineSeed() {
  if (process.platform === 'win32') {
    const snapshot = collectMachineIdentity();
    return machineSeedFromFacts(snapshot.facts, snapshot.machineGuid);
  }
  const f = fallbackFacts();
  return `fallback|${f.platform}|${f.arch}|${f.hostname}|${f.macs.join(',')}`;
}
function legacyWindowsSeed() { const s=collectMachineIdentity(); return legacySeedFromSnapshot(s); }
function computeMachineId() { return collectMachineIdentity().machineId; }
function computeLegacyMachineId() { return collectMachineIdentity().legacyMachineId; }

module.exports = {
  COMMAND_TIMEOUT_MS,
  computeMachineId,
  machineSeed,
  machineSeedFromFacts,
  formatMachineIdFromSeed,
  windowsHardwareFacts,
  normalizeHardwareValue,
  computeLegacyMachineId,
  legacyWindowsSeed,
  legacySeedFromSnapshot,
  collectMachineIdentity,
};
