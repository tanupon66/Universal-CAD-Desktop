# Repository bootstrap

Target repository: `tanupon66/Universal-CAD-Desktop`

Visibility: **Private**

Initial release tag: `desktop-v0.26.0`

The one-click publisher `PUBLISH-NEW-PRIVATE-REPO.cmd` will:

1. Verify/install GitHub CLI and Git when needed.
2. Reuse the signed-in GitHub account or start the normal browser sign-in flow.
3. Refuse to overwrite an existing repository with the same name.
4. Create a private GitHub repository.
5. Push this reviewed source tree.
6. Create and push `desktop-v0.26.0`.
7. Trigger `.github/workflows/build-windows.yml`.
8. Open the Actions page.

The workflow runs license tests and the original 52-script PWA regression suite, builds both NSIS installers, calculates SHA-256 checksums, uploads an Actions artifact, and creates a GitHub Release for version tags.
