# Universal CAD Studio Desktop v0.26.0

รุ่นนี้ห่อ Universal CAD Studio PWA v0.25.2 เดิมด้วย Electron โดยไม่รื้อ CAD engine เดิม และเพิ่ม License Gate ที่ทำงานใน Electron Main Process

Desktop เปิด PWA ผ่าน secure local origin `ucad://app/` เพื่อให้ ES Modules, IndexedDB และ local project storage ใช้ origin คงที่ โดย CAD data ยังอยู่ในเครื่อง

## โครงสร้าง License

- โปรแกรมลูกค้าเก็บเฉพาะ `desktop/public-key.pem` (Ed25519 public key)
- License Manager เก็บ private signing key แบบ AES-256-GCM + scrypt ใน `license-manager/issuer/master-key.enc.json`
- Private key จะถอดได้เฉพาะเมื่อใส่ Master Password ที่ถูกต้อง
- License ระบุ Customer, Customer ID, Computer Label, Machine ID, Valid From, Valid Until, License ID และ nonce
- โปรแกรมลูกค้าตรวจลายเซ็น, Machine ID, วันเริ่ม/สิ้นสุด และการย้อนเวลาของ system clock
- หลัง Activate สำเร็จ ตัว License ถูกเก็บด้วย Electron `safeStorage` ซึ่งบน Windows ใช้ OS-backed protection; ไฟล์ `.ucadlic` ต้นทางจะถูก `unlink` ทันทีเมื่อทำได้
- Private/Master signing key ไม่อยู่ใน customer build

## วิธีใช้งานจริง

1. ติดตั้ง `Universal CAD Studio` ที่เครื่องลูกค้า
2. เปิดโปรแกรม จะเห็น Machine ID เช่น `UCAD-....`
3. ลูกค้าส่ง Machine ID ให้ผู้ดูแล
4. ผู้ดูแลเปิด `Universal CAD License Manager`, กรอก Master Password, ลูกค้า, ชื่อเครื่อง, Machine ID และช่วงวันที่
5. บันทึกไฟล์ `.ucadlic` แล้วส่งให้ลูกค้า
6. ลูกค้าเลือกไฟล์ `.ucadlic` ในหน้า Activation
7. เมื่อผ่านการตรวจ โปรแกรมเก็บ License ไว้ใน Windows ของเครื่องนั้นและลบไฟล์ต้นทางที่เลือก จากนั้นเข้า CAD Studio

## ข้อจำกัดที่ต้องทราบ

Offline licensing ไม่สามารถพิสูจน์แบบ 100% ว่าไฟล์ License ไม่เคยถูกสำรองก่อน Activate ได้ แต่ License นี้ผูกกับ Machine ID ตั้งแต่ตอนออก จึงนำสำเนาไปใช้กับคอมเครื่องอื่นไม่ได้อยู่แล้ว หากต้องการ one-time activation แบบมีทะเบียนใช้แล้ว/ยังไม่ใช้จริง ๆ จำเป็นต้องมี activation ledger บน server เช่น Cloudflare Worker/D1.

Clock rollback ตรวจจากเวลาที่โปรแกรมเคยเปิดล่าสุดและจะบล็อกเมื่อระบบย้อนเวลามากกว่าค่า tolerance แต่การป้องกันการแก้เวลาแบบเด็ดขาดโดยไม่ใช้ server/TPM ไม่มีทางรับประกันได้ 100%.

## Build บน Windows

ทางง่ายที่สุด: ดับเบิลคลิก `BUILD-WINDOWS.cmd` แล้วสคริปต์จะติดตั้ง dependency, รันทดสอบ และสร้าง installer ทั้งสองตัว

หรือใช้คำสั่ง:

```powershell
npm install
npm run test
npm run build:windows
```

ผลลัพธ์อยู่ใน:

- `release/customer/Universal-CAD-Studio-Setup-0.26.0-x64.exe`
- `release/license-manager/Universal-CAD-License-Manager-Setup-0.26.0-x64.exe`

หรือใช้ GitHub Actions: Actions → `Build Windows EXE` → Run workflow → ดาวน์โหลด artifact `Universal-CAD-Windows-EXE`.

## Security deployment

ถ้ายังเผยแพร่ PWA เดิมแบบสาธารณะ ผู้ใช้ยังสามารถเข้าเวอร์ชันเว็บที่ไม่มี Desktop License Gate ได้ ดังนั้นรุ่นเชิงพาณิชย์ควรแจกผ่าน Desktop installer หรือเพิ่มระบบสิทธิ์แยกให้ PWA ด้วย


- ห้ามส่ง License Manager, master-key.enc.json หรือ Master Password ให้ลูกค้า
- Customer installer มี public key เท่านั้น จึงตรวจ License ได้แต่สร้าง License ใหม่ไม่ได้
- ควร Code Sign `.exe` ในรุ่น production เพื่อป้องกัน SmartScreen และช่วยตรวจการแก้ไฟล์ installer
- ถ้าต้องการเปลี่ยน Master signing identity ให้รัน `node scripts/create-master-material.cjs <NEW_MASTER_PASSWORD>` แล้ว rebuild ทั้ง customer app และ License Manager เพราะ public key จะเปลี่ยนตาม
