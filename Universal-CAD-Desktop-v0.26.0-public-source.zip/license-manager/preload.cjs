'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('issuerApi', {
  generate: (form) => ipcRenderer.invoke('issuer:generate', form),
  save: (license) => ipcRenderer.invoke('issuer:save', license),
  appInfo: () => ipcRenderer.invoke('issuer:info'),
  keyStatus: () => ipcRenderer.invoke('issuer:key-status'),
  importKey: () => ipcRenderer.invoke('issuer:import-key'),
});
