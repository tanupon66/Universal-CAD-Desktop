'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const { MASTER_SCHEMA, decryptPrivateKey } = require('../license-core/master-key.cjs');
const { createSignedLicense, serializeLicense, PRODUCT_ID, normalizeMachineId } = require('../license-core/license-format.cjs');

let win;
function keyStorePath(){ return path.join(app.getPath('userData'), 'issuer-key', 'master-key.enc.json'); }

function readMasterDocument(){
  const p = keyStorePath();
  if (!fs.existsSync(p)) throw new Error('ยังไม่ได้ติดตั้ง Master Key กรุณากด Import Master Key ก่อน');
  let doc;
  try { doc = JSON.parse(fs.readFileSync(p, 'utf8')); }
  catch { throw new Error('Master Key ที่บันทึกไว้เสียหาย กรุณา Import ใหม่'); }
  if (!doc || doc.schema !== MASTER_SCHEMA) throw new Error('รูปแบบ Master Key ไม่รองรับ');
  return doc;
}

function createWindow(){
  win = new BrowserWindow({width:900,height:900,minWidth:760,minHeight:720,show:false,backgroundColor:'#07111f',autoHideMenuBar:true,title:'Universal CAD License Manager',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,devTools:!app.isPackaged,spellcheck:false}});
  win.loadFile(path.join(__dirname,'ui','index.html')); win.once('ready-to-show',()=>win.show());
}

function cleanForm(form){
  return {
    customerName:String(form.customerName||'').trim(), customerId:String(form.customerId||'').trim(), computerLabel:String(form.computerLabel||'').trim(), machineId:normalizeMachineId(form.machineId), validFrom:String(form.validFrom||''), validUntil:String(form.validUntil||''), masterPassword:String(form.masterPassword||'')
  };
}

ipcMain.handle('issuer:key-status', () => ({ installed: fs.existsSync(keyStorePath()) }));
ipcMain.handle('issuer:import-key', async () => {
  const pick = await dialog.showOpenDialog(win, { title:'Import Universal CAD Master Key', properties:['openFile'], filters:[{name:'Universal CAD Encrypted Master Key',extensions:['json']}] });
  if (pick.canceled || !pick.filePaths[0]) return { canceled:true };
  let doc;
  try { doc = JSON.parse(fs.readFileSync(pick.filePaths[0], 'utf8')); }
  catch { throw new Error('ไฟล์ Master Key อ่านไม่ได้หรือไม่ใช่ JSON ที่ถูกต้อง'); }
  if (!doc || doc.schema !== MASTER_SCHEMA) throw new Error('ไฟล์นี้ไม่ใช่ Universal CAD Master Key ที่รองรับ');
  const target = keyStorePath();
  fs.mkdirSync(path.dirname(target), { recursive:true });
  const temp = `${target}.tmp-${process.pid}`;
  fs.writeFileSync(temp, JSON.stringify(doc), { encoding:'utf8', mode:0o600 });
  fs.renameSync(temp, target);
  return { canceled:false, installed:true };
});

ipcMain.handle('issuer:generate', (_event, input) => {
  const form=cleanForm(input);
  if(!form.customerName) throw new Error('กรุณากรอกชื่อลูกค้า');
  if(!form.machineId.startsWith('UCAD-')) throw new Error('Machine ID ไม่ถูกต้อง');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(form.validFrom)||!/^\d{4}-\d{2}-\d{2}$/.test(form.validUntil)) throw new Error('กรุณากำหนดวันที่เริ่มและสิ้นสุด');
  if(form.validUntil<form.validFrom) throw new Error('วันสิ้นสุดต้องไม่น้อยกว่าวันเริ่ม');
  const masterDoc=readMasterDocument();
  const privateKey=decryptPrivateKey(masterDoc,form.masterPassword);
  try{
    const payload={licenseId:crypto.randomUUID(),product:PRODUCT_ID,customerName:form.customerName,customerId:form.customerId,computerLabel:form.computerLabel,machineId:form.machineId,validFrom:form.validFrom,validUntil:form.validUntil,issuedAt:new Date().toISOString(),issuer:'Universal CAD License Manager',features:['all'],nonce:crypto.randomBytes(18).toString('base64url')};
    return createSignedLicense(payload,privateKey);
  } finally { form.masterPassword=''; }
});

ipcMain.handle('issuer:save', async (_event, license) => {
  const defaultName=`UCAD-${String(license?.payload?.customerName||'customer').replace(/[^A-Za-z0-9ก-๙_-]+/g,'_')}-${String(license?.payload?.machineId||'machine').slice(-9)}.ucadlic`;
  const out=await dialog.showSaveDialog(win,{title:'Save Universal CAD license',defaultPath:defaultName,filters:[{name:'Universal CAD License',extensions:['ucadlic']}]});
  if(out.canceled||!out.filePath)return {canceled:true};
  fs.writeFileSync(out.filePath,serializeLicense(license),{encoding:'utf8',mode:0o600});
  return {canceled:false,filePath:out.filePath};
});
ipcMain.handle('issuer:info',()=>({version:app.getVersion()}));
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
