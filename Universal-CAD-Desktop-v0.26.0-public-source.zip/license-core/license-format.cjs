'use strict';

const crypto = require('node:crypto');

const LICENSE_SCHEMA = 'ucad-license-v1';
const PRODUCT_ID = 'universal-cad-studio-desktop';
const ALGORITHM = 'Ed25519';

function stablePayload(payload) {
  const normalized = {
    schemaVersion: 1,
    licenseId: String(payload.licenseId || ''),
    product: String(payload.product || PRODUCT_ID),
    customerName: String(payload.customerName || '').trim(),
    customerId: String(payload.customerId || '').trim(),
    computerLabel: String(payload.computerLabel || '').trim(),
    machineId: normalizeMachineId(payload.machineId),
    validFrom: String(payload.validFrom || ''),
    validUntil: String(payload.validUntil || ''),
    issuedAt: String(payload.issuedAt || ''),
    issuer: String(payload.issuer || 'Universal CAD License Manager'),
    features: Array.isArray(payload.features) ? [...payload.features].map(String).sort() : ['all'],
    nonce: String(payload.nonce || ''),
  };
  return Buffer.from(JSON.stringify(normalized), 'utf8');
}

function normalizeMachineId(value) {
  return String(value || '').trim().toUpperCase().replace(/\s+/g, '');
}

function isIsoDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}

function todayLocal(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function validatePayloadShape(payload) {
  const errors = [];
  if (!payload || typeof payload !== 'object') return ['License payload is missing.'];
  if (!payload.licenseId) errors.push('licenseId is required.');
  if (payload.product !== PRODUCT_ID) errors.push('Product does not match this application.');
  if (!String(payload.customerName || '').trim()) errors.push('Customer name is required.');
  if (!normalizeMachineId(payload.machineId)) errors.push('Machine ID is required.');
  if (!isIsoDate(payload.validFrom)) errors.push('validFrom must be YYYY-MM-DD.');
  if (!isIsoDate(payload.validUntil)) errors.push('validUntil must be YYYY-MM-DD.');
  if (isIsoDate(payload.validFrom) && isIsoDate(payload.validUntil) && payload.validUntil < payload.validFrom) errors.push('validUntil must not be before validFrom.');
  if (!payload.issuedAt || Number.isNaN(Date.parse(payload.issuedAt))) errors.push('issuedAt is invalid.');
  if (!payload.nonce || String(payload.nonce).length < 16) errors.push('nonce is invalid.');
  return errors;
}

function createSignedLicense(payload, privateKeyPem) {
  const shaped = JSON.parse(stablePayload(payload).toString('utf8'));
  const errors = validatePayloadShape(shaped);
  if (errors.length) throw new Error(errors.join(' '));
  const signature = crypto.sign(null, stablePayload(shaped), privateKeyPem).toString('base64');
  return {
    schema: LICENSE_SCHEMA,
    algorithm: ALGORITHM,
    payload: shaped,
    signature,
  };
}

function verifySignedLicense(document, publicKeyPem) {
  if (!document || typeof document !== 'object') return { ok: false, code: 'FORMAT', message: 'License file is not valid JSON.' };
  if (document.schema !== LICENSE_SCHEMA || document.algorithm !== ALGORITHM) return { ok: false, code: 'FORMAT', message: 'License format is not supported.' };
  const errors = validatePayloadShape(document.payload);
  if (errors.length) return { ok: false, code: 'PAYLOAD', message: errors.join(' ') };
  let signature;
  try { signature = Buffer.from(String(document.signature || ''), 'base64'); } catch { return { ok: false, code: 'SIGNATURE', message: 'License signature is invalid.' }; }
  const valid = crypto.verify(null, stablePayload(document.payload), publicKeyPem, signature);
  if (!valid) return { ok: false, code: 'SIGNATURE', message: 'License signature verification failed.' };
  return { ok: true, payload: document.payload };
}

function evaluateLicense(document, publicKeyPem, machineId, options = {}) {
  const verified = verifySignedLicense(document, publicKeyPem);
  if (!verified.ok) return verified;
  const payload = verified.payload;
  const currentMachine = normalizeMachineId(machineId);
  if (normalizeMachineId(payload.machineId) !== currentMachine) {
    return { ok: false, code: 'MACHINE_MISMATCH', message: 'This license was issued for a different computer.', payload };
  }
  const now = options.now instanceof Date ? options.now : new Date(options.now || Date.now());
  const today = todayLocal(now);
  if (today < payload.validFrom) return { ok: false, code: 'NOT_YET_VALID', message: `License starts on ${payload.validFrom}.`, payload };
  if (today > payload.validUntil) return { ok: false, code: 'EXPIRED', message: `License expired on ${payload.validUntil}.`, payload };
  if (options.lastSeenUtcMs && Number.isFinite(Number(options.lastSeenUtcMs))) {
    const toleranceMs = Number(options.clockRollbackToleranceMs ?? 5 * 60 * 1000);
    if (now.getTime() + toleranceMs < Number(options.lastSeenUtcMs)) {
      return { ok: false, code: 'CLOCK_ROLLBACK', message: 'System clock appears to have been moved backwards.', payload };
    }
  }
  return { ok: true, code: 'VALID', payload, today };
}

function parseLicenseText(text) {
  const raw = String(text || '').trim();
  if (!raw) throw new Error('License file is empty.');
  const doc = JSON.parse(raw);
  return doc;
}

function serializeLicense(document) {
  return `${JSON.stringify(document, null, 2)}\n`;
}

module.exports = {
  LICENSE_SCHEMA,
  PRODUCT_ID,
  ALGORITHM,
  normalizeMachineId,
  todayLocal,
  validatePayloadShape,
  createSignedLicense,
  verifySignedLicense,
  evaluateLicense,
  parseLicenseText,
  serializeLicense,
};
