import assert from 'node:assert/strict';
import {
  detectLandGrid,
  defaultGridLabels,
  buildGridRenamePlan,
  applyGridRenamePlan,
  buildSequentialLandLabels,
  buildGridMappingPlan,
  buildGeneratedLandMapPlan,
} from '../land-grid-mapper.js';

const lands = [];
let id = 1;
for (let row = 0; row < 3; row += 1) {
  for (let col = 0; col < 4; col += 1) {
    lands.push({ componentId: '1', globalId: id++, cadName: `OLD${id}`, left: col * 2, top: 10 - row * 2, width: 1, length: 1 });
  }
}
const component = { id: '1', name: 'U1', lands };
const grid = detectLandGrid(component);
assert.equal(grid.rowCount, 3);
assert.equal(grid.columnCount, 4);
assert.equal(grid.missingCount, 0);
assert.equal(grid.collisions.length, 0);
const defaults = defaultGridLabels(grid);
assert.deepEqual(defaults.rows, ['A', 'B', 'C']);
assert.deepEqual(defaults.columns, ['1', '2', '3', '4']);
const plan = buildGridRenamePlan(grid, { rowLabels: defaults.rows, columnLabels: defaults.columns });
assert.equal(plan.duplicates.length, 0);
applyGridRenamePlan(plan);
assert.deepEqual(grid.matrix[0].map((land) => land.cadName), ['A1', 'A2', 'A3', 'A4']);
assert.deepEqual(grid.matrix[2].map((land) => land.cadName), ['C1', 'C2', 'C3', 'C4']);
const columnEdit = buildGridRenamePlan(grid, { rowLabels: ['A', 'B', 'C'], columnLabels: ['01', '02', '03', '04'], separator: '-' });
assert.equal(columnEdit.plan.find((item) => item.physicalRow === 1 && item.physicalColumn === 2).nextName, 'B-03');
const sequence = buildSequentialLandLabels(grid, { descending: true });
assert.equal(sequence.get(grid.matrix[0][0]), 12);
assert.equal(sequence.get(grid.matrix[2][3]), 1);
const duplicate = buildGridRenamePlan(grid, { rowLabels: ['', '', ''], columnLabels: ['1', '2', '3', '4'] });
assert(duplicate.duplicates.length > 0);
assert.throws(() => applyGridRenamePlan(duplicate), /ซ้ำหรือว่าง/);

// Sparse checkerboard rows previously produced B4, B6, B8... because empty
// physical columns consumed the coordinate number. Compact mode must number only
// occupied lands, while physical mode remains available for users who need it.
const sparseLands = [
  { componentId: '2', globalId: 101, cadName: 'OLD-A', left: 0, top: 10, width: 1, length: 1 },
  { componentId: '2', globalId: 102, cadName: 'OLD-B4', left: 3, top: 8, width: 1, length: 1 },
  { componentId: '2', globalId: 103, cadName: 'OLD-B6', left: 5, top: 8, width: 1, length: 1 },
  { componentId: '2', globalId: 104, cadName: 'OLD-B8', left: 7, top: 8, width: 1, length: 1 },
];
const sparseGrid = detectLandGrid({ id: '2', name: 'U2', lands: sparseLands }, { xTolerance: 0.1, yTolerance: 0.1 });
const sparseDefaults = defaultGridLabels(sparseGrid);
const physicalPlan = buildGridRenamePlan(sparseGrid, {
  namingMode: 'coordinate-physical', rowLabels: sparseDefaults.rows, columnLabels: sparseDefaults.columns,
});
const physicalSecondRow = physicalPlan.plan.filter((item) => item.physicalRow === 1).map((item) => item.nextName);
assert.deepEqual(physicalSecondRow, ['B2', 'B3', 'B4']);
const compactPlan = buildGridRenamePlan(sparseGrid, {
  namingMode: 'coordinate-compact', rowLabels: sparseDefaults.rows, columnStart: 4,
});
const compactSecondRow = compactPlan.plan.filter((item) => item.physicalRow === 1).map((item) => item.nextName);
assert.deepEqual(compactSecondRow, ['B4', 'B5', 'B6'], 'compact mode must not skip B5 because of an empty physical cell');

const landSequencePlan = buildGridRenamePlan(sparseGrid, {
  namingMode: 'sequence', sequencePrefix: 'LAND ', start: 1, step: 1, order: 'row-major',
});
assert.deepEqual(landSequencePlan.plan.map((item) => item.nextName), ['LAND 1', 'LAND 2', 'LAND 3', 'LAND 4']);
const numberOnlyPlan = buildGridRenamePlan(sparseGrid, {
  namingMode: 'number', start: 1, step: 1, padding: 3,
});
assert.deepEqual(numberOnlyPlan.plan.map((item) => item.nextName), ['001', '002', '003', '004']);

// Grid Map is mapping-only: empty cells do not consume a source record and a
// confirmed/manual mapping remains reserved instead of being overwritten.
const sources = [
  { sourceRow: 1, rawLandId: 'R1', componentId: '2', globalId: 101, mapped: true, manual: true, verified: true, userConfirmation: true },
  { sourceRow: 2, rawLandId: 'R2', componentId: '2', globalId: null, mapped: false },
  { sourceRow: 3, rawLandId: 'R3', componentId: '2', globalId: null, mapped: false },
];
const mappingPlan = buildGridMappingPlan(sparseGrid, sources, { preserveConfirmed: true, order: 'row-major' });
assert.equal(mappingPlan.protectedCount, 1);
assert.equal(mappingPlan.assignments.length, 2);
assert.deepEqual(mappingPlan.assignments.map((item) => item.land.globalId), [102, 103]);
assert.deepEqual(sparseLands.map((land) => land.cadName), ['OLD-A', 'OLD-B4', 'OLD-B6', 'OLD-B8'], 'Grid Map must never rename CAD lands');

const textIdGrid = detectLandGrid({ id: 'TXT', lands: [
  { componentId: 'TXT', globalId: 'PAD-A', cadName: 'A', left: 0, top: 0, width: 1, length: 1 },
] });
const textIdPlan = buildGridMappingPlan(textIdGrid, [{ sourceRow: 1, componentId: 'TXT', globalId: 'PAD-A', mapped: true }]);
assert.equal(textIdPlan.assignments[0].changed, false, 'alphanumeric target IDs must compare without numeric coercion');

// Regression fixture sized like the reported 6,807-land sparse BGA. Every row
// has gaps, so a physical-column counter would skip names. Sequence mode must
// still produce a continuous LAND 1..LAND 6807 list without modifying geometry.
const largeSparseLands = [];
let largeId = 1;
for (let row = 0; row < 152; row += 1) {
  const count = 44 + (row < 119 ? 1 : 0); // 6,807 total
  for (let index = 0; index < count; index += 1) {
    const column = Math.round(index * 102 / Math.max(1, count - 1));
    largeSparseLands.push({
      componentId: 'large', globalId: largeId, cadName: `OLD-${largeId++}`,
      left: column, top: 200 - row, width: 0.4, length: 0.4,
    });
  }
}
assert.equal(largeSparseLands.length, 6807);
const largeGrid = detectLandGrid({ id: 'large', name: 'U1_2', lands: largeSparseLands }, { xTolerance: 0.1, yTolerance: 0.1 });
assert.equal(largeGrid.rowCount, 152);
assert.equal(largeGrid.landCount, 6807);
assert(largeGrid.missingCount > 0);
const largeSequence = buildGridRenamePlan(largeGrid, { namingMode: 'sequence', sequencePrefix: 'LAND ', start: 1 });
assert.equal(largeSequence.plan[0].nextName, 'LAND 1');
assert.equal(largeSequence.plan.at(-1).nextName, 'LAND 6807');
assert.equal(new Set(largeSequence.plan.map((item) => item.nextName)).size, 6807);


// Grid/Land Map v0.24 generates a NEW alias and maps it to the unchanged CAD
// Land name. Every start/direction/order setting must be deterministic.
const generatedGrid = buildGeneratedLandMapPlan(grid, {
  namingMode: 'grid', gapMode: 'compact', rowStart: 'C', columnStart: 5, columnStep: 2,
  prefix: 'P-', separator: '-', suffix: '-T', reverseRows: false, reverseColumns: false,
});
assert.equal(generatedGrid.plan[0].newName, 'P-C-5-T');
assert.equal(generatedGrid.plan[1].newName, 'P-C-7-T');
assert.equal(generatedGrid.plan[4].newName, 'P-D-5-T');
assert.equal(generatedGrid.plan[0].cadName, 'A1', 'generated alias must map to the existing CAD name');
assert.equal(grid.matrix[0][0].cadName, 'A1', 'building a Grid/Land plan must not rename CAD');
const reversedGrid = buildGeneratedLandMapPlan(grid, {
  namingMode: 'grid', gapMode: 'physical', rowStart: 'A', columnStart: 1,
  order: 'column-major', reverseRows: true, reverseColumns: true,
});
assert.equal(reversedGrid.plan[0].newName, 'A1');
assert.equal(reversedGrid.plan[0].land, grid.matrix[2][3], 'A1 must start at the selected bottom-right corner');
assert.equal(reversedGrid.plan[1].newName, 'B1');
assert.equal(reversedGrid.plan[1].land, grid.matrix[1][3], 'column-major must continue upward/downward by configured row direction');

const generatedLandSequence = buildGeneratedLandMapPlan(grid, {
  namingMode: 'sequence', prefix: 'LAND ', start: 10, step: 5, padding: 3,
  order: 'column-major', reverseRows: true, reverseColumns: true,
});
assert.equal(generatedLandSequence.plan[0].newName, 'LAND 010');
assert.equal(generatedLandSequence.plan[1].newName, 'LAND 015');
assert.equal(generatedLandSequence.plan.at(-1).newName, 'LAND 065');

const overrideKey = generatedLandSequence.plan[0].landKey;
const withOverride = buildGeneratedLandMapPlan(grid, {
  namingMode: 'sequence', prefix: 'LAND ', start: 10, step: 5, padding: 3,
  order: 'column-major', reverseRows: true, reverseColumns: true,
  manualOverrides: new Map([[overrideKey, 'SPECIAL-01']]),
  existingAssignments: generatedLandSequence.plan.map((item) => ({ landKey: item.landKey, newName: item.newName })),
});
assert.equal(withOverride.plan[0].newName, 'SPECIAL-01');
assert.equal(withOverride.manualCount, 1);
assert.equal(withOverride.changedCount, 1);
assert.equal(withOverride.duplicates.length, 0);

console.log('Land grid detection, generated alias mapping, configurable sequence and CAD-name preservation passed');
