import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const [html,app,sw,manifestText,pkgText]=await Promise.all([
  readFile(new URL('index.html',root),'utf8'),readFile(new URL('app.js',root),'utf8'),readFile(new URL('sw.js',root),'utf8'),readFile(new URL('manifest.webmanifest',root),'utf8'),readFile(new URL('package.json',root),'utf8')
]);
const manifest=JSON.parse(manifestText), pkg=JSON.parse(pkgText);
for(const id of [
  'cadEditorGridMapButton','cadEditorGridMapFooterButton','landGridOverlay','landGridExportExcelButton',
  'landGridNamingMode','landGridGapMode','landGridPrefix','landGridSuffix','landGridRowStart',
  'landGridColumnStart','landGridColumnStep','landGridStart','landGridStep','landGridPadding',
  'landGridManualName','landGridApplyManualButton','landGridClearManualButton',
]) assert(html.includes(`id="${id}"`),`missing ${id}`);
for(const removed of ['landGridSourceDirection','landGridPreserveConfirmed','cadEditorLandMapButton','landMapOverlay','landMapExportPptxButton']) assert(!html.includes(`id="${removed}"`),`obsolete ${removed}`);
assert(html.includes('กำหนดชื่อใหม่และ Mapping กับ CAD Land'));
assert(html.includes('LAND 1, LAND 2, LAND 3'));
assert(!html.includes('PowerPoint'));
assert(app.includes('buildGeneratedLandMapPlan'));
assert(app.includes("'xlsx-grid-land-map'"));
assert(app.includes('gridLandMappings'));
assert(app.includes('ไม่ Rename CAD'));
await stat(new URL('../grid-map-excel.js',import.meta.url));
assert.equal(pkg.version,'0.25.2');
assert.equal(manifest.version,'0.25.2');
assert(sw.includes("const APP_VERSION = '0.25.2'"));
console.log('v0.24 configurable Grid/Land alias mapping and Excel-only export static checks passed');
