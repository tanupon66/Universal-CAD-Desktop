import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const [html, app, css] = await Promise.all([
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../styles.css', import.meta.url), 'utf8'),
]);

assert.equal((html.match(/id="cadEditorApplyButton"/g) || []).length, 1, 'CAD Editor must have one Apply button');
assert(!html.includes('id="cadStudioMappingButton"'), 'header Apply → Mapping button must be removed');
assert(!html.includes('data-cad-command="apply"'), 'File menu must not duplicate Apply');
for (const id of ['cadEditorConfirmOverlay','cadEditorConfirmYes','cadEditorConfirmNo','cadEditorBusyOverlay','cadEditorBusyProgress','cadEditorBusyCancelButton','cadEditorBusyCloseButton']) {
  assert(html.includes(`id="${id}"`), `missing ${id}`);
}
assert(app.includes("showCadEditorConfirm('apply')"), 'Apply confirmation flow missing');
assert(app.includes("showCadEditorConfirm('discard'"), 'discard confirmation flow missing');
assert(app.includes("document.querySelectorAll('[data-cad-menu-panel]:not(.hidden)').length"), 'Escape menu-close guard missing');
assert(app.includes('CAD_EDITOR_LIGHT_SELECTION_LIMIT'), 'large-selection lightweight mode missing');
assert(app.includes('runCadEditorTask('), 'busy-safe task runner missing');
assert(html.includes('Yes - ยืนยัน'), 'confirmation button must be named Yes - ยืนยัน');
assert(app.includes('declineCadEditorChoice'), 'animated No action missing');
assert(app.includes('cancelCadEditorTask'), 'cancellable busy task missing');
assert(app.includes('cadEditorModelToDataAsync'), 'chunked Apply conversion missing');
assert(css.includes('@keyframes cadConfirmIn'), 'confirmation entry animation missing');
assert(css.includes('@keyframes cadSpin'), 'busy spinner animation missing');
assert(css.includes('@keyframes cadConfirmReject'), 'No/reject animation missing');

const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]);
assert.equal(new Set(ids).size, ids.length, 'duplicate HTML IDs found');

const editor = html.split('<div id="cadEditorOverlay"', 2)[1].split('<div id="histogramOverlay"', 1)[0];
const buttonIds = [...editor.matchAll(/<button[^>]+id="([^"]+)"/g)].map((match) => match[1]);
for (const id of buttonIds) {
  assert(app.includes(`${id}.addEventListener`) || app.includes(`${id}?.addEventListener`), `CAD button has no event handler: ${id}`);
}

assert(app.includes('cadDataTopologySignature'), 'topology-aware Mapping rebuild missing');
assert(app.includes('prepareMappingForCadData'), 'revision-aware Mapping preparation missing');
assert(app.includes("const landMode = state.cadEditor.visual.mode === 'land';"), 'Land-mode safety guards missing');
assert(app.includes('if (landMode && !lands.length) return false;'), 'Arrow nudge must not move a Component from empty Land selection');
assert(html.includes('id="cadEditorSplitLandButton"'), 'Split Land tool missing');
assert(html.includes('data-cad-action="split-lands"'), 'Split Land selection action missing');

console.log('single Apply, confirmation, busy-state, Land safety and CAD control audit passed');

assert(!app.includes('window.confirm('), 'browser confirm must not be used');
assert(app.includes('CAD-APPLY-ROLLBACK'), 'atomic Apply rollback code missing');
assert(app.includes('prepareMappingForCadData(nextData'), 'Mapping must be prepared before Apply commit');
assert(!app.includes('updateArchiveXml(file, editedText)'), 'Apply must not mutate immutable archive source');
