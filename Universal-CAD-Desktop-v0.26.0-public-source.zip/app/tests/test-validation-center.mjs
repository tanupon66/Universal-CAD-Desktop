import assert from 'node:assert/strict';
import { normalizeLegacyCad } from '../universal-cad-model.js';
import { exportPreflight, overrideValidationIssue, validateUniversalCad } from '../validation-center.js';

const legacy = { board: { Name: 'B', Width: 10, Height: 10 }, components: [
  { id: '1', name: 'U1', packageName: 'QFN', centerX: 2, centerY: 2, lands: [
    { globalId: 1, localIndex: 1, cadName: 'A1', side: 'top', left: 1, top: 2, width: 1, length: 1 },
    { globalId: 2, localIndex: 2, cadName: 'A1', side: 'top', left: 2, top: 2, width: 1, length: 1 },
  ] },
  { id: '2', name: 'U1', packageName: 'QFN', centerX: 20, centerY: 20, lands: [
    { globalId: 3, localIndex: 1, cadName: 'B1', side: 'top', left: 20, top: 20, width: 1, length: 1 },
  ] },
] };
const model = normalizeLegacyCad(legacy, { projectId: 'validation' });
const validation = validateUniversalCad(model, { bom: [{ reference: 'U1', partNumber: 'PN1' }, { reference: 'R9', partNumber: 'PN9' }], requirePolarity: true });
assert.ok(validation.issues.some((item) => item.code === 'DUPLICATE_REFERENCE' && item.level === 'blocking-error'));
assert.ok(validation.issues.some((item) => item.code === 'DUPLICATE_LAND_NAME_COMPONENT'));
assert.ok(validation.issues.some((item) => item.code === 'COMPONENT_OUTSIDE_BOARD'));
assert.ok(validation.issues.some((item) => item.code === 'BOM_MISSING_IN_CAD'));
assert.equal(validation.exportAllowed, false);
const warning = validation.issues.find((item) => item.overridable);
overrideValidationIssue(validation, warning.id, 'ตรวจสอบกับ Engineer แล้ว');
assert.equal(warning.overridden, true);
assert.throws(() => overrideValidationIssue(validation, validation.issues.find((item) => item.code === 'DUPLICATE_REFERENCE').id, 'force'), /ไม่อนุญาต/);
const preflight = exportPreflight(model);
assert.ok(preflight.blockingErrors.length > 0);
const differentBoards = normalizeLegacyCad({ board: { Width: 10, Height: 10 }, components: [{ ...legacy.components[0] }, { ...legacy.components[1], name: 'U1' }] });
differentBoards.components[0].boardId = 'board:1'; differentBoards.components[1].boardId = 'board:2';
assert.equal(validateUniversalCad(differentBoards).issues.some((item) => item.code === 'DUPLICATE_REFERENCE'), false);
console.log('validation center scopes, severities, overrides and export preflight passed');
