import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createCadEditorModel } from '../cad-editor.js';
import { exportVtxInspectionXml, formatVtxNumber, isVtxEpmXml } from '../vtx-inspection-xml.js';
import { parseInspectionXml } from '../parsers.js';

const xml = await readFile(new URL('./sample-mini.xml', import.meta.url), 'utf8');
const model = createCadEditorModel(xml);
model.board.Name = 'TEST_BOARD';
model.components[0].centerX = 158.15399999999997;
model.components[0].lands[0].left = 154.52399999999997;
model.components[0].lands[0].width = 0.660000000000025;
model.components[0].lands[0].length = 0.6599999999999682;

const output = exportVtxInspectionXml(model, { side: 'all', date: new Date(2026, 7, 20, 15, 30, 0) });
assert(output.startsWith('<?xml version="1.0" encoding="utf-8"?>\r\n<DataList FormatVersion="">'));
assert(isVtxEpmXml(output));
assert(!output.includes('<InspectionData>'));
for (const required of [
  '<InspectionProjectXml>', '<InspectionRegionCollectionSetXml>', '<ComponentInformationCollectionXml>',
  '<ComponentNumberCollectionXml>', '<ComponentNumberCollection FormatVersion="">', '<LandNumberCollection>', '<FeatureList>',
]) assert(output.includes(required), `missing ${required}`);
assert(output.includes('CenterPosX="158.154"'));
assert(output.includes('Left="154.524"'));
assert(output.includes('Width="0.66"'));
assert(!output.includes('158.15399999999997'));
assert(!output.includes('0.660000000000025'));
assert(output.includes('<ComponentInformation Id="1" Name="U1">'));
assert(output.includes('<LandNumber LandId="1" Component="1"'));
assert.equal((output.match(/<FeatureList>/g) || []).length, 3);
assert.equal((output.match(/<Feature Command=/g) || []).length, 15);

const parsed = parseInspectionXml(output);
assert.equal(parsed.components.length, 2);
assert.equal(parsed.totalLands, 3);
assert.equal(parsed.board.Name, 'TEST_BOARD');
assert.equal(parsed.components[0].centerX, 158.154);
assert.equal(parsed.components[0].lands[0].left, 154.524);

assert.equal(formatVtxNumber(193.62799999999996, { precision: 3, minDecimals: 1 }), '193.628');
assert.equal(formatVtxNumber(180, { precision: 5, minDecimals: 1 }), '180.0');
assert.equal(formatVtxNumber(-0.00000001, { precision: 3, minDecimals: 1 }), '0.0');
console.log('VT-X/ePM XML export schema and precision checks passed');
