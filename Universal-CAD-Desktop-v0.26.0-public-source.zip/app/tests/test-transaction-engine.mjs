import assert from 'node:assert/strict';
import { normalizeLegacyCad } from '../universal-cad-model.js';
import { CadTransactionEngine, executeCadCommand, validateTransactionModel } from '../transaction-engine.js';

const legacy = {
  board: { Name: 'B1', Width: 100, Height: 80 },
  components: [
    { id: '1', name: 'U1', packageName: 'QFN', centerX: 10, centerY: 20, angle: 0, lands: [
      { globalId: 1, localIndex: 1, cadName: '1', side: 'top', left: 9, top: 21, width: 1, length: 2, centerX: 9.5, centerY: 20 },
      { globalId: 2, localIndex: 2, cadName: '2', side: 'top', left: 10, top: 21, width: 1, length: 2, centerX: 10.5, centerY: 20 },
    ] },
    { id: '2', name: 'R1', packageName: '0603', centerX: 30, centerY: 40, angle: 90, lands: [
      { globalId: 3, localIndex: 1, cadName: '1', side: 'bottom', left: 29, top: 41, width: 2, length: 1, centerX: 30, centerY: 40.5 },
    ] },
  ],
};
const model = normalizeLegacyCad(legacy, { projectId: 'project:test' });
assert.equal(validateTransactionModel(model), true);
const engine = new CadTransactionEngine(model);
engine.execute({ type: 'rename-component', componentId: '1', reference: 'U_MAIN' });
engine.execute({ type: 'move-component', componentId: '1', dx: 5, dy: -2 });
engine.execute({ type: 'rotate-component', componentId: '1', delta: -90 });
engine.execute({ type: 'change-side', componentId: '1', side: 'bottom' });
assert.equal(engine.model.components[0].reference, 'U_MAIN');
assert.deepEqual(engine.model.components[0].position, { x: 15, y: 18 });
assert.equal(engine.model.components[0].rotation, 270);
assert.equal(engine.model.components[0].side, 'bottom');
assert.equal(engine.undo(), true);
assert.equal(engine.model.components[0].side, 'unknown');
assert.equal(engine.redo(), true);
assert.equal(engine.model.components[0].side, 'bottom');

const landId = engine.model.components[0].landIds[0];
engine.execute({ type: 'move-land', landId, dx: 1, dy: 2 });
engine.execute({ type: 'resize-land', landId, width: 3, height: 4 });
engine.execute({ type: 'rotate-land', landId, delta: 450 });
assert.equal(engine.model.lands.find((item) => item.id === landId).geometry.rotation, 90);
const beforeAdd = engine.model.lands.length;
engine.execute({ type: 'add-land', componentId: '1', land: { name: 'P3', geometry: { left: 1, top: 2, width: 1, height: 1 } } });
assert.equal(engine.model.lands.length, beforeAdd + 1);
assert.equal(engine.undo(), true);
assert.equal(engine.model.lands.length, beforeAdd);

const qfn = engine.model.components[0].packageId;
engine.execute({ type: 'clone-package', packageId: qfn, newPackageId: 'package:QFN:custom', name: 'QFN-CUSTOM' });
engine.execute({ type: 'change-package', componentId: '1', packageId: 'package:QFN:custom' });
assert.equal(engine.model.components[0].packageId, 'package:QFN:custom');
engine.execute({ type: 'split-component-new-package', componentId: '2', newPackageId: 'package:0603:R1' });
assert.equal(engine.model.components[1].packageId, 'package:0603:R1');
engine.execute({ type: 'change-board-profile', profile: { type: 'rectangle', width: 120, height: 90 } });
engine.execute({ type: 'add-panel-instance', instance: { id: 'panel:1', transformation: { x: 10, y: 5, rotation: 450, mirror: true } } });
assert.equal(engine.model.panelInstances[0].transformation.rotation, 90);
engine.execute({ type: 'delete-panel-instance', instanceId: 'panel:1' });
assert.equal(engine.model.panelInstances.length, 0);
assert.ok(engine.changeSet().length >= 10);
assert.throws(() => executeCadCommand(engine.model, { type: 'resize-land', landId, width: 0, height: 1 }), /มากกว่า 0/);
console.log('transaction engine commands, validation, undo and redo passed');

const shapeModel = normalizeLegacyCad(legacy, { projectId: 'project:shape' });
const shapeEngine = new CadTransactionEngine(shapeModel);
const firstLandId = shapeEngine.model.components[0].landIds[0];
const originalLandCount = shapeEngine.model.lands.length;
shapeEngine.execute({ type: 'split-land', landId: firstLandId, axis: 'x', ratio: 0.5 });
assert.equal(shapeEngine.model.lands.length, originalLandCount + 1);
const splitIds = shapeEngine.model.components[0].landIds.slice(0, 2);
shapeEngine.execute({ type: 'merge-lands', landIds: splitIds });
assert.equal(shapeEngine.model.lands.length, originalLandCount);
assert.equal(shapeEngine.undo(), true);
assert.equal(shapeEngine.model.lands.length, originalLandCount + 1);
shapeEngine.execute({ type: 'set-package-origin', packageId: shapeEngine.model.components[0].packageId, x: 1.25, y: -2.5 });
shapeEngine.execute({ type: 'set-package-pin1', packageId: shapeEngine.model.components[0].packageId, landId: firstLandId });
shapeEngine.execute({ type: 'set-package-polarity', packageId: shapeEngine.model.components[0].packageId, polarity: 'positive' });
shapeEngine.execute({ type: 'renumber-pins', componentId: '1', prefix: 'P', start: 1 });
assert.equal(shapeEngine.model.lands.find((land) => land.id === firstLandId).name, 'P1');
const beforeDifference = shapeEngine.model.lands.length;
shapeEngine.execute({ type: 'boolean-difference-land', landId: firstLandId, cutter: { left: 9.1, top: 20.9, width: 0.1, height: 0.1 } });
assert.ok(shapeEngine.model.lands.length >= beforeDifference);
console.log('transaction land split, merge, boolean difference and package metadata commands passed');
