import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const [app, html, css, sw, precache] = await Promise.all([
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../styles.css', import.meta.url), 'utf8'),
  fs.readFile(new URL('../sw.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../precache-manifest.js', import.meta.url), 'utf8'),
]);
assert(app.includes("const BOARD_VIEW = '__board__'"));
assert(app.includes('state.selectedComponentId = BOARD_VIEW'));
assert(app.includes('ทั้งบอร์ด'));
assert(app.includes('for (const component of components)') && app.includes('for (const land of component.lands)'));
assert(app.includes('readCadPackageFile(file)'));
assert(app.includes('rebuildCadPackage(archive.packageInfo, archive.candidate, output)'));
assert(html.includes('เปิด ZIP / TGZ / TAR'));
assert(html.includes('.xml,.cpo,.cad,.fab,.gcd,.job,.dat,.txt,.zip,.tgz,.tar.gz,.tar'));
assert(css.includes('width: 100vw; height: 100dvh'));
assert(css.includes('body.cad-editor-open { overflow: hidden; }'));
assert(sw.includes('precache-manifest.js') && precache.includes('./archive-package.js'));
console.log('board view, nested archive and full-screen editor static checks passed');
