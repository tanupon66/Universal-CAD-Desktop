import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

class ClassList {
  constructor() { this.values = new Set(); }
  add(...items) { items.forEach((item) => this.values.add(item)); }
  remove(...items) { items.forEach((item) => this.values.delete(item)); }
  toggle(item, force) {
    if (force === true) { this.values.add(item); return true; }
    if (force === false) { this.values.delete(item); return false; }
    if (this.values.has(item)) { this.values.delete(item); return false; }
    this.values.add(item); return true;
  }
  contains(item) { return this.values.has(item); }
}
const context = new Proxy({}, { get: (target, key) => target[key] || (target[key] = () => {}), set: (target, key, value) => (target[key] = value, true) });
class Element {
  constructor(id = '') {
    this.id = id; this.classList = new ClassList(); this.style = {}; this.value = ''; this.textContent = '';
    this.innerHTML = ''; this.disabled = false; this.checked = false; this.clientWidth = id.includes('Canvas') ? 900 : 180;
    this.clientHeight = id.includes('Canvas') ? 650 : 120; this.tagName = 'DIV'; this.options = []; this.dataset = {};
    this.offsetWidth = 180; this.offsetHeight = 36; this.title = '';
  }
  addEventListener() {}
  append(...items) { this.options.push(...items); }
  click() {}
  focus() {}
  blur() {}
  setAttribute(name, value) { this[name] = value; }
  getAttribute(name) { return this[name]; }
  getContext() { return context; }
  getBoundingClientRect() { return { left: 0, top: 0, width: this.clientWidth, height: this.clientHeight }; }
  setPointerCapture() {}
  closest() { return null; }
}
const elements = new Map();
const get = (id) => elements.has(id) ? elements.get(id) : (elements.set(id, new Element(id)), elements.get(id));
globalThis.document = {
  body: new Element('body'), activeElement: new Element('active'), fullscreenElement: null,
  getElementById: get, querySelector: () => new Element(), querySelectorAll: () => [],
  createElement: (tag) => { const item = new Element(); item.tagName = String(tag).toUpperCase(); return item; },
  createDocumentFragment: () => new Element(), addEventListener() {}, exitFullscreen: async () => {},
};
globalThis.window = { devicePixelRatio: 1, addEventListener() {}, confirm() { return true; } };
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true });
globalThis.requestAnimationFrame = (callback) => (callback(), 1);
globalThis.ResizeObserver = class { observe() {} };
globalThis.URL.createObjectURL = () => '';
globalThis.URL.revokeObjectURL = () => {};

const module = await import('../app.js');
const {
  state, resetCadEditorHistory, beginCadEditorHistory, commitCadEditorHistory,
  undoCadEditor, redoCadEditor, syncCadNamesToEditorModel, applyCadNamesToProject,
} = module;

const component = {
  uid: 'component:1', originalId: '1', id: '1', name: 'U1', packageName: 'QFN', revision: '',
  centerX: 1, centerY: 2, angle: 0, isNew: false,
  lands: [{ uid: '1\u00001', originalComponentId: '1', originalGlobalId: 1, globalId: 1, componentId: '1', cadName: 'A1', side: 'Top', left: 0, top: 1, width: .5, length: .5, localIndex: 1, isNew: false }],
};
const model = { board: { Name: 'TEST', Width: 10, Height: 10 }, components: [component], sourceText: '', sourceSize: 0, changed: false };
state.cadEditor.model = model;
state.cadEditor.selectedComponentUids = new Set([component.uid]);
state.cadEditor.selectedComponentUid = component.uid;
state.cadEditor.selectedLandUid = null;
state.cadEditor.visual.mode = 'component';
resetCadEditorHistory(model);

const move = beginCadEditorHistory('Move U1', { componentUids: [component] });
component.centerX = 5;
component.lands[0].left = 4;
model.changed = true;
assert.equal(commitCadEditorHistory(move, { componentUids: [component] }), true);
assert.equal(state.cadEditor.history.undo.length, 1);
assert.equal(undoCadEditor(), true);
assert.equal(state.cadEditor.model.components[0].centerX, 1);
assert.equal(state.cadEditor.model.components[0].lands[0].left, 0);
assert.equal(state.cadEditor.model.changed, false);
assert.equal(redoCadEditor(), true);
assert.equal(state.cadEditor.model.components[0].centerX, 5);
assert.equal(state.cadEditor.model.components[0].lands[0].left, 4);

const structure = beginCadEditorHistory('Add component', { structure: true });
state.cadEditor.model.components.push({ ...structuredClone(state.cadEditor.model.components[0]), uid: 'component:2', id: '2', name: 'U2' });
state.cadEditor.model.changed = true;
assert.equal(commitCadEditorHistory(structure), true);
assert.equal(state.cadEditor.model.components.length, 2);
undoCadEditor();
assert.equal(state.cadEditor.model.components.length, 1);
redoCadEditor();
assert.equal(state.cadEditor.model.components.length, 2);



const viewerLand = { componentId: '1', globalId: 10, localIndex: 1, cadName: 'AB_CD', side: 'Top', left: 0, top: 1, centerX: .25, centerY: .75, width: .5, length: .5 };
const viewerComponent = { id: '1', name: 'U1', packageName: 'QFN', lands: [viewerLand], bounds: { minX: 0, maxX: .5, minY: .5, maxY: 1 } };
const viewerData = { board: { Name: 'SYNC', Width: 2, Height: 2 }, components: [viewerComponent], componentById: new Map([['1', viewerComponent]]), totalLands: 1 };
state.xmlData = viewerData;
state.xmlText = '<Inspection />';
state.activeCadRole = 'original';
state.cadFiles.original = { role: 'original', name: 'sync.xml', text: state.xmlText, data: viewerData, renames: new Map(), editorModel: null };
state.cadFiles.generated = null;
state.cadInspector.renames = new Map([['1\u000010', 'AB1CD']]);
state.mappingData = null;
state.selectedComponentId = '__board__';
state.selected = null;
assert.equal(applyCadNamesToProject({ silent: true }), 1);
assert.equal(viewerLand.cadName, 'AB1CD');
assert.equal(state.cadFiles.original.data.components[0].lands[0].cadName, 'AB1CD');

const editorSyncFile = {
  data: { components: [{ id: '1', lands: [{ globalId: 1, cadName: 'AB1CD' }] }] },
  editorModel: { components: [{ id: '1', originalId: '1', lands: [{ globalId: 1, originalGlobalId: 1, cadName: 'AB_CD' }] }] },
};
assert.equal(syncCadNamesToEditorModel(editorSyncFile), 1);
assert.equal(editorSyncFile.editorModel.components[0].lands[0].cadName, 'AB1CD');
assert.equal(syncCadNamesToEditorModel(editorSyncFile), 0);

const [html, app, css, sw, manifestText] = await Promise.all([
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../styles.css', import.meta.url), 'utf8'),
  fs.readFile(new URL('../sw.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../manifest.webmanifest', import.meta.url), 'utf8'),
]);
for (const menu of ['file', 'edit', 'view', 'tools']) {
  assert(html.includes(`data-cad-menu="${menu}"`));
  assert(html.includes(`data-cad-menu-panel="${menu}"`));
}
for (const command of ['open','export-xml','undo','redo','cut','copy','paste','duplicate','delete','fit-board','fit-selection','toggle-grid','toggle-labels','toggle-snap','fullscreen','select-tool','pan-tool','component-mode','land-mode','open-name-inspector','validate']) {
  assert(html.includes(`data-cad-command="${command}"`), `missing command ${command}`);
}
for (const id of ['cadEditorUndoButton','cadEditorRedoButton','cadEditorHistoryStatus','cadEditorApplyButton','cadEditorConfirmOverlay','cadEditorConfirmYes','cadEditorConfirmNo','cadEditorBusyOverlay']) assert(html.includes(`id="${id}"`));
for (const fn of ['resetCadEditorHistory','beginCadEditorHistory','commitCadEditorHistory','undoCadEditor','redoCadEditor','runCadEditorCommand','updateCadEditorMenuState','requestCadEditorApply','confirmCadEditorChoice','runCadEditorTask']) assert(app.includes(`function ${fn}`));
assert(app.includes("if (key === 'z')"));
assert(app.includes("if (key === 'y')"));

assert(!html.includes('id="cadStudioMappingButton"'), 'Apply → Mapping header button must be removed');
assert(!html.includes('data-cad-command="apply"'), 'File menu must not duplicate the bottom Apply action');
assert.equal((html.match(/id="cadEditorApplyButton"/g) || []).length, 1, 'there must be exactly one Apply button in CAD Editor');
assert(app.includes("showCadEditorConfirm('apply')"), 'Apply must use animated Yes/No confirmation');
assert(app.includes('CAD_EDITOR_LIGHT_SELECTION_LIMIT'), 'large selection lightweight mode missing');
assert(css.includes('.cad-confirm-overlay'), 'confirmation animation styles missing');
assert(css.includes('.cad-editor-busy-overlay'), 'busy-state styles missing');
assert(css.includes('.cad-menu-dropdown'));
assert(sw.includes("const APP_VERSION = '0.25.2'") && sw.includes('CACHE_PREFIX'));
assert(JSON.parse(manifestText).name.includes('v0.25.2'));
console.log('CAD history and functional menu tests passed');
