import assert from 'node:assert/strict';
import { transformCadEditorBoard } from '../board-transform.js';
import { createCadEditorModel, serializeCadEditorModelStandalone } from '../cad-editor.js';

const xml = `<?xml version="1.0"?><InspectionData><BoardInformation Name="TEST" Width="10" Height="20" Thickness="1"/><Components><ComponentInformation Id="1" Name="U1"><ComponentInformationItem ComponentNumberId="PKG" ComponentNumberRevision=""/><PositionAngle CenterPosX="2" CenterPosY="3" Angle="0"/></ComponentInformation></Components><Lands><LandNumber LandId="1" Component="1" Name="A1" Side="0"><Land Left="1" Top="4" Width="2" Length="2"/></LandNumber></Lands></InspectionData>`;
const model = createCadEditorModel(xml);
const originalSource = model.sourceText;
const right = transformCadEditorBoard(model, 'rotate-right');
assert.equal(right.outputBounds.width, 20);
assert.equal(right.outputBounds.height, 10);
assert.equal(model.board.Width, 20);
assert.equal(model.board.Height, 10);
assert.equal(model.components[0].centerX, 3);
assert.equal(model.components[0].centerY, 8);
assert.equal(model.components[0].angle, 90);
assert.equal(model.components[0].lands[0].left, 2);
assert.equal(model.components[0].lands[0].top, 9);
assert.equal(model.sourceText, originalSource, 'immutable source text must not be modified');
const serialized = serializeCadEditorModelStandalone(model);
assert.match(serialized, /BoardInformation[^>]*Width="20"[^>]*Height="10"/);

transformCadEditorBoard(model, 'rotate-left');
assert.equal(model.board.Width, 10);
assert.equal(model.board.Height, 20);
assert(Math.abs(model.components[0].centerX - 2) < 1e-9);
assert(Math.abs(model.components[0].centerY - 3) < 1e-9);
assert.equal(model.components[0].angle, 0);

const bad = createCadEditorModel(xml);
bad.components[0].lands[0].width = 0;
const before = JSON.stringify(bad);
assert.throws(() => transformCadEditorBoard(bad, 'rotate-180'), /Geometry/);
assert.equal(JSON.stringify(bad), before, 'invalid board transform must fail before mutation');
console.log('Board rotation/mirror transform, immutable source and board-size serialization passed');
