# Security notes

This repository intentionally does **not** contain the Universal CAD private signing key, the encrypted issuer master-key document, or the Master Password.

The customer application contains only the Ed25519 public key used to verify licenses. The License Manager is a generic issuer UI: on first use, the administrator imports the encrypted `master-key.enc.json` file locally. That key document is copied into the License Manager's Electron `userData` directory and is never uploaded by the application.

Keep the encrypted master-key file and its Master Password in separate secure locations. Do not commit either one to Git history, even when a repository is private.
