'use strict';

const crypto = require('node:crypto');
const os = require('node:os');
const { execFileSync } = require('node:child_process');

function tryCommand(command, args) {
  try {
    return String(execFileSync(command, args, { windowsHide: true, encoding: 'utf8', timeout: 4000, stdio: ['ignore', 'pipe', 'ignore'] }) || '').trim();
  } catch { return ''; }
}

function windowsMachineGuid() {
  const out = tryCommand('reg.exe', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid']);
  const match = out.match(/MachineGuid\s+REG_\w+\s+([^\r\n]+)/i);
  return match ? match[1].trim() : '';
}

function windowsBiosUuid() {
  const script = '(Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue).UUID';
  const out = tryCommand('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script]);
  return out.split(/\r?\n/).map((s) => s.trim()).find((s) => /^[0-9A-Fa-f-]{16,}$/.test(s)) || '';
}

function fallbackSeed() {
  const macs = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const item of list || []) if (item && !item.internal && item.mac && item.mac !== '00:00:00:00:00:00') macs.push(item.mac.toLowerCase());
  }
  return [os.hostname(), os.arch(), os.platform(), ...macs.sort()].join('|');
}

function machineSeed() {
  if (process.platform === 'win32') {
    const guid = windowsMachineGuid();
    const bios = windowsBiosUuid();
    if (guid || bios) return `win|${guid}|${bios}`;
  }
  return `fallback|${fallbackSeed()}`;
}

function computeMachineId() {
  const hash = crypto.createHash('sha256').update(machineSeed()).digest('hex').toUpperCase();
  const body = hash.slice(0, 24).match(/.{1,4}/g).join('-');
  return `UCAD-${body}`;
}

module.exports = { computeMachineId, machineSeed };
