'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { safeStorage } = require('electron');
const { computeMachineId } = require('./machine-id.cjs');
const { evaluateLicense, parseLicenseText } = require('../license-core/license-format.cjs');

class LicenseService {
  constructor({ userDataPath, publicKeyPath }) {
    this.userDataPath = userDataPath;
    this.publicKeyPath = publicKeyPath;
    this.storePath = path.join(userDataPath, 'license.dat');
    this.publicKeyPem = fs.readFileSync(publicKeyPath, 'utf8');
    this.machineId = computeMachineId();
    this._lastTouchWrite = 0;
  }

  getMachineId() { return this.machineId; }

  _readProtectedDocument() {
    if (!fs.existsSync(this.storePath)) return null;
    const blob = fs.readFileSync(this.storePath);
    if (!blob.length) return null;
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available.');
    const plain = safeStorage.decryptString(blob);
    const record = JSON.parse(plain);
    return record;
  }

  _writeProtectedRecord(record) {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available.');
    fs.mkdirSync(this.userDataPath, { recursive: true });
    const encrypted = safeStorage.encryptString(JSON.stringify(record));
    const temp = `${this.storePath}.tmp-${process.pid}`;
    fs.writeFileSync(temp, encrypted, { mode: 0o600 });
    fs.renameSync(temp, this.storePath);
  }

  status({ touch = false, now = new Date() } = {}) {
    let record;
    try { record = this._readProtectedDocument(); }
    catch (error) { return { ok: false, code: 'STORE_ERROR', message: error.message, machineId: this.machineId }; }
    if (!record?.license) return { ok: false, code: 'NO_LICENSE', message: 'No license has been activated on this computer.', machineId: this.machineId };
    const result = evaluateLicense(record.license, this.publicKeyPem, this.machineId, {
      now,
      lastSeenUtcMs: record.lastSeenUtcMs,
      clockRollbackToleranceMs: 5 * 60 * 1000,
    });
    if (!result.ok) return { ...result, machineId: this.machineId };
    if (touch && now.getTime() - this._lastTouchWrite > 10 * 60 * 1000) {
      const next = { ...record, lastSeenUtcMs: Math.max(Number(record.lastSeenUtcMs) || 0, now.getTime()), lastSeenIso: now.toISOString() };
      try { this._writeProtectedRecord(next); this._lastTouchWrite = now.getTime(); } catch { /* status remains valid */ }
    }
    return { ...result, machineId: this.machineId, activatedAt: record.activatedAt || null };
  }

  activateFromFile(filePath) {
    const resolved = path.resolve(String(filePath || ''));
    if (!resolved.toLowerCase().endsWith('.ucadlic')) throw new Error('Please select a .ucadlic license file.');
    const document = parseLicenseText(fs.readFileSync(resolved, 'utf8'));
    const validation = evaluateLicense(document, this.publicKeyPem, this.machineId, { now: new Date() });
    if (!validation.ok) {
      const error = new Error(validation.message);
      error.code = validation.code;
      throw error;
    }
    const now = new Date();
    const record = { license: document, activatedAt: now.toISOString(), lastSeenUtcMs: now.getTime(), lastSeenIso: now.toISOString() };
    this._writeProtectedRecord(record);
    this._lastTouchWrite = now.getTime();
    let consumed = false;
    let consumeWarning = '';
    try { fs.unlinkSync(resolved); consumed = true; }
    catch (error) { consumeWarning = `Activated, but the source license file could not be deleted: ${error.message}`; }
    return { ...validation, machineId: this.machineId, consumed, consumeWarning, activatedAt: now.toISOString() };
  }

  removeLocalLicense() {
    for (const p of [this.storePath]) { try { fs.unlinkSync(p); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
  }
}

module.exports = { LicenseService };
