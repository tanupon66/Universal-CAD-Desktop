'use strict';
const $ = (id) => document.getElementById(id);
const machineId = $('machineId'), copyBtn = $('copyBtn'), activateBtn = $('activateBtn'), openBtn = $('openBtn');
const message = $('message'), details = $('details'), statusPill = $('statusPill'), appVersion = $('appVersion');

function showMessage(text, success = false) { message.textContent = text; message.classList.remove('hidden','success'); if (success) message.classList.add('success'); }
function renderStatus(status) {
  machineId.textContent = status.machineId || '—';
  if (!status.ok) { statusPill.textContent = status.code === 'EXPIRED' ? 'หมดอายุ' : 'ยังไม่เปิดใช้งาน'; statusPill.classList.remove('valid'); details.classList.add('hidden'); openBtn.classList.add('hidden'); return; }
  const p = status.payload;
  statusPill.textContent = 'ใช้งานได้'; statusPill.classList.add('valid');
  details.innerHTML = `<b>ลูกค้า</b><span>${escapeHtml(p.customerName)}</span><b>คอมพิวเตอร์</b><span>${escapeHtml(p.computerLabel || p.machineId)}</span><b>License ID</b><span>${escapeHtml(p.licenseId)}</span><b>ระยะเวลา</b><span>${escapeHtml(p.validFrom)} ถึง ${escapeHtml(p.validUntil)}</span>`;
  details.classList.remove('hidden'); openBtn.classList.remove('hidden');
}
function escapeHtml(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

copyBtn.addEventListener('click', async () => { await window.desktopLicense.copyMachineId(); copyBtn.textContent='คัดลอกแล้ว'; setTimeout(()=>copyBtn.textContent='คัดลอกรหัส',1200); });
activateBtn.addEventListener('click', async () => {
  message.classList.add('hidden'); activateBtn.disabled = true;
  const response = await window.desktopLicense.chooseAndActivate();
  activateBtn.disabled = false;
  if (response.canceled) return;
  if (response.error) { showMessage(response.error.message); return; }
  renderStatus(response.result);
  const consume = response.result.consumed ? ' ไฟล์ License ต้นทางถูกลบแล้ว' : ` ${response.result.consumeWarning || ''}`;
  showMessage(`เปิดใช้งานสำเร็จ.${consume}`, true);
  setTimeout(() => window.desktopLicense.openMainApp(), 500);
});
openBtn.addEventListener('click', () => window.desktopLicense.openMainApp());

(async () => { const [status, info] = await Promise.all([window.desktopLicense.status(), window.desktopLicense.appInfo()]); renderStatus(status); appVersion.textContent = `${info.name} v${info.version}`; if (!status.ok && !['NO_LICENSE'].includes(status.code)) showMessage(status.message); })();
