# Universal CAD Studio Desktop v0.27.0

Desktop release based on **Universal CAD Studio PWA v0.26.0**. The Electron shell and license architecture stay compatible with Desktop v0.26.0, while the embedded PWA is replaced by the newer NPI-capable release.

## What is included

- Full PWA v0.26.0 runtime, including NPI Workspace, compatibility/conversion-loss reporting, CAD health, package recognition/mapping, CAD/BOM/placement reconciliation, revision comparison/timeline, coordinate calibration, panel arrays, golden-template tools, custom export profiles and BOM Export Designer.
- Existing CAD Editor, Mapping, Apply/Undo/Redo, validation, autosave/recovery, VT-X/ePM XML, GenCAD, FABmaster, ODB++, Grid/Land Map and Excel workflows remain present.
- Windows Electron customer application with machine-bound offline licensing.
- Separate Universal CAD License Manager for the administrator.

## License compatibility

Desktop v0.27.0 deliberately keeps the same product ID and Ed25519 public verification key as Desktop v0.26.0. Existing valid `.ucadlic` licenses therefore remain valid on the same licensed computer and do **not** need to be reissued merely because the application is updated.

The customer installer contains only `desktop/public-key.pem`. The administrator's encrypted Master Key and Master Password are distributed separately and are never bundled in the repository or installers. License Manager imports the encrypted Master Key locally into its Electron `userData` directory.

Activation validates the signature, Machine ID, valid-from/valid-until dates and normal clock rollback protection. Successful activation is persisted locally using Electron `safeStorage`; the selected source `.ucadlic` is deleted after activation when the filesystem permits it.

## Build

On Windows, run `BUILD-WINDOWS.cmd`, or:

```powershell
npm install
npm run test:full
npm run build:windows
```

Expected installers:

- `release/customer/Universal-CAD-Studio-Setup-0.27.0-x64.exe`
- `release/license-manager/Universal-CAD-License-Manager-Setup-0.27.0-x64.exe`

## Validation gate

The source package must pass:

- License cryptography tests
- Public-package/secret-leak tests
- PWA typecheck (102 modules)
- Security lint
- PWA regression suite (53/53)
- Static production build and production verifier
- Windows Electron/NSIS packaging in GitHub Actions

## Security notes

- Never commit or send the Master Password or encrypted Master Key to customers.
- Keep the commercial repository private after the Windows build is confirmed.
- Offline machine binding prevents using the same license on another Machine ID, but absolute global one-time activation/revocation requires an online trusted ledger.
- The installer is not Authenticode-signed unless a Windows code-signing certificate is configured, so SmartScreen may initially show `Unknown publisher`.
