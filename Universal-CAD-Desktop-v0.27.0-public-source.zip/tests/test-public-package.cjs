'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');
const ROOT = path.join(__dirname, '..');
const forbidden = [
  'license-manager/issuer/master-key.enc.json',
  'UCAD_MASTER_PASSWORD_v0.26.0.txt',
  'UCAD_MASTER_PASSWORD_v0.27.0.txt',
  'private-key.pem',
];
for (const rel of forbidden) assert.ok(!fs.existsSync(path.join(ROOT, rel)), `forbidden secret present: ${rel}`);
const managerBuilder = fs.readFileSync(path.join(ROOT, 'electron-builder.manager.yml'), 'utf8');
const customerBuilder = fs.readFileSync(path.join(ROOT, 'electron-builder.customer.yml'), 'utf8');
assert.ok(!managerBuilder.includes('master-key.enc.json'), 'manager installer must not bundle issuer master key');
assert.match(managerBuilder, /directories:\s*[\r\n]+\s*app:\s*\./, 'manager builder must package from suite root');
assert.match(customerBuilder, /directories:\s*[\r\n]+\s*app:\s*\./, 'customer builder must package from suite root');
assert.ok(customerBuilder.includes('app/*.js'), 'customer builder must include all root PWA runtime JavaScript modules');
const manager = fs.readFileSync(path.join(ROOT, 'license-manager/main.cjs'), 'utf8');
assert.ok(manager.includes("app.getPath('userData')"), 'manager must store imported key in local userData');
assert.ok(manager.includes('issuer:import-key'), 'manager must support explicit local key import');
const publicKey = fs.readFileSync(path.join(ROOT, 'desktop/public-key.pem'), 'utf8');
assert.match(publicKey, /BEGIN PUBLIC KEY/);
console.log('public-package security tests: PASS');
