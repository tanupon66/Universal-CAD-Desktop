@echo off
setlocal
cd /d "%~dp0"
title Universal CAD Studio - Build Windows EXE

echo ============================================================
echo  Universal CAD Studio Desktop v0.27.0 - Windows EXE Builder
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found. Install Node.js 22 or newer first.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo [ERROR] npm was not found.
  pause
  exit /b 1
)

echo [1/4] Installing build dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 goto :failed

echo [2/4] Running full License, security and PWA production gate...
call npm run test:full
if errorlevel 1 goto :failed

echo [3/4] Building Customer Installer and License Manager Installer...
call npm run build:windows
if errorlevel 1 goto :failed

echo [4/4] Build completed.
echo.
echo Customer installer:
dir /b "release\customer\*.exe" 2>nul
echo.
echo License Manager installer:
dir /b "release\license-manager\*.exe" 2>nul
echo.
echo IMPORTANT: Never send the License Manager or Master Password to customers.
pause
exit /b 0

:failed
echo.
echo [FAILED] Build stopped because a command returned an error.
pause
exit /b 1
