'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { safeStorage } = require('electron');

class CustomerLedger {
  constructor(userDataPath) { this.filePath = path.join(userDataPath, 'customer-license-ledger.dat'); }
  read() {
    if (!fs.existsSync(this.filePath)) return { schema:'ucad-customer-ledger-v1', pools:{} };
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available.');
    const value = JSON.parse(safeStorage.decryptString(fs.readFileSync(this.filePath)));
    if (!value || value.schema !== 'ucad-customer-ledger-v1' || typeof value.pools !== 'object') throw new Error('Customer License ledger is corrupted.');
    return value;
  }
  write(value) {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available.');
    fs.mkdirSync(path.dirname(this.filePath), { recursive:true });
    const temp = `${this.filePath}.tmp-${process.pid}`;
    fs.writeFileSync(temp, safeStorage.encryptString(JSON.stringify(value)), { mode:0o600 });
    fs.renameSync(temp, this.filePath);
  }
}
module.exports = { CustomerLedger };
