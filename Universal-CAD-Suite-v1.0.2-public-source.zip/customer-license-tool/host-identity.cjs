'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { safeStorage } = require('electron');
const { createEnrollmentCode, fingerprintPublicKey } = require('../license-core/host-seal.cjs');

class HostIdentity {
  constructor(userDataPath) { this.filePath = path.join(userDataPath, 'license-host-identity.dat'); }
  _newHostId() { return `UCAD-HOST-${crypto.randomBytes(12).toString('hex').toUpperCase().match(/.{1,4}/g).join('-')}`; }
  _write(record) {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available.');
    fs.mkdirSync(path.dirname(this.filePath), { recursive:true });
    const temp = `${this.filePath}.tmp-${process.pid}`;
    fs.writeFileSync(temp, safeStorage.encryptString(JSON.stringify(record)), { mode:0o600 });
    fs.renameSync(temp, this.filePath);
  }
  _read() {
    if (!fs.existsSync(this.filePath)) return null;
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available.');
    return JSON.parse(safeStorage.decryptString(fs.readFileSync(this.filePath)));
  }
  ensure() {
    let record = this._read();
    // Keep all valid v1.0.0/v1.0.1 host identities so existing entitlements remain usable.
    if (record?.hostId?.startsWith('UCAD-HOST-') && record.privateKeyPem && record.publicKeyPem) return record;
    const { publicKey, privateKey } = crypto.generateKeyPairSync('x25519');
    record = {
      schema:'ucad-license-host-identity-v2',
      hostId:this._newHostId(),
      publicKeyPem:publicKey.export({ type:'spki', format:'pem' }),
      privateKeyPem:privateKey.export({ type:'pkcs8', format:'pem' }),
      createdAt:new Date().toISOString(),
      identityMode:'persistent-random',
    };
    this._write(record);
    return record;
  }
  publicInfo() {
    const r = this.ensure();
    return { hostId:r.hostId, publicKeyPem:r.publicKeyPem, fingerprint:fingerprintPublicKey(r.publicKeyPem), enrollmentCode:createEnrollmentCode(r), createdAt:r.createdAt };
  }
  privateInfo() { return this.ensure(); }
  currentHostId() { return this.ensure().hostId; }
  restore(record) {
    if (!record || !['ucad-license-host-identity-v1','ucad-license-host-identity-v2'].includes(record.schema)) throw new Error('Unsupported recovery host identity.');
    if (!String(record.hostId || '').startsWith('UCAD-HOST-')) throw new Error('Recovery Host ID is invalid.');
    const privateKey = crypto.createPrivateKey(record.privateKeyPem);
    const derived = crypto.createPublicKey(privateKey).export({ type:'spki', format:'pem' });
    if (String(derived).trim() !== String(record.publicKeyPem).trim()) throw new Error('Recovery host key pair mismatch.');
    this._write({ ...record, schema:'ucad-license-host-identity-v2', restoredAt:new Date().toISOString() });
    return record;
  }
}
module.exports = { HostIdentity };
