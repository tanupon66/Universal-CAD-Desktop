'use strict';
const crypto = require('node:crypto');

const RECOVERY_SCHEMA = 'ucad-license-host-recovery-v1';

function deriveKey(password, salt) {
  const pass = String(password || '');
  if (pass.length < 10) throw new Error('Recovery Password must contain at least 10 characters.');
  return crypto.scryptSync(pass, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

function createRecoveryBundle({ hostRecord, ledger, password }) {
  if (!hostRecord?.hostId || !hostRecord?.privateKeyPem || !hostRecord?.publicKeyPem) throw new Error('License Host identity is incomplete.');
  const payload = {
    schema: 'ucad-license-host-recovery-payload-v1',
    hostId: String(hostRecord.hostId),
    hostRecord,
    ledger,
    exportedAt: new Date().toISOString(),
  };
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = deriveKey(password, salt);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(Buffer.from(JSON.stringify(payload), 'utf8')), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    schema: RECOVERY_SCHEMA,
    kdf: 'scrypt-N32768-r8-p1',
    cipher: 'AES-256-GCM',
    hostId: payload.hostId,
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    tag: tag.toString('base64'),
    ciphertext: ciphertext.toString('base64'),
  };
}

function openRecoveryBundle(document, password) {
  if (!document || document.schema !== RECOVERY_SCHEMA) throw new Error('Unsupported recovery backup format.');
  const salt = Buffer.from(String(document.salt || ''), 'base64');
  const key = deriveKey(password, salt);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(String(document.iv || ''), 'base64'));
  decipher.setAuthTag(Buffer.from(String(document.tag || ''), 'base64'));
  let payload;
  try {
    payload = JSON.parse(Buffer.concat([
      decipher.update(Buffer.from(String(document.ciphertext || ''), 'base64')),
      decipher.final(),
    ]).toString('utf8'));
  } catch {
    throw new Error('Incorrect Recovery Password or corrupted backup file.');
  }
  if (!payload || payload.schema !== 'ucad-license-host-recovery-payload-v1') throw new Error('Unsupported recovery payload.');
  if (String(payload.hostId) !== String(document.hostId)) throw new Error('Invalid recovery host binding.');
  return payload;
}

module.exports = { RECOVERY_SCHEMA, createRecoveryBundle, openRecoveryBundle };
