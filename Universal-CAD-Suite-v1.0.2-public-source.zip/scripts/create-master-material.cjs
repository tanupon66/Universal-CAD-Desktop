'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const {encryptPrivateKey}=require('../license-core/master-key.cjs');
const root=path.join(__dirname,'..');const outPublic=path.join(root,'desktop','public-key.pem');const outMaster=path.join(root,'license-manager','issuer','master-key.enc.json');const outPassword=process.argv[2];
if(!outPassword)throw new Error('Usage: node scripts/create-master-material.cjs <master-password>');
const {publicKey,privateKey}=crypto.generateKeyPairSync('ed25519',{publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});fs.writeFileSync(outPublic,publicKey);fs.writeFileSync(outMaster,JSON.stringify(encryptPrivateKey(privateKey,outPassword),null,2)+'\n',{mode:0o600});console.log('Created public verification key and encrypted issuer private key.');
