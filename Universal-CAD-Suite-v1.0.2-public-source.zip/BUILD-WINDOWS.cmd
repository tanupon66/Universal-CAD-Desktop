@echo off
setlocal
cd /d "%~dp0"
title Universal CAD Suite v1.0.1 - Windows Builder

echo ============================================================
echo  Universal CAD Suite v1.0.1 / Engine v0.26.0
echo ============================================================
echo.
where node >nul 2>nul || (echo [ERROR] Node.js 22+ not found.& pause & exit /b 1)
where npm >nul 2>nul || (echo [ERROR] npm not found.& pause & exit /b 1)

echo [1/4] Installing dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 goto :failed

echo [2/4] Running full validation gate...
call npm run test:full
if errorlevel 1 goto :failed

echo [3/4] Building 3 Windows installers...
call npm run build:windows
if errorlevel 1 goto :failed

echo [4/4] Build completed.
echo.
echo Universal CAD Studio:
dir /b "release\studio\*.exe" 2>nul
echo.
echo Customer License Tool:
dir /b "release\customer-license-tool\*.exe" 2>nul
echo.
echo Master License Manager:
dir /b "release\master-license-manager\*.exe" 2>nul
echo.
echo IMPORTANT: Master License Manager, Master Key, Master Password and Owner Universal License are owner-only.
pause
exit /b 0

:failed
echo.
echo [FAILED] Build stopped because a command returned an error.
pause
exit /b 1
