# Universal CAD Studio v0.18.6 — Test Report

วันที่ทดสอบ: 2026-06-26

## Browser tests บน Chromium จริง

ผ่านการทดสอบ:

- เปิด CAD และเข้า CAD Editor
- แก้ชื่อ Land แล้ว Apply
- ตรวจปุ่ม `Yes-ยืนยัน`
- ตรวจว่า Confirm ปิดก่อนงาน Apply
- ตรวจ Busy/Progress และการคืนสถานะ
- ตรวจ Viewer Data และ `editedText` ใช้ชื่อใหม่
- กด No แล้วไม่ Apply
- ปิด Editor พร้อมยืนยัน Discard
- เปิดใหม่และดาวน์โหลด Export XML จริง
- จำลองบอร์ด 4,000 Components / 16,000 Lands
- กด X ระหว่าง Apply และตรวจว่างานถูกยกเลิกก่อนแสดงหน้าต่างยืนยันปิด
- ตรวจ Tools menu ไม่ล้น viewport ที่ 1365 × 768
- ตรวจ Canvas เต็มพื้นที่ถึง Status bar
- เรียกคำสั่ง Fit, Zoom, Grid, Label, Snap, Side, Select, Pan และ Validate
- ไม่พบ JavaScript page error หรือ console error

ผล: ผ่าน

## Large-board responsiveness

ข้อมูลจำลองเท่ากับไฟล์ ODB++ ตัวอย่าง:

- 15,573 Components
- 56,782 Lands

ผลการทดสอบในสภาพแวดล้อมนี้:

- ชุด synchronous reference: ประมาณ 0.37 วินาที
- ชุด asynchronous Validate + Convert + XML + Snapshot: ประมาณ 1.1 วินาที
- Event-loop heartbeat ระหว่างงาน: มากกว่า 400 ครั้ง
- Cancel ระหว่าง Validate: ผ่าน

ผล: UI ยังตอบสนองระหว่างงาน

## Automated regression tests

ผ่าน self-contained tests 25 ชุด ครอบคลุม:

- App smoke และ DOM IDs
- Parser / ODB++ / Unix `.Z`
- Archive nested ZIP → TGZ → XML round-trip
- CAD Editor และ Visual Editor
- Undo/Redo และเมนู File/Edit/View/Tools
- Name rules และการตรวจชื่อ Land แยก Component
- Board View / Workspace full height / Menu viewport
- Mapping sync หลัง CAD Edit
- CAD Compare และ Dual CAD
- Manual Pattern / Safe Edit
- Component Excel report / XLSX report / CSV/JSON static paths
- Large-board responsive pipeline

ไฟล์ทดสอบอีก 4 ชุดเป็น integration tests ที่ต้องรับ path ของโปรเจกต์จริงจาก command line

## Syntax and packaging

- JavaScript syntax check ทุกไฟล์: ผ่าน
- Duplicate HTML IDs: ไม่พบ
- CAD Editor buttons มี event handler: ครบ
- Service Worker cache: `universal-cad-studio-v0.18.6`

หมายเหตุ: การทดสอบลดความเสี่ยงของ regression แต่ไม่สามารถรับประกันว่าไม่มีข้อผิดพลาดในทุกไฟล์ CAD ที่เป็นไปได้
