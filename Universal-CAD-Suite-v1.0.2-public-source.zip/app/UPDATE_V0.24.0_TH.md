# Universal CAD Studio v0.24.0 — Configurable Grid/Land Mapping

## แนวคิดที่แก้ไข

ชื่อ `A1`, `A2`, `B1`, `B2` หรือ `LAND 1`, `LAND 2` ไม่ใช่ชื่อที่ต้องมีอยู่ก่อนในข้อมูลต้นทาง แต่เป็น **ชื่อใหม่ที่ผู้ใช้สร้าง** แล้ว Mapping แบบ 1:1 ไปยังชื่อ Land เดิมใน CAD

ตัวอย่าง:

- ชื่อใหม่ `LAND 1` ↔ CAD Land `H9`
- ชื่อใหม่ `LAND 2` ↔ CAD Land `H8`
- ชื่อใหม่ `A1` ↔ CAD Land `PAD_003`

การ Apply Grid/Land Mapping ไม่เปลี่ยน `cadName` และไม่แก้ Immutable Source

## การตั้งค่าที่เพิ่ม

- รูปแบบชื่อใหม่: Grid, LAND sequence, เลขล้วน
- เริ่มแถวจาก A หรือค่าอื่น
- เริ่มคอลัมน์และกำหนด Step คอลัมน์
- เริ่มเลขลำดับและกำหนด Step
- เติมเลขศูนย์ เช่น `LAND 001`
- Prefix, Separator และ Suffix
- ไล่ตามแถวหรือคอลัมน์
- บน→ล่าง หรือล่าง→บน
- ซ้าย→ขวา หรือขวา→ซ้าย
- Compact gap หรือ Physical gap
- แก้ชื่อใหม่เฉพาะ Land จาก Preview

## การบันทึก

เมื่อกด `Yes - Apply Mapping` ระบบเก็บ:

- ชื่อใหม่
- ชื่อ CAD Land เดิม
- XML Land ID
- ตำแหน่ง Physical และ Logical Grid
- Configuration ที่ใช้
- Manual override
- Revision และประวัติ Apply

ข้อมูลบันทึกใน Autosave, Project Backup และ JSON Model Export โดยไม่เขียนทับ XML ต้นฉบับ

## Excel

Excel มี 2 ชีต:

1. `Grid Land Map` — ช่องบนเป็นชื่อใหม่ ช่องล่างเป็นชื่อ CAD
2. `Mapping Data` — ตาราง Mapping ราย Land พร้อม ID, พิกัด, ขนาด และสถานะ
