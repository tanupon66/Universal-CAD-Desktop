# Universal CAD Studio v0.25.1 — Release Report

App version: 0.25.1  
Schema version: 2  
Release type: large FABmaster `.cad/.fab` hotfix

## 1. Baseline

v0.25.0 baseline ผ่าน 50/50 automated test scripts ก่อนแก้ไข

## 2. Root cause

Archive scanner ของ v0.25.0 จำกัด `MAX_SCAN_BYTES = 120 MiB`. ไฟล์จริงใน ZIP มี `.cad` ขนาด 271,523,369 bytes จึงถูก skip โดยไม่เข้า FABmaster adapter แม้ content signature จะเป็น A!/J!/S! ที่รองรับอยู่แล้ว

Parser แบบเดิมยังใช้ full text + line array + section row arrays จึงไม่เหมาะกับไฟล์ 3.84 ล้านบรรทัด แม้จะเพิ่ม scan limit ก็ตาม

## 3. Architecture changes

- `ZipArchive` เพิ่ม streaming member access และ prefix sniff
- `archive-package.js` route large FABmaster member ไป streaming adapter จาก content signature
- `pcb-ascii-formats.js` เพิ่ม memory-bounded streaming state machine
- `app.js` จำกัด initial direct-file probe ที่ 1 MiB
- Working Model/Project schema/Transaction/Mapping/Export API เดิมไม่เปลี่ยน

## 4. Files changed

- `zip-reader.js`
- `archive-package.js`
- `import-adapters.js`
- `pcb-ascii-formats.js`
- `app.js`
- `tests/test-large-fabmaster-stream.mjs`
- `scripts/verify-large-fabmaster.mjs`
- version/PWA metadata/tests/docs

## 5. Bugs fixed

- Large `.cad/.fab` ใน ZIP >120 MiB ไม่ถูก skip แล้ว
- Large standalone `.cad/.fab` ไม่ถูก full-buffer เพียงเพื่อ format probe
- Multi-million irrelevant FABmaster rows ไม่ถูกเก็บเป็น row objects
- Board View ไม่ใช้ J drawing extents ที่กว้างผิดสเกลเมื่อมี `BOARD GEOMETRY / OUTLINE`

## 6. Real-file verification

`CAD_T99O089T00_045_20180921.zip`:

- Inner CAD: `FAB_T99O089T00_045_20180921.cad`
- Uncompressed size: 271,523,369 bytes
- Scanned: 3,844,879 lines
- Result: 4,714 Components / 16,027 Lands / 128 Packages
- Unit: mils
- Board profile: 313.500008 × 215.829896 mm
- Source pin rows with empty REFDES: 6 (not attachable, intentionally skipped)

## 7. Compatibility

Project schema remains 2. Original ZIP bytes remain immutable. Grid/Land Map, Name Inspector, Apply, Undo/Redo, Transaction Engine, Autosave, Validation, Excel and existing XML/CAD/FAB export workflows are retained.

## 8. Known limitations

Streaming optimization currently targets FABmaster/Cadence A!/J!/S!. Very-large GenCAD text still does not have a dedicated streaming section parser. Netlist/traces/zones are not normalized into the current Inspection compatibility model and are reported as unsupported record categories. CAD/FAB writers remain Partial writers as documented in v0.25.0.

## 9. Deployment

Deploy the entire `dist/`/Production Build together so HTML, JavaScript modules, manifest and Service Worker all use v0.25.1. Static hosting only; no Node.js runtime server is required.

## 10. Final Gate

- Type Check: 96 modules — ผ่าน
- Security lint: ผ่าน (มี review warning เดิมของ controlled `innerHTML` 1 จุด)
- Automated tests: 51/51 — ผ่าน, Failed 0, Skipped 0
- Production Build: ผ่าน
- Production HTTP/MIME/PWA verification: ผ่าน 41 precache assets
- Real-file verification: ผ่านกับ ZIP ที่ผู้ใช้แนบจริง
- Git commit hash: `unavailable` เพราะแพ็กเกจต้นทางที่ได้รับไม่ใช่ Git working tree; ไม่สร้างค่า commit ปลอม
