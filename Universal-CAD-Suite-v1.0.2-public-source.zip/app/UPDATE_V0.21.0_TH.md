# Universal CAD Studio v0.21.0 — Board Direction, Grid Mapping และ Land Map

## ฟังก์ชันใหม่

- หมุนบอร์ดซ้าย 90°, ขวา 90°, 180° และ Mirror ซ้าย/ขวา หรือบน/ล่าง
- การกลับทิศทำบน Working Model เป็น Transaction เดียว, Undo/Redo ได้ และไม่แก้ Immutable Original Source
- Grid Mapping ตรวจแถว/คอลัมน์จากตำแหน่ง Land และแก้ชื่อทั้งแถวหรือคอลัมน์จาก Header เดียว
- รองรับการกำหนดทิศ A จากบน/ล่าง, เลข 1 จากซ้าย/ขวา และตัวคั่น เช่น `A-01`
- Export Land Map เป็น SVG และ PowerPoint `.pptx` แบบกล่องแก้ไขต่อได้
- เลข LAND ใช้ Mapping ปัจจุบัน หรือสร้างลำดับมาก→น้อย/น้อย→มาก ตามแถวหรือคอลัมน์

## ผลกับข้อมูลเดิม

ไม่มีการเปลี่ยน Schema version หรือ rename field. Project/Autosave/Backup v0.20.0 ยังเปิดได้ตาม Compatibility Layer เดิม. Board transform, Grid Mapping และ Land Map เป็น additive features.

## วิธีใช้ย่อ

1. Import CAD แล้วเปิด CAD Editor
2. เมนู **Board** → เลือก Rotate/Mirror และยืนยัน
3. เลือก Component 1 ตัว → **Grid Map** → แก้หัวแถว/คอลัมน์ → Apply
4. กด Apply หลักเพื่อสร้าง Revision ใหม่
5. เลือก **Land Map** → ตั้งหมายเลข/ทิศทาง → Export SVG หรือ PowerPoint
