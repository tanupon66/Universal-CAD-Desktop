# Test Report v0.26.0

Commands executed:

`npm run typecheck` — PASS, 102 modules.

`npm run lint` — PASS. Review warnings: controlled dynamic innerHTML in app.js and npi-workspace-ui.js.

`npm run test:all` — PASS, 53/53 scripts; failed 0; skipped 0.

`npm run build` — PASS, static production package v0.26.0, 45 precache assets. Git hash unavailable because source directory has no .git metadata.

`npm run verify:production` — PASS, HTTP/MIME/manifest/build metadata/precache verification.

The v0.26-specific regression covers format compatibility, conversion-loss reporting, package recognition/mapping, CAD/BOM/placement reconciliation, coordinate calibration, panel arrays, project summary, BOM CSV generation, column B Location reordering, and row-oriented BOM layout.
