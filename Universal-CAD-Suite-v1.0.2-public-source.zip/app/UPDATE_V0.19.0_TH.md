# อัปเดต Universal CAD Studio v0.19.0

วันที่จัดทำ: 26 มิถุนายน 2026

## ฟังก์ชันใหม่: ลากคลุม Land แล้ว Split/Delete

- ใน **Land Mode** สามารถลากกรอบบนพื้นที่ว่างเพื่อเลือก Land หลายจุด
- ใช้ `Shift` เพื่อเพิ่มรายการ และ `Ctrl`/`Cmd` เพื่อสลับรายการในชุดที่เลือก
- ปุ่ม **Split** หรือ `Ctrl+X` ย้าย Land ที่เลือกไปเป็น Component ใหม่
- ปุ่ม **Delete** ลบ Land ที่เลือกหลายจุดพร้อมกัน
- Duplicate, Move, Rotate, Flip และปุ่มลูกศรรองรับ Land หลายจุด
- ทำซ้ำ Split ได้หลายครั้งเพื่อแบ่ง Component เดียวออกเป็นหลายส่วน
- Land ที่ย้ายยังใช้ XML Land ID เดิม จึงไม่สร้าง ID ซ้ำ
- โปรแกรมบังคับให้เหลือ Land อย่างน้อยหนึ่งจุดใน Component เดิม
- Undo/Redo เก็บทั้งโครงสร้าง Component และชุด Land ที่เลือก

## บัคที่แก้

1. **Apply XML/ไฟล์เดี่ยวไม่สำเร็จหรือ Mapping ไม่เปลี่ยน**
   - Apply ซิงก์ `data`, `editedText`, Archive candidate และ snapshot พร้อมกัน
   - ตรวจการเปลี่ยนโครงสร้างจาก Component ID + XML Land ID ไม่ได้เทียบเพียงจำนวน Component/Land
   - Mapping รีเฟรชทันทีหลัง Apply และมีเส้นทางลองซ้ำหลังปิด Editor

2. **หน้าต่างยืนยันหรือ Busy ค้าง**
   - รักษา pending action เมื่อยกเลิกงานแล้วปิด Editor
   - ทุกงาน Apply/Export คืน Busy state ใน `finally`
   - Mapping ที่รีเฟรชผิดพลาดจะไม่ทำให้ Apply CAD ทั้งงานค้าง

3. **คำสั่ง Land ไปทำกับ Component ผิดระดับ**
   - แก้ `Ctrl+X` เดิมที่อาจ Cut Component ทั้งชิ้นขณะอยู่ Land Mode
   - แก้ Duplicate/Delete/Rotate/Flip/Nudge เมื่อยังไม่ได้เลือก Land ไม่ให้ย้อนกลับไปแก้ Component
   - ปุ่ม Split แสดงและเปิดใช้งานเฉพาะเมื่อเลือก Land ที่แบ่งได้จริง

4. **ชนิดไฟล์**
   - รองรับ XML จากเนื้อหา แม้นามสกุลเป็น `.dat`, `.txt`, `.cad`, `.cpo` หรือ `.job`
   - เพิ่มการเปิด Unix compress `.Z` ระดับไฟล์หลัก
   - คงเส้นทาง ODB++ `.Z` ภายใน Archive เดิม เพื่อไม่ให้เขียน Archive กลับผิดรูปแบบ
   - TGZ/ZIP/TAR ที่ภายในเป็น CAD XML ยัง round-trip ได้ตามเดิม

## ข้อจำกัดที่ยังคงอยู่

ODB++ ที่โปรแกรมแปลงจาก `components.Z`/`eda/data.Z` เป็น XML สามารถแก้และ Export XML ได้ แต่ยังไม่รองรับการสร้าง ODB++ TGZ ใหม่กลับไปใช้กับซอฟต์แวร์ต้นทาง ส่วน TGZ/ZIP/TAR ที่ภายในเป็น CAD XML รองรับการเขียนกลับ Archive
