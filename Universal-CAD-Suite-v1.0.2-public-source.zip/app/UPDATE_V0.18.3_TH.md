# อัปเดต Universal CAD Studio v0.18.3

## แก้หน้า Mapping ใช้ CAD เดิม

- หน้า Mapping ใช้ CAD ที่ผ่านการแก้ไขล่าสุด
- ปุ่ม Mapping เปลี่ยนเป็น **Apply → Mapping**
- ซิงก์ชื่อ Land, พิกัด, ขนาด, Side, Component และ Land ที่เพิ่ม/ลบ
- ปิด Editor แล้วบันทึก state ที่แก้โดยอัตโนมัติ
- Validate ก่อนทับข้อมูล หากข้อมูลผิดจะคงอยู่ใน Editor เพื่อให้แก้ต่อ
- Rebuild Mapping, Viewer, Duplicate detector และ CAD Compare จากข้อมูลชุดใหม่
- คอลัมน์ **CAD Name** แสดงชื่อ CAD จริง ไม่ใช้ Alias เก่ามาทับชื่อ
- ก่อนวาดตาราง ระบบรีเฟรชชื่อและพิกัดจาก Active CAD อีกครั้ง

Cache ใหม่: `universal-cad-studio-v0.18.3`
