# Universal CAD Studio v0.25.1 — Large FABmaster CAD Hotfix

## ปัญหาที่พบจากไฟล์จริง

ไฟล์ `CAD_T99O089T00_045_20180921.zip` มี `FAB_T99O089T00_045_20180921.cad` ขนาด 271,523,369 bytes หลังแตก ZIP และเป็น FABmaster/Cadence A!/J!/S! จริง แต่ v0.25.0 กำหนด `MAX_SCAN_BYTES` ไว้ 120 MiB ทำให้ archive scanner ข้ามไฟล์ก่อนถึง FABmaster parser จึงรายงานเหมือนไม่พบ CAD ที่รองรับ

การเพิ่ม limit อย่างเดียวไม่ปลอดภัย เพราะไฟล์จริงมีประมาณ 3.84 ล้านบรรทัด หาก decode เป็น JavaScript string ทั้งไฟล์แล้ว `split()`/สร้าง row objects จะใช้หน่วยความจำมากและเสี่ยงค้าง UI

## การแก้ไข

- เพิ่ม `ZipArchive.openStream()` และ `readPrefix()` เพื่อ sniff และ decompress member แบบ stream
- เพิ่ม FABmaster large-file streaming parser
- เก็บเฉพาะ Component, Pad, Pin/Land และ Board Outline ที่ Working Model ต้องใช้
- Net/trace/graphic rows ที่ไม่รองรับจะไม่ถูกเก็บเป็น object แต่ยังรายงานชนิดข้อมูลที่ข้าม
- ไฟล์ `.cad/.fab` ขนาดใหญ่แบบ standalone probe เพียง 1 MiB แรกก่อนใช้ File.stream()
- Board bounds เลือก `BOARD GEOMETRY / OUTLINE` ก่อน J-record extents
- ไม่มีการเปลี่ยน Project schema และไม่มีการลบฟังก์ชัน v0.25.0

## ผลจากไฟล์จริง

- CAD member: 271,523,369 bytes
- Scanned lines: 3,844,879
- Components: 4,714
- Lands: 16,027
- Packages: 128
- Unit: mils
- Board: 313.500008 × 215.829896 mm
- Compatibility XML: ~3.79 MB

Source มี pin rows 6 รายการที่ `REFDES` ว่าง จึงไม่สามารถผูกกับ Component ได้และถูกข้ามโดยตั้งใจ
