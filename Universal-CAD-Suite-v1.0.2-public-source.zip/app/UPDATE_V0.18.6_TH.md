# อัปเดต v0.18.6

## Apply / Confirmation

- เปลี่ยนข้อความปุ่มจาก `Yes · Apply` เป็น `Yes-ยืนยัน`
- เพิ่มแอนิเมชันตอบรับทั้ง Yes และ No
- ปิด Confirm dialog ก่อนเริ่มงานหนัก
- Apply แบ่งงานเป็น Validate → Convert → XML Sync → Snapshot
- แสดงเปอร์เซ็นต์และขั้นตอนปัจจุบัน

## ป้องกันอาการค้าง

- เพิ่ม Task cancellation
- เพิ่มปุ่มยกเลิกงานและยกเลิกพร้อมปิด Editor
- ปุ่ม X ด้านบนยังใช้ได้ระหว่าง Busy
- งานที่ยกเลิกจะไม่ Apply ข้อมูลครึ่งหนึ่ง
- Busy state ถูกคืนค่าเสมอแม้เกิด Error หรือ Cancel

## Viewer / Mapping

- ใช้ Index สำหรับหา Land จาก Component ID + XML Land ID
- ไม่ Render หน้า Mapping ที่ซ่อนอยู่ระหว่าง Apply
- รีเฟรช Viewer/Mapping หลังปิด Editorเพื่อให้หน้าต่างปิดก่อนและไม่รู้สึกค้าง
- เก็บ XML ของข้อมูลที่แก้แล้วไว้ใน `editedText`

## Export

- Export XML แบ่งงานเป็นช่วงและยกเลิกได้
- Export Archive คืนข้อความและสถานะปุ่มเสมอเมื่อสำเร็จหรือผิดพลาด
