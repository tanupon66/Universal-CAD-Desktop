import assert from 'node:assert/strict';
import fs from 'node:fs';

const css = fs.readFileSync(new URL('../styles.css', import.meta.url), 'utf8');

assert(css.includes('Universal CAD Studio v0.23.0 — fill the whole CAD editing workspace'), 'workspace fill patch marker missing');
assert(/\.cad-editor-visual-workspace\s*\{[\s\S]*?grid-template-rows:\s*minmax\(0,\s*1fr\)/.test(css), 'workspace still reserves an empty auto row');
assert(/\.cad-studio-canvas-wrap\s*\{[\s\S]*?height:\s*100%/.test(css), 'canvas wrapper does not stretch to full height');
assert(/#cadEditorCanvas\s*\{[\s\S]*?position:\s*absolute[\s\S]*?inset:\s*0/.test(css), 'canvas is not pinned to all workspace edges');
assert(/\.cad-studio-main\s*\{[\s\S]*?overflow:\s*hidden/.test(css), 'main CAD grid can leak unused space');

console.log('CAD editor full-height workspace checks passed');
