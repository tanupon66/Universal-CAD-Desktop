import assert from 'node:assert/strict';
import { createTar, gzip, bytesFromText } from '../archive-reader.js';
import { readCadPackageFile } from '../archive-package.js';
import { parseInspectionXml } from '../parsers.js';

const eda = `UNITS=MM
PKG QFN4 0.5 -1 -1 1 1
PIN 1 S -0.5 -0.5 0 E S ID=1
RC -0.15 -0.15 0.3 0.3
PIN 2 S 0.5 -0.5 0 E S ID=2
RC -0.15 -0.15 0.3 0.3
PIN 3 S 0.5 0.5 0 E S ID=3
RC -0.15 -0.15 0.3 0.3
PIN 4 S -0.5 0.5 0 E S ID=4
RC -0.15 -0.15 0.3 0.3
`;
const top = `UNITS=MM
# CMP 0
CMP 0 10 20 0 N U1 MCU
TOP 0 9.5 19.5 0 N 0 0 1
TOP 1 10.5 19.5 0 N 0 0 2
TOP 2 10.5 20.5 0 N 0 0 3
TOP 3 9.5 20.5 0 N 0 0 4
`;
const bot = `UNITS=MM
CMP 0 30 40 180 M U2 MCU
TOP 0 29.5 39.5 0 N 0 0 A1
TOP 1 30.5 39.5 0 N 0 0 A2
`;
const tar = createTar([
  { path: 'demo/steps/pcb/eda/data', bytes: bytesFromText(eda) },
  { path: 'demo/steps/pcb/layers/comp_+_top/components', bytes: bytesFromText(top) },
  { path: 'demo/steps/pcb/layers/comp_+_bot/components', bytes: bytesFromText(bot) },
]);
const tgz = await gzip(tar);
const file = { name: 'demo.tgz', async arrayBuffer() { return tgz.buffer.slice(tgz.byteOffset, tgz.byteOffset + tgz.byteLength); } };
const pkg = await readCadPackageFile(file);
assert.equal(pkg.candidates[0].format, 'odb++');
assert.equal(pkg.candidates[0].odbInfo.components, 2);
assert.equal(pkg.candidates[0].odbInfo.lands, 6);
const parsed = parseInspectionXml(pkg.candidates[0].text);
assert.equal(parsed.components.length, 2);
assert.equal(parsed.totalLands, 6);
assert.equal(parsed.components[0].lands[0].width, 0.3);
assert.equal(parsed.components[1].lands[0].side, 'Bottom');
console.log('ODB++ TGZ conversion test passed');
