import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { detectCadFormat } from '../format-detector.js';
import { adaptCadText } from '../import-adapters.js';
import { __test as pcbAsciiTest } from '../pcb-ascii-formats.js';
import { readCadPackageFile } from '../archive-package.js';
import { createZip } from '../zip-reader.js';
import { parseInspectionXml } from '../parsers.js';

for (const fixture of [
  { file: 'sample-gencad.cad', format: 'gencad-1.4' },
  { file: 'sample-fabmaster.fab', format: 'fabmaster-ascii' },
]) {
  const url = new URL(`./fixtures/${fixture.file}`, import.meta.url);
  const text = await readFile(url, 'utf8');
  const bytes = new TextEncoder().encode(text);
  const detection = detectCadFormat({ name: fixture.file, bytes, text });
  assert.equal(detection.format, fixture.format, `${fixture.file}: content detector`);
  assert.equal(detection.supported, true);
  const adapted = adaptCadText(text, { fileName: fixture.file, detection });
  assert.equal(adapted.sourceFormat, fixture.format);
  assert.equal(adapted.components, 1);
  assert.equal(adapted.lands, 2);
  const parsed = parseInspectionXml(adapted.xmlText);
  assert.equal(parsed.components.length, 1);
  assert.equal(parsed.totalLands, 2);
  assert.equal(parsed.components[0].name, 'U1');
  assert.equal(parsed.components[0].packageName, 'PKG_TEST');

  const packageResult = await readCadPackageFile({ name: fixture.file, arrayBuffer: async () => bytes.buffer });
  assert.equal(packageResult.candidates[0]?.format, fixture.format, `${fixture.file}: package reader must route through adapter`);
  assert.match(packageResult.candidates[0]?.text, /<InspectionData/);
}

const nestedGenText = await readFile(new URL('./fixtures/sample-gencad.cad', import.meta.url), 'utf8');
const nestedZip = createZip([{ name: 'nested board/source board.cad', bytes: new TextEncoder().encode(nestedGenText) }, { name: 'notes/readme.txt', bytes: new TextEncoder().encode('keep me') }]);
const nestedPackage = await readCadPackageFile({ name: 'nested.zip', arrayBuffer: async () => nestedZip.buffer.slice(nestedZip.byteOffset, nestedZip.byteOffset + nestedZip.byteLength) });
assert.equal(nestedPackage.candidates[0]?.format, 'gencad-1.4', 'nested ZIP GenCAD candidate must be detected');
assert.match(nestedPackage.candidates[0]?.displayPath || '', /source board\.cad/);

const fabText = await readFile(new URL('./fixtures/sample-fabmaster.fab', import.meta.url), 'utf8');
assert.equal(detectCadFormat({ name: 'cadence-export.cad', text: fabText }).format, 'fabmaster-ascii', '.cad extension must not override A!/J!/S! content signature');
const genText = await readFile(new URL('./fixtures/sample-gencad.cad', import.meta.url), 'utf8');
assert.equal(detectCadFormat({ name: 'wrong-extension.fab', text: genText }).format, 'gencad-1.4', '.fab extension must not override GenCAD content signature');

assert.equal(pcbAsciiTest.sourceUnitFromGencad('UNITS USER 1000').toMm, 0.0254, 'common GenCAD USER 1000 scale');

const legacy = ':FABMASTER\n:BOARDINFO\nX\n:PARTLIST\nY\n';
const legacyDetection = detectCadFormat({ name: 'legacy.fab', text: legacy });
assert.equal(legacyDetection.format, 'fabmaster-legacy');
assert.equal(legacyDetection.supported, false, 'legacy FABmaster is detected but must not be falsely claimed as supported');
assert.throws(() => adaptCadText(legacy, { fileName: 'legacy.fab', detection: legacyDetection }), /legacy|variant/i);
assert.throws(() => adaptCadText('$HEADER\nGENCAD 1.4\nUNITS INCH\n$ENDHEADER\n$COMPONENTS\n$ENDCOMPONENTS\n$SHAPES\n$ENDSHAPES', { fileName: 'empty.cad' }), /Component|COMPONENTS/i, 'detected GenCAD must not create an empty successful project');
assert.throws(() => adaptCadText('A!REFDES!SYM_X!SYM_Y!\nJ!EMPTY!2026!0!0!1!1!1!MILLIMETERS!\nS!!!!', { fileName: 'empty.fab' }), /Component|placement/i, 'detected FABmaster must not create an empty successful project');
console.log('GenCAD 1.4 + FABmaster A!/J!/S! import adapters and package routing passed');
