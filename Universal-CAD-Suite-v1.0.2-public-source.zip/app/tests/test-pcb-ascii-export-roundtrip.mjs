import assert from 'node:assert/strict';
import { parseInspectionXml } from '../parsers.js';
import { createCadEditorModel } from '../cad-editor.js';
import { exportGenCad14, convertGenCadToInspectionXml, exportFabmasterAscii, convertFabmasterExtractToInspectionXml } from '../pcb-ascii-formats.js';

const source = `<?xml version="1.0"?><Inspection><BoardInformation Name="RT" Width="50" Height="30" Thickness="1.6"/><Components><ComponentInformation Id="1" Name="U1"><ComponentInformationItem ComponentNumberId="QFN32"/><PositionAngle CenterPosX="10" CenterPosY="20" Angle="90"/></ComponentInformation></Components><Lands><LandNumber LandId="11" Component="1" Name="A1" Side="Top"><Land Left="9.5" Top="20.5" Width="1" Length="0.5"/></LandNumber><LandNumber LandId="12" Component="1" Name="A2" Side="Top"><Land Left="10.5" Top="20.5" Width="1" Length="0.5"/></LandNumber></Lands></Inspection>`;
const model = createCadEditorModel(source);
const before = parseInspectionXml(source);
const nearly = (a, b, tolerance = 0.00005) => Math.abs(Number(a) - Number(b)) <= tolerance;

const cases = [
  {
    label: 'GenCAD 1.4', extension: '.cad', exportFn: exportGenCad14,
    importFn: (text) => convertGenCadToInspectionXml(text, { fileName: 'roundtrip.cad' }),
    signature: /\$HEADER[\s\S]*GENCAD 1\.4/,
  },
  {
    label: 'FABmaster ASCII', extension: '.fab', exportFn: exportFabmasterAscii,
    importFn: (text) => convertFabmasterExtractToInspectionXml(text, { fileName: 'roundtrip.fab' }),
    signature: /^A!REFDES!/m,
  },
];
for (const item of cases) {
  const exported = item.exportFn(model, { side: 'all', fileName: 'roundtrip', metadata: { appVersion: '0.25.1', revisionNumber: 1, exportTime: '2026-08-20T00:00:00.000Z' } });
  assert.equal(exported.extension, item.extension);
  assert.equal(exported.partial, true, 'writer must truthfully declare the current subset limitation');
  assert.match(exported.text, item.signature);
  const adapted = item.importFn(exported.text);
  const after = parseInspectionXml(adapted.xmlText);
  assert.equal(after.components.length, before.components.length, `${item.label}: component count`);
  assert.equal(after.totalLands, before.totalLands, `${item.label}: land count`);
  const a = after.components[0]; const b = before.components[0];
  assert.equal(a.name, b.name); assert.equal(a.packageName, b.packageName); assert.equal(a.angle, b.angle);
  assert(nearly(a.centerX, b.centerX), `${item.label}: centerX semantic round-trip`);
  assert(nearly(a.centerY, b.centerY), `${item.label}: centerY semantic round-trip`);
  assert.deepEqual(a.lands.map((land) => land.cadName), b.lands.map((land) => land.cadName), `${item.label}: land names`);
  for (let i = 0; i < a.lands.length; i += 1) {
    assert(nearly(a.lands[i].left, b.lands[i].left), `${item.label}: land ${i} left`);
    assert(nearly(a.lands[i].top, b.lands[i].top), `${item.label}: land ${i} top`);
    assert(nearly(a.lands[i].width, b.lands[i].width), `${item.label}: land ${i} width`);
    assert(nearly(a.lands[i].length, b.lands[i].length), `${item.label}: land ${i} length`);
  }
}
console.log('Inspection XML → GenCAD/FABmaster → re-import semantic subset round-trip passed');
