import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../styles.css', import.meta.url), 'utf8');
const app = fs.readFileSync(new URL('../app.js', import.meta.url), 'utf8');

assert(!/data-cad-menu-panel="tools"[^>]*cad-menu-dropdown-right/.test(html), 'Tools menu must not use right alignment near the left edge');
assert(app.includes('function positionCadEditorMenu(panel, trigger)'), 'viewport menu positioning function missing');
assert(app.includes('positionCadEditorMenu(panel, trigger);'), 'menu positioning is not called when opening');
assert(app.includes("window.addEventListener('resize', repositionOpenCadEditorMenu"), 'open menu must reposition after viewport resize');
assert(css.includes('max-width: calc(100vw - 16px)'), 'menu max width guard missing');
assert(css.includes('.cad-menu-dropdown-right {\n  left: 0;\n  right: auto;'), 'legacy right alignment override missing');

console.log('CAD menu viewport guard checks passed');
