import assert from 'node:assert/strict';
import { createGridMapExcelModel, buildGridMapExcelBlob } from '../grid-map-excel.js';
import { buildGeneratedLandMapPlan, detectLandGrid } from '../land-grid-mapper.js';
import { ZipArchive } from '../zip-reader.js';
import { parseXlsx } from '../parsers.js';

const lands=[]; let id=1;
for(let row=0;row<2;row+=1) for(let col=0;col<3;col+=1) lands.push({globalId:id++,cadName:`CAD-${String.fromCharCode(65+row)}${col+1}`,left:col*2,top:5-row*2,width:1,length:1,componentId:'1'});
const component={id:'1',uid:'component:1',name:'U1',packageName:'BGA6',lands};
const grid=detectLandGrid(component);
const plan=buildGeneratedLandMapPlan(grid,{
  namingMode:'grid',gapMode:'compact',rowStart:'A',columnStart:1,
  order:'row-major',reverseRows:false,reverseColumns:false,
});
const model=createGridMapExcelModel(component,{grid,plan,boardName:'TEST',metadata:{projectId:'test',revisionNumber:3,validationStatus:'passed'}});
assert.equal(model.cells.length,6);
assert.deepEqual(model.cells.map(cell=>cell.newName),['A1','A2','A3','B1','B2','B3']);
assert.deepEqual(model.cells.map(cell=>cell.cadName),['CAD-A1','CAD-A2','CAD-A3','CAD-B1','CAD-B2','CAD-B3']);
assert.equal(model.proposedCount,6);
const blob=await buildGridMapExcelBlob(model);
const bytes=new Uint8Array(await blob.arrayBuffer());
assert(bytes.length>5000);
const zip=new ZipArchive(bytes);
assert(zip.entries.has('xl/workbook.xml'));
const mapXml=await zip.read('xl/worksheets/sheet1.xml','text');
assert.match(mapXml,/A1/);
assert.match(mapXml,/CAD: CAD-A1/);
assert.match(mapXml,/Grid \/ Land Map/);
const parsed=await parseXlsx(bytes.buffer);
assert.deepEqual(parsed.sheets.map(sheet=>sheet.name),['Grid Land Map','Mapping Data']);
assert(parsed.sheets[1].rows.some(row=>row.includes('New preview')));
console.log(`Configurable generated-name ↔ CAD Land Excel export passed (${bytes.length} bytes, ${parsed.sheets.length} sheets)`);
