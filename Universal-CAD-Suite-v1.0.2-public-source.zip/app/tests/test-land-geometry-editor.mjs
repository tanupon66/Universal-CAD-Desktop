import assert from 'node:assert/strict';
import { createCadEditorModel, mergeLandRectangles, splitLandRectangle } from '../cad-editor.js';

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Inspection>
  <BoardInformation Name="B" Width="10" Height="10" Thickness="1" />
  <Components><ComponentInformation Id="1" Name="U1"><ComponentInformationItem ComponentNumberId="QFN" ComponentNumberRevision="A"/><PositionAngle CenterPosX="2" CenterPosY="1" Angle="0"/></ComponentInformation></Components>
  <Lands>
    <LandNumber LandId="1" Component="1" Name="A1" Side="Top"><Land Left="0" Top="2" Width="2" Length="2"/></LandNumber>
    <LandNumber LandId="2" Component="1" Name="A2" Side="Top"><Land Left="2" Top="2" Width="2" Length="2"/></LandNumber>
  </Lands>
</Inspection>`
const model = createCadEditorModel(xml);
const component = model.components[0];
const count = component.lands.length;
const pieces = splitLandRectangle(model, component, component.lands[0], { axis: 'x', ratio: 0.5 });
assert.equal(pieces.length, 2);
assert.equal(component.lands.length, count + 1);
assert.equal(pieces[0].width, 1);
assert.equal(pieces[1].width, 1);
const mergedSplit = mergeLandRectangles(model, component, pieces);
assert.equal(component.lands.length, count);
assert.equal(mergedSplit.width, 2);
const mergedAdjacent = mergeLandRectangles(model, component, component.lands);
assert.equal(component.lands.length, 1);
assert.equal(mergedAdjacent.width, 4);
assert.equal(model.changed, true);
console.log('CAD editor Land Cut ½ and safe Merge with undo-compatible mutations passed');
