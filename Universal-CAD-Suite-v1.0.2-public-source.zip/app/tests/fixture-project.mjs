import { readFile } from 'node:fs/promises';
import { createZip } from '../zip-reader.js';

function xmlEscape(value) {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function inlineCell(ref, value) {
  if (typeof value === 'number') return `<c r="${ref}"><v>${value}</v></c>`;
  return `<c r="${ref}" t="inlineStr"><is><t>${xmlEscape(value)}</t></is></c>`;
}
export async function createFixtureProjectZip() {
  const cadXml = await readFile(new URL('./sample-mini.xml', import.meta.url));
  const rows = [
    ['Reference', 'Package', 'Land', 'Measurement'],
    ['U1', 'BGA', 'A1', 10.1],
    ['U1', 'BGA', 'A2', 10.2],
    ['R1', '0402', '1', 9.9],
  ];
  const sheetRows = rows.map((row, rowIndex) => `<row r="${rowIndex + 1}">${row.map((value, colIndex) => inlineCell(`${String.fromCharCode(65 + colIndex)}${rowIndex + 1}`, value)).join('')}</row>`).join('');
  const workbook = `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets></workbook>`;
  const rels = `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
  const sheet = `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
  const xlsx = createZip([
    { name: 'xl/workbook.xml', bytes: new TextEncoder().encode(workbook) },
    { name: 'xl/_rels/workbook.xml.rels', bytes: new TextEncoder().encode(rels) },
    { name: 'xl/worksheets/sheet1.xml', bytes: new TextEncoder().encode(sheet) },
  ]);
  return createZip([
    { name: 'fixture/cad.xml', bytes: cadXml },
    { name: 'fixture/data.xlsx', bytes: xlsx },
  ]);
}
