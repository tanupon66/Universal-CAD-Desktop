import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { ZipArchive } from '../zip-reader.js';
import { parseInspectionXml } from '../parsers.js';
import { createFixtureProjectZip } from './fixture-project.mjs';

const source = process.argv[2];
const outer = new ZipArchive(source ? await fs.readFile(source) : await createFixtureProjectZip());
const xmlEntry = outer.find((entry) => /\.xml$/i.test(entry.name));
assert(xmlEntry, 'ZIP must contain XML');
const xml = parseInspectionXml(await outer.read(xmlEntry.name, 'text'));
const component = xml.components.find((item) => item.name === 'U1');
assert(component, 'Expected U1 in example CAD');
const lands = source ? component.lands : [
  ...component.lands,
  { ...component.lands[0], globalId: 99, cadName: component.lands[0].cadName },
];
const groups = new Map();
for (const land of lands) {
  const name = String(land.cadName || '').trim();
  if (!name) continue;
  if (!groups.has(name)) groups.set(name, []);
  groups.get(name).push(land);
}
const duplicates = new Map([...groups].filter(([, items]) => items.length > 1));
const duplicatePositions = [...duplicates.values()].reduce((sum, items) => sum + items.length, 0);
if (source) {
  assert.equal(duplicates.size, 1169);
  assert.equal(duplicatePositions, 2338);
} else {
  assert.equal(duplicates.size, 1);
  assert.equal(duplicatePositions, 2);
}
for (const items of duplicates.values()) {
  assert(items.length > 1);
  assert(items.every((land) => Number.isFinite(land.centerX) && Number.isFinite(land.centerY)));
}
console.log(JSON.stringify({ fixture: source ? 'external' : 'internal', component: component.name, duplicateGroups: duplicates.size, duplicatePositions }, null, 2));
