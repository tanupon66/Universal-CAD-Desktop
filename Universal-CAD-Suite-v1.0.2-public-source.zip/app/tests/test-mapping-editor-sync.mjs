import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

class ClassList {
  constructor() { this.values = new Set(); }
  add(...items) { items.forEach((item) => this.values.add(item)); }
  remove(...items) { items.forEach((item) => this.values.delete(item)); }
  toggle(item, force) {
    if (force === true) { this.values.add(item); return true; }
    if (force === false) { this.values.delete(item); return false; }
    if (this.values.has(item)) { this.values.delete(item); return false; }
    this.values.add(item); return true;
  }
  contains(item) { return this.values.has(item); }
}
const context = new Proxy({}, { get: (target, key) => target[key] || (target[key] = () => {}), set: (target, key, value) => (target[key] = value, true) });
class Element {
  constructor(id = '') {
    this.id = id; this.classList = new ClassList(); this.style = {}; this.value = ''; this.textContent = '';
    this.innerHTML = ''; this.disabled = false; this.checked = false; this.clientWidth = id.includes('Canvas') ? 900 : 180;
    this.clientHeight = id.includes('Canvas') ? 650 : 120; this.tagName = 'DIV'; this.options = []; this.dataset = {};
    this.offsetWidth = 180; this.offsetHeight = 36; this.title = '';
  }
  addEventListener() {}
  append(...items) { this.options.push(...items); }
  click() {}
  focus() {}
  blur() {}
  setAttribute(name, value) { this[name] = value; }
  getAttribute(name) { return this[name]; }
  getContext() { return context; }
  getBoundingClientRect() { return { left: 0, top: 0, width: this.clientWidth, height: this.clientHeight, right: this.clientWidth, bottom: this.clientHeight }; }
  setPointerCapture() {}
  closest() { return null; }
}
const elements = new Map();
const get = (id) => elements.has(id) ? elements.get(id) : (elements.set(id, new Element(id)), elements.get(id));
globalThis.document = {
  body: new Element('body'), activeElement: new Element('active'), fullscreenElement: null,
  getElementById: get, querySelector: () => new Element(), querySelectorAll: () => [],
  createElement: (tag) => { const item = new Element(); item.tagName = String(tag).toUpperCase(); return item; },
  createDocumentFragment: () => new Element(), addEventListener() {}, exitFullscreen: async () => {},
};
globalThis.window = { devicePixelRatio: 1, addEventListener() {}, confirm() { return true; } };
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true });
globalThis.requestAnimationFrame = (callback) => (callback(), 1);
globalThis.ResizeObserver = class { observe() {} };
globalThis.URL.createObjectURL = () => '';
globalThis.URL.revokeObjectURL = () => {};

const [{ state, syncMappingRowsFromActiveCad }, { createCadEditorModel }] = await Promise.all([
  import('../app.js'),
  import('../cad-editor.js'),
]);

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Inspection>
  <BoardInformation Name="Demo" Width="10" Height="10" Thickness="1" Units="MM" MinX="0" MinY="0" />
  <Components>
    <ComponentInformation Id="1" Name="U1"><ComponentInformationItem ComponentNumberId="BGA" ComponentNumberRevision="A"/><PositionAngle CenterPosX="2" CenterPosY="2" Angle="0"/></ComponentInformation>
  </Components>
  <Lands>
    <LandNumber LandId="1" Component="1" Name="OLD1" Side="Top"><Land Left="1" Top="3" Width="1" Length="1"/></LandNumber>
  </Lands>
</Inspection>`;

const model = createCadEditorModel(xml);
model.components[0].lands[0].cadName = 'NEW1';
model.components[0].lands[0].left = 4;
model.changed = true;
assert.equal(model.components[0].lands[0].cadName, 'NEW1');
assert.equal(model.components[0].lands[0].left, 4);

const liveLand = { componentId: '1', globalId: 1, cadName: 'NEW1', left: 4, top: 3, centerX: 4.5, centerY: 2.5, width: 1, length: 1, side: 'Top' };
const liveComponent = { id: '1', name: 'U1_EDITED', packageName: 'BGA_EDITED', lands: [liveLand] };
state.xmlData = { components: [liveComponent], componentById: new Map([['1', liveComponent]]), totalLands: 1, board: { Name: 'Demo' } };
state.mappingData = { mappings: [{ componentId: '1', globalId: 1, componentName: 'U1', packageName: 'BGA', cadName: 'OLD1', left: 1, top: 3, centerX: 1.5, centerY: 2.5, width: 1, length: 1, duplicateCadNameCount: 1 }] };
assert(syncMappingRowsFromActiveCad() > 0);
assert.equal(state.mappingData.mappings[0].cadName, 'NEW1');
assert.equal(state.mappingData.mappings[0].componentName, 'U1_EDITED');
assert.equal(state.mappingData.mappings[0].packageName, 'BGA_EDITED');
assert.equal(state.mappingData.mappings[0].left, 4);

const [app, html, sw] = await Promise.all([
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../sw.js', import.meta.url), 'utf8'),
]);
assert(app.includes('function commitCadEditorToProject'));
assert(app.includes('function syncMappingRowsFromActiveCad'));
assert(app.includes("mapping.cadName || '—'"));
assert(app.includes('const nextData = await cadEditorModelToDataAsync(model'));
assert(app.includes('file.appliedEditorSnapshot = snapshot'));
assert(app.includes('file.editedText = editedText'));
assert(app.includes('file.viewerDirty = true'));
assert(app.includes('syncMappingRowsFromActiveCad()'));
assert(app.includes('function requestCadEditorApply'));
assert(app.includes("showCadEditorConfirm('apply')"));
assert(app.includes("showCadEditorConfirm('discard'"));
assert(!html.includes('id="cadStudioMappingButton"'));
assert(!html.includes('Apply → Mapping'));
assert.equal((html.match(/id="cadEditorApplyButton"/g) || []).length, 1);
assert(sw.includes("const APP_VERSION = '0.26.0'") && sw.includes('CACHE_PREFIX'));
console.log('CAD Editor to Mapping synchronization static tests passed');
