import assert from 'node:assert/strict';
import { csvCell, protectSpreadsheetText, safeDownloadName, sanitizeSheetName } from '../export-safety.js';

for (const value of ['=1+1', '+SUM(A1:A2)', '-CMD()', '@HYPERLINK("x")', '*unsafe', '\tformula', '\rformula']) {
  assert.equal(protectSpreadsheetText(value).startsWith("'"), true, value);
}
assert.equal(protectSpreadsheetText(-12.5), -12.5, 'numeric negatives remain numeric');
assert.equal(protectSpreadsheetText('00123'), "'00123", 'leading zero reference is preserved as text');
assert.equal(csvCell('a,b'), '"a,b"');
assert.equal(csvCell('=1+1'), "'=1+1");
assert.equal(sanitizeSheetName('bad/name:*?[]'), 'bad name');
assert.equal(safeDownloadName('../../bad:name.csv'), 'bad_name.csv');
console.log('CSV/Excel formula injection, leading-zero and filename safety passed');
