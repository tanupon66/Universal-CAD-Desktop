import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  cadEditorModelToData,
  createCadEditorModel,
  serializeCadEditorModelStandalone,
  splitComponentLands,
  validateCadEditorModel,
} from '../cad-editor.js';
import { readCadPackageFile, rebuildCadPackage } from '../archive-package.js';
import { textFromBytes } from '../archive-reader.js';

const xml = await readFile(new URL('./sample-mini.xml', import.meta.url), 'utf8');
const model = createCadEditorModel(xml);
const source = model.components.find((component) => component.id === '1');
const movedLand = source.lands[1];
const split = splitComponentLands(model, source, new Set([movedLand.uid]), { name: 'U1_SPLIT1' });

assert.equal(model.components.length, 3);
assert.equal(source.lands.length, 1);
assert.equal(split.lands.length, 1);
assert.equal(split.lands[0], movedLand, 'Land เดิมต้องถูกย้าย ไม่ใช่สร้างสำเนา');
assert.equal(split.lands[0].globalId, 2, 'XML Land ID ต้องคงเดิม');
assert.equal(split.lands[0].componentId, split.id);
assert.equal(validateCadEditorModel(model).valid, true);
assert.throws(() => splitComponentLands(model, source, new Set(source.lands.map((land) => land.uid))), /At least one land must remain/);

const data = cadEditorModelToData(model);
assert.equal(data.totalLands, 3);
assert.equal(data.componentById.get(split.id).lands[0].globalId, 2);
const output = serializeCadEditorModelStandalone(model);
assert.match(output, new RegExp(`Component="${split.id}"[^>]*Name="A2"`));

// ไฟล์ XML ที่ใช้นามสกุลอื่นต้องยังเปิดและเขียนกลับได้ด้วย content detection
const disguisedFile = {
  name: 'board-data.dat',
  async arrayBuffer() { return new TextEncoder().encode(output).buffer; },
};
const packageInfo = await readCadPackageFile(disguisedFile);
assert.equal(packageInfo.root.kind, 'file');
assert.equal(packageInfo.candidates.length, 1);
const rebuilt = await rebuildCadPackage(packageInfo, packageInfo.candidates[0], output.replace('U1_SPLIT1', 'U1_SPLIT2'));
assert.match(textFromBytes(rebuilt), /U1_SPLIT2/);

// Unix compress (.Z) ระดับบนสุดต้องถูกคลายแล้วตรวจจับ XML ตามเนื้อหา
function literalUnixZ(text) {
  const input = new TextEncoder().encode(text);
  if (input.length > 255) throw new Error('test fixture must stay below 256 bytes');
  const bitLength = input.length * 9;
  const packed = new Uint8Array(3 + Math.ceil(bitLength / 8));
  packed.set([0x1f, 0x9d, 0x09]); // Unix compress, max 9-bit, non-block mode
  let bit = 0;
  for (const code of input) {
    const absolute = 24 + bit;
    const byteIndex = absolute >>> 3;
    const shift = absolute & 7;
    const value = code << shift;
    packed[byteIndex] |= value & 0xff;
    if (byteIndex + 1 < packed.length) packed[byteIndex + 1] |= (value >>> 8) & 0xff;
    if (byteIndex + 2 < packed.length) packed[byteIndex + 2] |= (value >>> 16) & 0xff;
    bit += 9;
  }
  return packed;
}
const tinyXml = '<LandNumber LandId="1"><Land/></LandNumber>';
const zBytes = literalUnixZ(tinyXml);
const zPackage = await readCadPackageFile({
  name: 'tiny.xml.Z',
  async arrayBuffer() { return zBytes.buffer.slice(zBytes.byteOffset, zBytes.byteOffset + zBytes.byteLength); },
});
assert.equal(zPackage.candidates.length, 1);
assert.equal(zPackage.candidates[0].text, tinyXml);
assert(zPackage.diagnostics.some((item) => item.includes('Unix compress (.Z)')));

console.log('land marquee split, direct XML-like file and Unix .Z tests passed');
