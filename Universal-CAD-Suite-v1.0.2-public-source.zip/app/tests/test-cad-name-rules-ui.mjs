import fs from 'node:fs/promises';
import assert from 'node:assert/strict';

const [html, app, css, sw, manifest] = await Promise.all([
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../styles.css', import.meta.url), 'utf8'),
  fs.readFile(new URL('../sw.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../manifest.webmanifest', import.meta.url), 'utf8'),
]);

for (const id of ['cadOverflowMode', 'cadDuplicateMode', 'cadDuplicateCharacter', 'cadRulePreview']) {
  assert(html.includes(`id="${id}"`), `missing ${id}`);
}
for (const value of ['keep-start', 'keep-end', 'replace-character', 'suffix', 'regenerate']) {
  assert(html.includes(`value="${value}"`), `missing option ${value}`);
}
for (const token of ['overflowMode: state.cadInspector.overflowMode', 'duplicateMode: state.cadInspector.duplicateMode', 'duplicateCharacter: state.cadInspector.duplicateCharacter']) {
  assert(app.includes(token), `missing rule wiring: ${token}`);
}
assert(app.includes('cadNameRules: { maxLength:'), 'backup CAD rule block missing');
assert(css.includes('.cad-rule-preview'), 'rule preview style missing');

assert(html.includes('<option selected="" value="all">All (including valid names)</option>'), 'name inspector must show normal names by default');
assert(app.includes("filter: 'all'"), 'CAD name inspector default filter must include valid names');
assert(app.includes("applyCadNamesToProject({ silent: true });"), 'CAD name changes must live-sync to the main viewer');
assert(app.includes("chip.textContent = item.changed ? 'Passed' : 'Normal'"), 'normal CAD names need an explicit normal status');
assert(html.includes('Sync Names to Viewer'), 'viewer sync action label missing');

assert(sw.includes("const APP_VERSION = '0.26.0'") && sw.includes('CACHE_PREFIX'), 'wrong service worker cache');
assert(JSON.parse(manifest).name.includes('v0.26.0'), 'wrong manifest version');
console.log('CAD name rule UI and persistence checks passed');
