import assert from 'node:assert/strict';
import { buildCadNameAudit, cadLandKey, generateCadRenames, truncateCadName } from '../cad-inspector.js';

const component = {
  id: 'C1', name: 'U1', packageName: 'QFN', lands: [
    { componentId: 'C1', globalId: 1, localIndex: 1, cadName: 'ABCDEFG' },
    { componentId: 'C1', globalId: 2, localIndex: 2, cadName: 'AB_CD' },
    { componentId: 'C1', globalId: 3, localIndex: 3, cadName: 'AB_CD' },
    { componentId: 'C1', globalId: 4, localIndex: 4, cadName: 'AB_CD' },
    { componentId: 'C1', globalId: 5, localIndex: 5, cadName: '' },
  ],
};
const xml = { components: [component] };

assert.equal(truncateCadName('ABCDEFG', 5, 'keep-start'), 'ABCDE');
assert.equal(truncateCadName('ABCDEFG', 5, 'keep-end'), 'CDEFG');
assert.equal(truncateCadName('ABCDEFG', 5, 'regenerate'), '');

const replaced = generateCadRenames(xml, new Map(), {
  maxLength: 5,
  overflowMode: 'keep-start',
  duplicateMode: 'replace-character',
  duplicateCharacter: '_',
});
assert.equal(replaced.renames.get(cadLandKey('C1', 1)), 'ABCDE');
assert.equal(replaced.renames.get(cadLandKey('C1', 3)), 'AB1CD');
assert.equal(replaced.renames.get(cadLandKey('C1', 4)), 'AB2CD');
assert.equal(buildCadNameAudit(xml, replaced.renames, { maxLength: 5 }).summary.unresolved, 0);

const keepEnd = generateCadRenames(xml, new Map(), {
  maxLength: 5,
  overflowMode: 'keep-end',
  duplicateMode: 'replace-character',
  duplicateCharacter: '_',
});
assert.equal(keepEnd.renames.get(cadLandKey('C1', 1)), 'CDEFG');
assert.equal(buildCadNameAudit(xml, keepEnd.renames, { maxLength: 5 }).summary.unresolved, 0);

const suffixXml = { components: [{
  id: 'C2', name: 'U2', lands: [
    { componentId: 'C2', globalId: 1, localIndex: 1, cadName: 'HELLO' },
    { componentId: 'C2', globalId: 2, localIndex: 2, cadName: 'HELLO' },
    { componentId: 'C2', globalId: 3, localIndex: 3, cadName: 'ABCDEZ' },
    { componentId: 'C2', globalId: 4, localIndex: 4, cadName: 'ABCDE' },
  ],
}] };
const suffix = generateCadRenames(suffixXml, new Map(), {
  maxLength: 5,
  overflowMode: 'keep-start',
  duplicateMode: 'suffix',
});
assert.equal(suffix.renames.get(cadLandKey('C2', 2)), 'HELL1');
assert.equal(suffix.renames.get(cadLandKey('C2', 3)), 'ABCD1');
assert.equal(buildCadNameAudit(suffixXml, suffix.renames, { maxLength: 5 }).summary.unresolved, 0);

console.log('CAD name trimming and duplicate-replacement rules passed');
