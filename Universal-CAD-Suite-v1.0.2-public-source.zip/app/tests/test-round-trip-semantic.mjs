import assert from 'node:assert/strict';
import { parseInspectionXml } from '../parsers.js';
import { createCadEditorModel, serializeCadEditorModelStandalone } from '../cad-editor.js';

const source = `<?xml version="1.0"?><Inspection><BoardInformation Name="RoundTrip" Width="50" Height="30" Thickness="1.6"/><Components><ComponentInformation Id="U1" Name="U1"><ComponentInformationItem ComponentNumberId="QFN32"/><PositionAngle CenterPosX="10" CenterPosY="20" Angle="90"/></ComponentInformation><ComponentInformation Id="R-A1" Name="R-A1"><ComponentInformationItem ComponentNumberId="0402"/></ComponentInformation></Components><Lands><LandNumber LandId="11" Component="U1" Name="A1" Side="Top"><Land Left="9.5" Top="20.5" Width="1" Length="1"/></LandNumber><LandNumber LandId="12" Component="U1" Name="A2" Side="Top"><Land Left="10.5" Top="20.5" Width="1" Length="1"/></LandNumber><LandNumber LandId="21" Component="R-A1" Name="1" Side="Bottom"><Land Left="4" Top="5" Width="0.4" Length="0.8"/></LandNumber></Lands></Inspection>`;
const before = parseInspectionXml(source);
const recoveredModel = createCadEditorModel(before);
assert.equal(recoveredModel.components.length, before.components.length, 'parsed CAD model must remain compatible with recovery/editor API');
assert.equal(recoveredModel.board.Name, before.board.Name);
const output = serializeCadEditorModelStandalone(createCadEditorModel(source));
const after = parseInspectionXml(output);
assert.equal(after.board.Name, before.board.Name);
assert.equal(after.components.length, before.components.length);
assert.equal(after.totalLands, before.totalLands);
const semantic = (data) => data.components.map((component) => ({
  id: String(component.id), name: component.name, packageName: component.packageName, centerX: component.centerX, centerY: component.centerY, angle: component.angle,
  lands: component.lands.map((land) => ({ id: Number(land.globalId), name: land.cadName, side: land.side, left: land.left, top: land.top, width: land.width, length: land.length })),
}));
assert.deepEqual(semantic(after), semantic(before));
console.log('Inspection XML import → export → re-import semantic compare passed');
