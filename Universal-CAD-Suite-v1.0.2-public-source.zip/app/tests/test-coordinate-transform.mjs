import assert from 'node:assert/strict';
import { applyMatrix, bottomSideTransform, composeTransform, convertUnit, normalizeRotation, panelInstanceMatrix } from '../coordinate-transform.js';
const near = (a,b) => assert.ok(Math.abs(a-b)<1e-9, `${a} != ${b}`);
near(convertUnit(25.4,'mm','inch'),1); near(convertUnit(1,'inch','mm'),25.4); near(convertUnit(1000,'mil','inch'),1);
assert.equal(normalizeRotation(-90),270); assert.equal(normalizeRotation(450),90);
let p=applyMatrix(composeTransform({origin:{x:1,y:2},position:{x:10,y:20},rotation:90}),{x:2,y:2}); near(p.x,10); near(p.y,21);
p=applyMatrix(bottomSideTransform({boardWidth:100,axis:'y'}),{x:20,y:5}); near(p.x,80); near(p.y,5);
p=applyMatrix(panelInstanceMatrix({position:{x:10,y:0},rotation:180,mirror:true},{origin:{x:0,y:0},units:'mm'}),{x:2,y:3}); near(p.x,12); near(p.y,-3);
console.log('central unit conversion and coordinate transformation matrix tests passed');
