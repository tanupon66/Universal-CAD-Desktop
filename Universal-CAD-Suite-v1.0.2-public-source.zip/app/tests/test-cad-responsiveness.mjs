import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import {
  cadEditorModelToData,
  cadEditorModelToDataAsync,
  cloneCadEditorModel,
  cloneCadEditorModelAsync,
  serializeCadEditorModelStandalone,
  serializeCadEditorModelStandaloneAsync,
  validateCadEditorModelAsync,
} from '../cad-editor.js';
import { parseInspectionXml } from '../parsers.js';

const componentCount = 15573;
const landTarget = 56782;
const components = [];
let globalId = 1;
const fourLandComponents = landTarget - componentCount * 3;
for (let index = 0; index < componentCount; index += 1) {
  const landCount = index < fourLandComponents ? 4 : 3;
  const lands = [];
  for (let landIndex = 0; landIndex < landCount; landIndex += 1) {
    const id = globalId++;
    lands.push({
      uid: `land:${id}`,
      originalComponentId: String(index + 1),
      originalGlobalId: id,
      globalId: id,
      componentId: String(index + 1),
      cadName: `A${landIndex + 1}`,
      side: index % 2 ? 'Bottom' : 'Top',
      left: index * 0.01 + landIndex * 0.2,
      top: index * 0.01,
      width: 0.1,
      length: 0.1,
      localIndex: landIndex + 1,
      isNew: false,
    });
  }
  components.push({
    uid: `component:${index + 1}`,
    originalId: String(index + 1),
    id: String(index + 1),
    name: `U${index + 1}`,
    packageName: 'PKG',
    revision: '',
    centerX: index * 0.01,
    centerY: index * 0.01,
    angle: 0,
    isNew: false,
    lands,
  });
}
const model = { board: { Width: 450, Height: 368, Thickness: 1.6 }, components, sourceText: '', sourceSize: 0, changed: true };

const syncStart = performance.now();
const syncSnapshot = cloneCadEditorModel(model);
const syncData = cadEditorModelToData(model);
const syncXml = serializeCadEditorModelStandalone(model, { side: 'all' });
const syncElapsed = performance.now() - syncStart;
assert.equal(syncSnapshot.components.length, componentCount);
assert.equal(syncData.totalLands, landTarget);
assert.equal(parseInspectionXml(syncXml).totalLands, landTarget);
assert(syncElapsed < 5000, `large-board synchronous primitives took ${syncElapsed.toFixed(1)}ms`);

let heartbeat = 0;
const timer = setInterval(() => { heartbeat += 1; }, 1);
const progress = [];
const options = { batchSize: 700, onProgress: ({ stage, ratio }) => progress.push([stage, ratio]) };
const asyncStart = performance.now();
const validation = await validateCadEditorModelAsync(model, options);
const asyncData = await cadEditorModelToDataAsync(model, options);
const asyncXml = await serializeCadEditorModelStandaloneAsync(model, { ...options, side: 'all' });
const asyncSnapshot = await cloneCadEditorModelAsync(model, options);
const asyncElapsed = performance.now() - asyncStart;
clearInterval(timer);

assert(validation.valid, validation.errors.slice(0, 3).join(' | '));
assert.equal(asyncData.totalLands, landTarget);
assert.equal(parseInspectionXml(asyncXml).totalLands, landTarget);
assert.equal(asyncSnapshot.components.length, componentCount);
assert(heartbeat > 5, `event loop did not remain responsive; heartbeat=${heartbeat}`);
assert(progress.some(([stage]) => stage === 'validate'));
assert(progress.some(([stage]) => stage === 'convert'));
assert(progress.some(([stage]) => stage === 'serialize'));
assert(progress.some(([stage]) => stage === 'snapshot'));
assert(asyncElapsed < 15000, `chunked large-board pipeline took ${asyncElapsed.toFixed(1)}ms`);

let cancel = false;
await assert.rejects(
  validateCadEditorModelAsync(model, {
    batchSize: 50,
    isCancelled: () => cancel,
    onProgress: ({ processed }) => { if (processed > 0) cancel = true; },
  }),
  (error) => error?.name === 'AbortError',
  'chunked validation must support cancellation',
);

console.log(`large-board responsive pipeline passed: sync ${syncElapsed.toFixed(1)}ms, async ${asyncElapsed.toFixed(1)}ms, heartbeat ${heartbeat}`);
