import assert from 'node:assert/strict';
import { bytesFromText, createTar, gzip, gunzip, parseTar, textFromBytes } from '../archive-reader.js';
import { readCadPackageFile, rebuildCadPackage, packageOutputInfo } from '../archive-package.js';
import { createZip, ZipArchive } from '../zip-reader.js';

const xml = `<?xml version="1.0"?><Inspection><BoardInformation Name="NestedDemo" Width="20" Height="10"/><Components><ComponentInformation Id="1" Name="U1"><ComponentInformationItem ComponentNumberId="BGA"/></ComponentInformation><ComponentInformation Id="2" Name="R1"><ComponentInformationItem ComponentNumberId="0402"/></ComponentInformation></Components><Lands><LandNumber LandId="1" Component="1" Name="A1" Side="Top"><Land Left="1" Top="2" Width="0.4" Length="0.4"/></LandNumber><LandNumber LandId="2" Component="2" Name="A1" Side="Bottom"><Land Left="5" Top="6" Width="0.3" Length="0.5"/></LandNumber></Lands></Inspection>`;
const meta = 'keep-this-metadata';
const tgz = await gzip(createTar([
  { path: 'job/cad/CAD_DATA.cpo', bytes: bytesFromText(xml) },
  { path: 'job/meta/settings.dat', bytes: bytesFromText(meta) },
]));
const outerBytes = createZip([
  { name: 'CPO/job-package.tgz', bytes: tgz },
  { name: 'CPO/readme.txt', bytes: bytesFromText('outer file') },
]);
const fakeFile = {
  name: 'CPO.zip',
  async arrayBuffer() { return outerBytes.buffer.slice(outerBytes.byteOffset, outerBytes.byteOffset + outerBytes.byteLength); },
};

const packageInfo = await readCadPackageFile(fakeFile);
assert.equal(packageInfo.root.kind, 'zip');
assert.equal(packageInfo.candidates.length, 1);
assert.match(packageInfo.candidates[0].displayPath, /CPO\.zip.*job-package\.tgz.*CAD_DATA\.cpo/);
assert.match(packageInfo.candidates[0].text, /NestedDemo/);
assert.deepEqual(packageOutputInfo(packageInfo, 'top'), { extension: '.zip', mime: 'application/zip', filename: 'CPO_top.zip', label: 'ZIP' });

const changedXml = xml.replace('NestedDemo', 'NestedDemoEdited').replace('Name="A1" Side="Top"', 'Name="A2" Side="Top"');
const rebuilt = await rebuildCadPackage(packageInfo, packageInfo.candidates[0], changedXml);
const rebuiltZip = new ZipArchive(rebuilt);
assert.equal(await rebuiltZip.read('CPO/readme.txt', 'text'), 'outer file');
const rebuiltTgz = await rebuiltZip.read('CPO/job-package.tgz', 'uint8array');
const rebuiltTarEntries = parseTar(await gunzip(rebuiltTgz));
assert.equal(textFromBytes(rebuiltTarEntries.find((entry) => entry.path === 'job/meta/settings.dat').bytes), meta);
const rebuiltXml = textFromBytes(rebuiltTarEntries.find((entry) => entry.path === 'job/cad/CAD_DATA.cpo').bytes);
assert.match(rebuiltXml, /NestedDemoEdited/);
assert.match(rebuiltXml, /Name="A2" Side="Top"/);
console.log('nested ZIP → TGZ → CAD XML round-trip passed');

const traversalZip = createZip([{ name: '../secret.xml', bytes: bytesFromText(xml) }]);
const traversalFile = { name: 'unsafe.zip', async arrayBuffer() { return traversalZip.buffer.slice(traversalZip.byteOffset, traversalZip.byteOffset + traversalZip.byteLength); } };
await assert.rejects(() => readCadPackageFile(traversalFile), /Unsafe path|ARCHIVE_PATH_TRAVERSAL/);
const traversalTar = createTar([{ path: '../secret.xml', bytes: bytesFromText(xml) }]);
const traversalTarFile = { name: 'unsafe.tar', async arrayBuffer() { return traversalTar.buffer.slice(traversalTar.byteOffset, traversalTar.byteOffset + traversalTar.byteLength); } };
await assert.rejects(() => readCadPackageFile(traversalTarFile), /Unsafe path|ARCHIVE_PATH_TRAVERSAL/);
console.log('archive path traversal rejection passed');
