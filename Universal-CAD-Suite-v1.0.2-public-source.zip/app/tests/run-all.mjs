import { readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const scripts = Object.entries(pkg.scripts).filter(([name]) => name.startsWith('test:') && !['test:all', 'test:external'].includes(name));
let passed = 0;
const failures = [];
for (const [name, command] of scripts) {
  const [bin, ...args] = command.split(/\s+/);
  const result = spawnSync(bin, args, { cwd: new URL('../', import.meta.url), stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.status === 0) passed += 1;
  else failures.push(name);
}
console.log(`test:all result: ${passed}/${scripts.length} scripts passed`);
if (failures.length) throw new Error(`Failed scripts: ${failures.join(', ')}`);
