import fs from 'node:fs/promises';
import assert from 'node:assert/strict';

const [html, app, css, sw, manifest] = await Promise.all([
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../styles.css', import.meta.url), 'utf8'),
  fs.readFile(new URL('../sw.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../manifest.webmanifest', import.meta.url), 'utf8'),
]);

for (const id of [
  'cadEditorOverlay', 'cadEditorCanvas', 'cadEditorSelectionBar', 'cadEditorContextMenu',
  'cadEditorRotateLeftButton', 'cadEditorRotateRightButton', 'cadEditorFlipSideButton',
  'cadEditorAlignLeftButton', 'cadEditorAlignCenterXButton', 'cadEditorAlignRightButton',
  'cadEditorAlignTopButton', 'cadEditorAlignCenterYButton', 'cadEditorAlignBottomButton',
  'cadEditorInfoType', 'cadEditorInfoName', 'cadEditorInfoPackage', 'cadEditorInfoSide',
  'cadEditorSnapToggle', 'cadEditorNudgeStep', 'cadEditorVisualSideFilter'
]) assert(html.includes(`id="${id}"`), `missing direct CAD control ${id}`);

for (const action of ['duplicate', 'rotate-left', 'rotate-right', 'flip-side', 'fit-selection', 'delete']) {
  assert(html.includes(`data-cad-action="${action}"`), `missing action ${action}`);
}

for (const fn of [
  'duplicateSelectedCadEditorComponents', 'copyCadEditorSelection', 'pasteCadEditorClipboard',
  'rotateCadEditorSelection', 'flipCadEditorSelectionSide', 'alignCadEditorSelection',
  'resizeCadEditorLandFromSnapshot', 'openCadEditorContextMenu', 'runCadEditorAction'
]) assert(app.includes(`function ${fn}`), `missing function ${fn}`);

assert(html.includes('cad-editor-legacy-controls hidden'), 'legacy entry form must stay hidden');
assert(css.includes('.cad-studio-shell'), 'missing CAD Studio shell');
assert(css.includes('.cad-studio-toolrail'), 'missing tool rail');
assert(css.includes('.cad-studio-dock'), 'missing right dock');
assert(css.includes('.cad-context-menu'), 'missing context menu style');
assert(sw.includes("const APP_VERSION = '0.26.0'") && sw.includes('CACHE_PREFIX'), 'wrong service worker cache');
assert(JSON.parse(manifest).name.includes('v0.26.0'), 'wrong manifest version');
console.log('CAD Studio v0.26.0 direct-workflow checks passed');
