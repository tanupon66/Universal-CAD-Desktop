import assert from 'node:assert/strict';
import { convertFabmasterStreamToInspectionXml } from '../pcb-ascii-formats.js';
import { parseInspectionXml } from '../parsers.js';

const j = 'J!source.brd!Thu Jan 01 00:00:00 2026!-50000!-50000!50000!50000!0.01!mils!TEST!';
const lines = [
  'A!REFDES!COMP_CLASS!COMP_PART_NUMBER!COMP_HEIGHT!COMP_DEVICE_LABEL!COMP_INSERTION_CODE!SYM_TYPE!SYM_NAME!SYM_MIRROR!SYM_ROTATE!SYM_X!SYM_Y!REFDES!REFDES!COMP_VOLTAGE!',
  j,
  'S!U1!IC!!!!!PACKAGE!BGA_TEST!NO!0!100!100!U1!U1!!',
  'S!R1!DISCRETE!!!!!PACKAGE!R_0402!YES!90!200!200!R1!R1!!',
  'A!PAD_NAME!REC_NUMBER!LAYER!FIXFLAG!VIAFLAG!PADSHAPE1!PADWIDTH!PADHGHT!PADXOFF!PADYOFF!PADFLASH!PADSHAPENAME!',
  j,
  'S!PAD_A!1!TOP!!!RECTANGLE!20!30!0!0!!!',
  'S!PAD_B!1!TOP!!!RECTANGLE!10!10!0!0!!!',
  'A!SYM_NAME!SYM_MIRROR!PIN_NAME!PIN_NUMBER!PIN_X!PIN_Y!PAD_STACK_NAME!REFDES!PIN_ROTATION!TEST_POINT!',
  j,
  'S!BGA_TEST!NO!A1!A1!100!100!PAD_A!U1!0!!',
  'S!BGA_TEST!NO!A2!A2!120!100!PAD_A!U1!0!!',
  'S!R_0402!YES!1!1!200!200!PAD_B!R1!0!!',
  'A!CLASS!SUBCLASS!GRAPHIC_DATA_NAME!GRAPHIC_DATA_NUMBER!RECORD_TAG!GRAPHIC_DATA_1!GRAPHIC_DATA_2!GRAPHIC_DATA_3!GRAPHIC_DATA_4!GRAPHIC_DATA_5!GRAPHIC_DATA_6!GRAPHIC_DATA_7!GRAPHIC_DATA_8!GRAPHIC_DATA_9!NET_NAME!',
  j,
];
for (let i = 0; i < 20000; i += 1) lines.push(`S!ETCH!TOP!LINE!257!${i}!0!0!1!1!5!!!!!N${i}!`);
// Actual board profile is 0..1000 x 0..500 mil; J extents above are deliberately huge.
lines.push(
  'S!BOARD GEOMETRY!OUTLINE!LINE!257!B1!0!0!1000!0!0!!!!!!',
  'S!BOARD GEOMETRY!OUTLINE!LINE!257!B2!1000!0!1000!500!0!!!!!!',
  'S!BOARD GEOMETRY!OUTLINE!LINE!257!B3!1000!500!0!500!0!!!!!!',
  'S!BOARD GEOMETRY!OUTLINE!LINE!257!B4!0!500!0!0!0!!!!!!',
  '\u001a',
);
const bytes = new TextEncoder().encode(lines.join('\r\n'));
// Deliberately chunk the stream across arbitrary line boundaries.
const stream = new ReadableStream({
  start(controller) {
    for (let offset = 0; offset < bytes.length; offset += 1379) controller.enqueue(bytes.subarray(offset, Math.min(bytes.length, offset + 1379)));
    controller.close();
  },
});
const progress = [];
const result = await convertFabmasterStreamToInspectionXml(stream, { fileName: 'large-sample.cad', totalBytes: bytes.length, onProgress: (item) => progress.push(item) });
assert.equal(result.streaming, true);
assert.equal(result.components, 2);
assert.equal(result.lands, 3);
assert.equal(result.unit, 'mils');
assert(result.scannedLines >= 20015);
assert(result.warnings.some((warning) => /BOARD GEOMETRY \/ OUTLINE/.test(warning)));
assert(result.warnings.some((warning) => /skipped 20000 records/.test(warning)));
const parsed = parseInspectionXml(result.xmlText);
assert.equal(parsed.components.length, 2);
assert.equal(parsed.totalLands, 3);
assert(Math.abs(parsed.board.Width - 25.4) < 1e-9, `board width ${parsed.board.Width}`);
assert(Math.abs(parsed.board.Height - 12.7) < 1e-9, `board height ${parsed.board.Height}`);
assert(progress.length > 0);
console.log(`large FABmaster streaming parser passed: ${result.scannedLines} lines, ${result.components} components, ${result.lands} lands`);
