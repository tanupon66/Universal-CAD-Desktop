import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { componentBounds, moveComponent, moveLand } from '../cad-editor.js';

const [html, app, css] = await Promise.all([
  fs.readFile(new URL('../index.html', import.meta.url), 'utf8'),
  fs.readFile(new URL('../app.js', import.meta.url), 'utf8'),
  fs.readFile(new URL('../styles.css', import.meta.url), 'utf8'),
]);
for (const id of ['cadEditorCanvas','cadEditorSelectTool','cadEditorPanTool','cadEditorComponentMode','cadEditorLandMode','cadEditorVisualSearch','cadEditorPropertyTitle']) {
  assert(html.includes(`id="${id}"`), `missing ${id}`);
}
for (const fn of ['drawCadEditorCanvas','hitCadEditorComponent','componentsInsideCadEditorMarquee','cadEditorPointerDown','moveSelectedCadEditorComponents']) {
  assert(app.includes(`function ${fn}`), `missing ${fn}`);
}
assert(css.includes('CAD/EDA direct-manipulation editor base'));
assert(css.includes('Universal CAD Studio v0.23.0'));
assert(css.includes('#cadEditorCanvas'));
assert(html.includes('drag') || html.includes('Drag'));

const component = {
  centerX: 1,
  centerY: 2,
  lands: [
    { left: 0, top: 3, width: 1, length: 1 },
    { left: 2, top: 2, width: .5, length: .5 },
  ],
};
assert.deepEqual(componentBounds(component), { minX: 0, minY: 1.5, maxX: 2.5, maxY: 3, width: 2.5, height: 1.5, centerX: 1.25, centerY: 2.25 });
moveComponent(component, 4, -1);
assert.equal(component.centerX, 5);
assert.equal(component.centerY, 1);
assert.equal(component.lands[0].left, 4);
assert.equal(component.lands[0].top, 2);
moveLand(component.lands[1], -.5, .25);
assert.equal(component.lands[1].left, 5.5);
assert.equal(component.lands[1].top, 1.25);
console.log('graphical CAD editor tests passed');
