import assert from 'node:assert/strict';
import { createTar, parseTar, bytesFromText, textFromBytes, gzip, gunzip, findCadXmlEntries } from '../archive-reader.js';
import {
  addComponent,
  addLand,
  createCadEditorModel,
  deleteLand,
  modelSummary,
  renumberAllComponentsA1,
  validateCadEditorModel,
} from '../cad-editor.js';
import { generateCadRenames, cadLandKey } from '../cad-inspector.js';
import { parseInspectionXml } from '../parsers.js';

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Inspection>
  <BoardInformation Name="Demo" Width="10" Height="10" Thickness="1" />
  <Components>
    <ComponentInformation Id="1" Name="U1"><ComponentInformationItem ComponentNumberId="BGA" ComponentNumberRevision="A"/><PositionAngle CenterPosX="1" CenterPosY="1" Angle="0"/></ComponentInformation>
    <ComponentInformation Id="2" Name="R1"><ComponentInformationItem ComponentNumberId="0402" ComponentNumberRevision=""/><PositionAngle CenterPosX="3" CenterPosY="3" Angle="90"/></ComponentInformation>
  </Components>
  <Lands>
    <LandNumber LandId="1" Component="1" Name="OLD1" Side="Top"><Land Left="0" Top="1" Width="0.4" Length="0.4"/></LandNumber>
    <LandNumber LandId="2" Component="1" Name="OLD2" Side="Top"><Land Left="1" Top="1" Width="0.4" Length="0.4"/></LandNumber>
    <LandNumber LandId="3" Component="2" Name="P1" Side="Bottom"><Land Left="2" Top="3" Width="0.3" Length="0.5"/></LandNumber>
    <LandNumber LandId="4" Component="2" Name="P2" Side="Bottom"><Land Left="3" Top="3" Width="0.3" Length="0.5"/></LandNumber>
  </Lands>
</Inspection>`;

const parsed = parseInspectionXml(xml);
const renames = generateCadRenames(parsed, new Map(), { renameAll: true, maxLength: 5 });
assert.equal(renames.renames.get(cadLandKey('1', 1)), 'A1');
assert.equal(renames.renames.get(cadLandKey('1', 2)), 'A2');
assert.equal(renames.renames.get(cadLandKey('2', 3)), 'A1');
assert.equal(renames.renames.get(cadLandKey('2', 4)), 'A2');

const orphanXml = `<?xml version="1.0"?><Inspection><BoardInformation Name="Orphan"/><Lands><LandNumber LandId="99" Component="404" Name="A1" Side="Top"><Land Left="0" Top="0" Width="1" Length="1"/></LandNumber></Lands></Inspection>`;
const orphanParsed = parseInspectionXml(orphanXml);
assert.equal(orphanParsed.components.length, 1);
assert.equal(orphanParsed.components[0].id, '404');
assert.equal(orphanParsed.components[0].lands.length, 1);
assert.equal(createCadEditorModel(orphanXml).components[0].isNew, true);

const model = createCadEditorModel(xml);
assert.deepEqual(modelSummary(model), { components: 2, lands: 4, top: 2, bottom: 2, unknown: 0 });
assert.equal(renumberAllComponentsA1(model), 4);
assert.deepEqual(model.components[0].lands.map((land) => land.cadName), ['A1', 'A2']);
assert.deepEqual(model.components[1].lands.map((land) => land.cadName), ['A1', 'A2']);
const c3 = addComponent(model, { name: 'C1', packageName: '0603' });
const newLand = addLand(model, c3, { side: 'Top' });
assert.equal(newLand.cadName, 'A1');
assert.equal(validateCadEditorModel(model).valid, true);
assert.equal(deleteLand(model, c3, newLand), true);
assert.equal(modelSummary(model).components, 3);

const tar = createTar([
  { path: 'project/cad.xml', bytes: bytesFromText(xml) },
  { path: 'project/meta.txt', bytes: bytesFromText('metadata') },
]);
const tarEntries = parseTar(tar);
assert.equal(tarEntries.length, 2);
assert.equal(textFromBytes(tarEntries.find((entry) => entry.path === 'project/meta.txt').bytes), 'metadata');
const candidates = findCadXmlEntries(tarEntries);
assert.equal(candidates[0].path, 'project/cad.xml');
const compressed = await gzip(tar);
const restored = await gunzip(compressed);
assert.equal(restored.length, tar.length);
assert.equal(parseTar(restored).length, 2);

const longPath = `project/${'very-long-folder/'.repeat(12)}cad.xml`;
const longTar = createTar([{ path: longPath, bytes: bytesFromText(xml) }]);
assert.equal(parseTar(longTar)[0].path, longPath);

console.log('universal CAD editor and TGZ tests passed');
