import assert from 'node:assert/strict';
import { detectDelimiter, parseDelimitedText, parseNumericCoordinate } from '../delimited-import.js';

const csv = '\uFEFFRefDes,Package,X,Y,Rotation,Part Number\r\n"U1","QFN,32",-1.25,2.5e1,90,00123\r\nR2,0402,3.5,-4.2,0,PN-2';
assert.equal(detectDelimiter(csv), ',');
const parsed = parseDelimitedText(csv, { fileName: 'placement.csv' });
assert.equal(parsed.format, 'cad-xy-bom-delimited');
assert.equal(parsed.rowCount, 2);
assert.equal(parsed.activeSheet.rows[1][1], 'QFN,32');
assert.equal(parsed.activeSheet.rows[1][5], '00123');
assert.equal(parseNumericCoordinate('-1.2e-3'), -0.0012);
assert.equal(parseNumericCoordinate('12,5'), 12.5);
const semicolon = parseDelimitedText('Reference;X (mm);Y (mm)\nU1;-1,25;2,50', { fileName: 'xy.txt' });
assert.equal(semicolon.delimiter, ';');
assert.equal(semicolon.unit, 'mm');
assert.throws(() => parseDelimitedText('A,B\n"x,y', { fileName: 'bad.csv' }), /quoted field/);
console.log('CSV/TXT XY/BOM parser handles BOM, quotes, CRLF, negatives, scientific notation and decimal comma');
