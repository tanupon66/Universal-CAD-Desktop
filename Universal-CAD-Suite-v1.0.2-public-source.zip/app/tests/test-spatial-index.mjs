import assert from 'node:assert/strict';
import { buildLandSpatialIndex, PointSpatialIndex } from '../spatial-index.js';
const index=new PointSpatialIndex(1); index.insert(0,0,'A'); index.insert(10,10,'B'); assert.deepEqual(index.queryRadius(.2,.1,.5).map(x=>x.value),['A']); assert.equal(index.queryRadius(5,5,1).length,0);
const land={centerX:1,centerY:2}; const built=buildLandSpatialIndex([{lands:[land]}]); assert.equal(built.queryRadius(1,2,.01)[0].value,land);
console.log('spatial index query avoids full component scan');
