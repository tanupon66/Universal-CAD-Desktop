import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const root = new URL('../', import.meta.url);
const [html, app, detector, adapters, precache, pkgText] = await Promise.all([
  readFile(new URL('index.html', root), 'utf8'), readFile(new URL('app.js', root), 'utf8'),
  readFile(new URL('format-detector.js', root), 'utf8'), readFile(new URL('import-adapters.js', root), 'utf8'),
  readFile(new URL('precache-manifest.js', root), 'utf8'), readFile(new URL('package.json', root), 'utf8'),
]);
const pkg = JSON.parse(pkgText);
assert.equal(pkg.version, '0.26.0');
assert(html.includes('.fab,.gcd'), 'file inputs must accept .fab/.gcd');
assert(html.includes('id="cadEditorExportFormat"'));
assert(html.includes('value="gencad-1.4"') && html.includes('value="fabmaster-ascii"'));
assert(html.includes('data-cad-command="export-gencad"') && html.includes('data-cad-command="export-fabmaster"'));
assert(app.includes("from './pcb-ascii-formats.js'"));
assert(app.includes('requestCadEditorSelectedExport'));
assert(app.includes("case 'export-gencad'") && app.includes("case 'export-fabmaster'"));
assert(app.includes("sourceFormat === 'gencad-1.4'") && app.includes("sourceFormat === 'fabmaster-ascii'"), 'archive rebuild must write back the original text format instead of inserting XML under .cad/.fab');
assert(app.includes("!['inspection-xml', 'gencad-1.4', 'fabmaster-ascii'].includes(sourceFormat)"), 'archive writer must block converted formats without a matching writer');
assert(detector.includes("format = 'gencad-1.4'") && detector.includes("format = 'fabmaster-ascii'"));
assert(adapters.includes("detection.format === 'gencad-1.4'") && adapters.includes("detection.format === 'fabmaster-ascii'"));
assert(precache.includes('./pcb-ascii-formats.js'), 'offline source precache must include new runtime module');
console.log('v0.25 CAD/FAB static wiring and offline module coverage passed');
