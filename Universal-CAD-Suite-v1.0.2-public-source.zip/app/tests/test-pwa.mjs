import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const manifest = JSON.parse(await readFile(path.join(root, 'manifest.webmanifest'), 'utf8'));
const sw = await readFile(path.join(root, 'sw.js'), 'utf8');
const app = await readFile(path.join(root, 'app.js'), 'utf8');
const precacheText = await readFile(path.join(root, 'precache-manifest.js'), 'utf8');
const match = precacheText.match(/=\s*(\[[\s\S]*\]);/);
assert(match, 'precache manifest must expose an asset array');
const assets = JSON.parse(match[1]);
assert.equal(manifest.version, '0.26.0');
assert.equal(manifest.start_url, './');
assert.equal(manifest.scope, './');
assert.equal(manifest.display, 'standalone');
assert.equal(manifest.id, './');
assert(Array.isArray(manifest.icons) && manifest.icons.length >= 2);
for (const icon of manifest.icons) await stat(path.join(root, icon.src.replace(/^\.\//, '')));
for (const required of ['./', './index.html', './app.js', './styles.css', './manifest.webmanifest']) assert(assets.includes(required), `missing ${required} from precache`);
for (const asset of assets.filter((item) => item !== './')) await stat(path.join(root, asset.replace(/^\.\//, '')));
const imports = new Set();
for (const sourceName of assets.filter((item) => item.endsWith('.js') && !item.endsWith('sw.js') && !item.endsWith('precache-manifest.js'))) {
  const source = await readFile(path.join(root, sourceName.replace(/^\.\//, '')), 'utf8');
  for (const found of source.matchAll(/from\s+['"](\.\/[^'"]+)['"]/g)) imports.add(found[1]);
}
for (const imported of imports) assert(assets.includes(imported), `runtime module ${imported} is not precached`);
assert(sw.includes("importScripts('./precache-manifest.js')"));
assert(sw.includes("const APP_VERSION = '0.26.0'"));
assert(sw.includes("type === 'SKIP_WAITING'"));
assert(sw.includes("request.mode === 'navigate'"));
assert(sw.includes("caches.match('./index.html')"));
assert(app.includes("updateViaCache: 'none'"));
assert(app.includes("registration.addEventListener('updatefound'"));
assert(app.includes("navigator.serviceWorker.addEventListener('controllerchange'"));
console.log(`PWA manifest, ${assets.length} precache assets, update flow and offline fallback checks passed`);
