# XML Compatibility Report — v0.25.2

Compared: Universal CAD v0.25.x XML, ePM-readable reference XML, and the v0.25.2 fixed export.

## Structural result

- Old UniversalCAD root: `InspectionData`
- ePM reference root: `DataList`
- v0.25.2 fixed root: `DataList`
- Unique element types: old=9, ePM=30, fixed=30
- Element types missing from fixed compared with ePM: none
- Extra element types in fixed compared with ePM: none

## Core attribute compatibility

- `DataList`: fixed=['FormatVersion']; ePM=['FormatVersion']; match=True
- `InspectionProject`: fixed=['CreationDateTime', 'ODBFolderPath', 'UpdateDateTime']; ePM=['CreationDateTime', 'ODBFolderPath', 'UpdateDateTime']; match=True
- `BoardInformation`: fixed=['Height', 'MaskThickness', 'Name', 'ReferencePositionX', 'ReferencePositionY', 'Side', 'Thickness', 'Width']; ePM=['Height', 'MaskThickness', 'Name', 'ReferencePositionX', 'ReferencePositionY', 'Side', 'Thickness', 'Width']; match=True
- `ComponentInformation`: fixed=['Id', 'Name']; ePM=['Id', 'Name']; match=True
- `ComponentInformationItem`: fixed=['ComponentNumberId', 'ComponentNumberRevision']; ePM=['ComponentNumberId', 'ComponentNumberRevision']; match=True
- `PositionAngle`: fixed=['Angle', 'CenterPosX', 'CenterPosY']; ePM=['Angle', 'CenterPosX', 'CenterPosY']; match=True
- `ComponentNumber`: fixed=['ComponentNumberId', 'ComponentType']; ePM=['ComponentNumberId', 'ComponentType']; match=True
- `ComponentWindow`: fixed=['Height', 'Length', 'Width']; ePM=['Height', 'Length', 'Width']; match=True
- `ElectrodeGroupInComponentNumber`: fixed=['ElectrodeType', 'Height', 'KneePosRatio', 'Length', 'PinGroupId', 'ToePosRatio', 'Width']; ePM=['ElectrodeType', 'Height', 'KneePosRatio', 'Length', 'PinGroupId', 'ToePosRatio', 'Width']; match=True
- `LandNumber`: fixed=['Component', 'LandId', 'Name', 'Side']; ePM=['Component', 'LandId', 'Name', 'Side']; match=True
- `Land`: fixed=['Left', 'Length', 'Top', 'Width']; ePM=['Left', 'Length', 'Top', 'Width']; match=True
- `Feature`: fixed=['Clockwise', 'Command', 'Type', 'X1', 'X2', 'Y1', 'Y2']; ePM=['Clockwise', 'Command', 'Type', 'X1', 'X2', 'Y1', 'Y2']; match=True

## Numeric precision

- old: PositionAngle.CenterPosX=14, PositionAngle.CenterPosY=3, PositionAngle.Angle=0, Land.Left=14, Land.Top=14, Land.Width=15, Land.Length=16
- ePM: PositionAngle.CenterPosX=3, PositionAngle.CenterPosY=3, PositionAngle.Angle=5, Land.Left=3, Land.Top=3, Land.Width=3, Land.Length=3
- fixed: PositionAngle.CenterPosX=3, PositionAngle.CenterPosY=3, PositionAngle.Angle=1, Land.Left=3, Land.Top=3, Land.Width=2, Land.Length=2

## Fixed sample counts

- Components: 1
- Lands: 72
- Features: 360 (5 per Land)
- Component/Land export IDs are sequential and relationships are rewritten consistently.
- Machine XML contains no UniversalCAD metadata comment before `DataList`.

## Important limitation

This verifies structural compatibility against the supplied ePM XML and eliminates floating-point serialization artifacts. It does not prove acceptance by the physical machine; that still requires an import test on the target software.