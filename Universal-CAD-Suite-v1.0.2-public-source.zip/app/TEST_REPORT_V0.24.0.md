# Test Report — Universal CAD Studio v0.24.0

Run date: 2026-07-31 UTC  
Environment: Node.js v22.16.0, npm 10.9.2  
Source commit: unavailable because the provided source archive did not contain `.git` metadata

## Summary

| Command | Result | Passed | Failed | Skipped | Notes |
|---|---|---:|---:|---:|---|
| `npm run typecheck` | Passed | 89 modules | 0 | 0 | `node --check` for JavaScript modules |
| `npm run lint` | Passed | policy gate | 0 | 0 | One review warning for controlled legacy `innerHTML` |
| `npm run test:all` | Passed | 47 scripts | 0 | 0 | Unit, static, integration and PWA tests |
| `npm run build` | Passed | 1 build | 0 | 0 | Static production package v0.24.0 |
| `npm run verify:production` | Passed | 40 assets | 0 | 0 | HTTP, MIME, manifest, build metadata and precache |
| `npm run verify:grid-map-input -- /mnt/data/R4125-B0013-02_R01_ODB-A_top_bottom.xml U56_3` | Passed | 1 actual file | 0 | 0 | 8×9, 72 Lands, 0 missing, 0 collision |
| Artifact Tool Excel inspection | Passed | 2 sheets | 0 | 0 | No formula errors; key ranges inspected and rendered |

## Focused v0.24.0 regression coverage

- Generated Grid alias `A1/A2/B1...` mapped to unchanged CAD Land name
- Generated `LAND 1...N` and number-only formats
- Row start, column start, column step, sequence start, step and zero padding
- Prefix, separator and suffix
- Row-major and column-major traversal
- Top-to-bottom, bottom-to-top, left-to-right and right-to-left
- Bottom-right start produces `A1` on the selected bottom-right CAD Land
- Compact mode skips empty physical cells without consuming a label
- Physical mode preserves coordinate gaps
- Manual override changes one generated alias without changing `cadName`
- Duplicate/blank generated names block Apply and Excel export
- Grid/Land mapping persistence fields are present in Autosave/Backup/JSON export
- Obsolete external-source Grid controls are absent
- PowerPoint and standalone Land Map export remain absent

## Actual uploaded XML result

- Board: `R4125-B0013-02_R01_ODB`
- Component: `U56_3`
- Package: `LGA72_354X394_P0433_V3`
- Detected Grid: 8 rows × 9 columns
- Lands: 72
- Missing cells: 0
- Grid collisions: 0
- App-generated Excel: `Grid Land Map` and `Mapping Data`

## Excel verification

The sample was generated with:

- Format: `LAND 1...72`
- Start corner: bottom-right
- Traversal: row-major
- Row direction: bottom-to-top
- Column direction: right-to-left

Verified mapping begins with `LAND 1 ↔ H9` and ends with `LAND 72 ↔ A1`.

Artifact Tool inspection results:

- `Grid Land Map!A1:J22`
- `Mapping Data!A1:Q74`
- Formula error scan: 0 matches
- Visual render completed successfully

## Test limitations

- No physical SMT machine or proprietary machine-program simulator was available.
- Interactive installation/offline reload was not tested on the user's target device; static PWA, Service Worker and HTTP production verification passed.
- The uploaded XML has a complete regular Grid; irregular 6,807-Land behavior is covered by the existing synthetic non-confidential fixture.

Full stdout/stderr is stored in `FINAL_TEST_LOG_V0.24.0.txt`.
