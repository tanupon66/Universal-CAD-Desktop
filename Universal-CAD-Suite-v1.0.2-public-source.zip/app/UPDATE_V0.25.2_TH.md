# อัปเดต v0.25.2

Hotfix สำหรับ XML ที่เครื่องอ่านไม่ได้:

- เปลี่ยน XML Export จาก internal `InspectionData` เป็นโครงสร้าง VT-X/ePM `DataList`.
- เพิ่ม collection และ hierarchy ที่พบในไฟล์ ePM ที่อ่านได้จริง.
- เพิ่ม `ComponentNumberCollection`, `LandNumberCollection`, `DestinationList`, `FeatureList`.
- Normalize พิกัดเป็นสูงสุด 3 ตำแหน่ง และ Angle สูงสุด 5 ตำแหน่ง.
- Re-index Component/Land ID ใน export snapshot.
- ไม่ใส่ UniversalCAD metadata comment ลง machine XML.
- ไม่เปลี่ยน Project schema และไม่รื้อ Grid/Land Map, Mapping, Apply, Undo/Redo, CAD/FAB, Excel, Autosave หรือ PWA.
