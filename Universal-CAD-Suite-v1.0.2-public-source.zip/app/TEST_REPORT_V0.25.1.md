# Test Report — Universal CAD Studio v0.25.1

## Baseline

- `npm run test:all` on v0.25.0: 50/50 scripts passed

## Final automated gate

Commands:

- `npm run typecheck`
- `npm run lint`
- `npm run test:all`
- `npm run build`
- `npm run verify:production`
- `npm run verify:large-fabmaster -- /mnt/data/CAD_T99O089T00_045_20180921.zip`

New automated regression: `tests/test-large-fabmaster-stream.mjs` checks chunk-boundary streaming, ignored trace rows, Component/Land extraction and preference for BOARD GEOMETRY/OUTLINE over oversized J extents.

No existing test was disabled or skipped to make this release pass.

## Final results

- Type Check: 96 JavaScript modules passed `node --check`
- Security lint: passed; 1 pre-existing controlled `innerHTML` review warning in `app.js`
- Automated tests: 51/51 scripts passed
- Failed: 0
- Skipped: 0
- Production build: passed
- Production verifier: HTTP/MIME/manifest/build metadata + 41 precache assets passed
- Real supplied ZIP: passed, FABmaster streaming import 3,844,879 lines → 4,714 Components / 16,027 Lands / 128 Packages; board 313.500008 × 215.829896 mm; import ~3.46 s in the Node verification environment
- Build commit: unavailable because the supplied source ZIP is not a Git working tree; no commit hash was invented
