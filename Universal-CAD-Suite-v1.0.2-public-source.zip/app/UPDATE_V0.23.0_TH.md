# Universal CAD Studio v0.23.0 — Unified Grid/Land Map Excel

## Workflow ใหม่

1. เลือก Component หนึ่งตัวใน CAD Editor
2. เปิด **Grid / Land Map**
3. เลือกลำดับ Grid, ทิศทางแถว/คอลัมน์, ลำดับ Source และการรักษา Manual/Confirmed Mapping
4. ตรวจ Preview ซึ่งแสดง `LAND <Source>` และชื่อ CAD ในช่องเดียวกัน
5. กด **Export Excel** เพื่อส่งออก Preview ปัจจุบัน หรือกด **Yes - Apply Grid Mapping** เพื่อ Commit Mapping

## Excel Output

- ชีต `Grid Map`: แสดงผังตามตำแหน่งจริง โดยแต่ละตำแหน่งใช้สองแถว—LAND และ CAD name
- ชีต `Land Data`: รายการ Land ทั้งหมด พร้อม XML ID, Grid row/column, Mapping status, Preview flag, Source record, match method/score และพิกัด
- เมื่อไม่มี Source Mapping ระบบใช้ LAND 1..N เป็นเลขสำรอง และ Preview บนหน้าจอจะแสดงเลขเดียวกับ Excel

## สิ่งที่ถอดออก

- ปุ่ม/เมนู `Export Land Map` แยก
- Modal Land Map แยก
- PowerPoint `.pptx` และ SVG Land Map export
- PptxGenJS runtime และ license bundle
- transient `cadEditor.landMap` state และ Object URL cleanup ที่ไม่จำเป็น

Schema ยังเป็น 2 และ Project/Autosave/Backup รุ่นเดิมยังใช้ได้
