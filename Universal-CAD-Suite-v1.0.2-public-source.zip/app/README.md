# Universal CAD Studio v0.25.2

Universal CAD Studio เป็น Progressive Web App สำหรับเตรียมข้อมูล CAD/NPI ในเบราว์เซอร์ โดยคงการ Deploy แบบ Static Hosting และงาน CAD หลักทำงานภายในอุปกรณ์ ไม่ต้องมี Node.js Server ใน Runtime

## สถาปัตยกรรม

- Vanilla HTML/CSS/JavaScript ES Modules
- Universal CAD Model schema v2 เป็นโมเดลกลางสำหรับ Project, Source, Board/Panel, Component, Package, Land/Pin/Net/Hole/Fiducial, BOM, Coordinate System, Revision และ Change Set
- แยก Immutable Original Source, Parsed Source Model, Working Model, Applied Revision และ Export Snapshot
- Transaction Engine รองรับ Validate, Commit, Rollback, Undo/Redo และ Revision
- IndexedDB Autosave เฉพาะ Revision ที่ Commit สมบูรณ์
- Service Worker + generated precache manifest สำหรับ PWA/Offline shell และ Update flow

## คำสั่งตรวจสอบ

```bash
npm run typecheck
npm run lint
npm run test:all
npm run build
npm run verify:production
```

`npm run build` สร้าง `dist/` ที่นำไป Deploy บน Cloudflare Pages, GitHub Pages หรือ Static Hosting ได้โดยตรง ไม่มี Application Server

## รูปแบบที่รองรับ

รองรับการนำเข้า Inspection CAD XML/CPO-like XML, **GenCAD 1.4 (`.cad`)**, **FABmaster ASCII A!/J!/S! (`.fab` และ `.cad` variant ที่มี signature นี้)**, XML/CAD text ภายใน ZIP/TGZ/TAR/GZIP, ODB++ จากโครงสร้างที่มี `components.Z`/`eda/data.Z`, CSV/TXT CAD XY หรือ BOM และ XLSX workflow เดิม ระบบตรวจจาก magic bytes, archive structure, XML root/namespace, text signature และ encoding ไม่อาศัยนามสกุลเพียงอย่างเดียว

IPC-2581 รองรับแบบบางส่วนสำหรับข้อมูล placement/package/pin/land ที่ Adapter แปลงได้ ส่วน GenCAD/FABmaster Writer รุ่นนี้เป็น **partial cross-format writer** สำหรับ Board/Component placement/rectangular Land-Padstack ที่ Working Model มีอยู่ โดยยังไม่สร้าง netlist/routes/vias/arbitrary polygon ที่ไม่มีในโมเดลกลาง ส่วน Gerber/Excellon ตรวจชนิดและรายงาน Diagnostic ได้ แต่ยังไม่มี Geometry Editor/Writer ครบถ้วน ดูรายละเอียดที่ `docs/FORMAT_SUPPORT.md`

### Large FABmaster `.cad/.fab`

ตั้งแต่ v0.25.2 ไฟล์ FABmaster/Cadence A!/J!/S! ขนาดใหญ่สามารถอ่านแบบ streaming ได้ทั้งไฟล์ตรงและไฟล์ที่อยู่ใน ZIP ตัว parser เก็บเฉพาะ Component, Pad/Padstack, Pin/Land และ Board Outline ที่จำเป็นต่อ Working Model ส่วน net/trace/graphic หลายล้าน record จะถูกนับและรายงานเป็น unsupported/ignored โดยไม่ materialize เป็น object ทั้งหมดใน RAM ขอบเขตบอร์ดจะใช้ `BOARD GEOMETRY / OUTLINE` เมื่อมี เพื่อไม่ให้ Drawing extents ทำให้ Board View เล็กผิดปกติ

## Board Direction, Grid/Land Map และ Name Grid

- เมนู **Board** หมุนทั้งบอร์ดซ้าย/ขวา 90°, 180° หรือ Mirror พร้อม Undo/Redo
- **Grid / Land Map** สร้างชื่อใหม่ เช่น `A1/A2/B1` หรือ `LAND 1/LAND 2` แล้ว Mapping แบบ 1:1 ไปยังชื่อ Land เดิมใน CAD โดยไม่ต้องมีข้อมูลต้นทางจาก XLSX/CSV
- กำหนดจุดเริ่ม ทิศทาง Row/Column-major, Compact/Physical gap, Prefix/Suffix, Start, Step, Padding และ Manual override ราย Land ได้
- ส่งออก **Excel `.xlsx`** โดยมีชีต `Grid Land Map` แสดงชื่อใหม่ด้านบน/ชื่อ CAD ด้านล่าง และชีต `Mapping Data` สำหรับ Mapping/พิกัดครบทุก Land
- ไม่มี Modal หรือปุ่ม Export Land Map แยก และไม่มี PowerPoint/SVG runtime ซ้ำซ้อนอีกต่อไป
- การเปลี่ยนชื่อ CAD จริงยังอยู่ใน **ตรวจสอบชื่อ → เปลี่ยนชื่อแบบ Grid พร้อม Preview** เพื่อแยกจาก Mapping Alias อย่างชัดเจน

## Apply และ Export

Apply เตรียม normalized model, mapping refresh, validation และ project revision ให้ครบก่อนเผยแพร่ state หากขั้นตอนใดล้มเหลวจะ Rollback ทั้ง Editor/Mapping/Revision โดยไม่แก้ Original Source โดยตรง Export ใช้ Applied Revision ล่าสุดและสร้าง Export Snapshot พร้อม Project ID, Revision, เวลา, source/export format, validation status และ accepted warnings ใน CAD Editor สามารถเลือก Inspection XML, GenCAD 1.4 `.cad` หรือ FABmaster ASCII `.fab` ได้จาก Format selector เดียวกัน

## PWA

- `manifest.webmanifest`: `start_url`/`scope` เป็น `./`, `display: standalone`
- `sw.js`: cache version ผูกกับ App version และ Schema version
- `precache-manifest.js`: สร้างอัตโนมัติจาก Runtime files ตอน Build
- มีปุ่มแจ้ง Update เมื่อ Service Worker ใหม่อยู่ในสถานะ waiting
- Static Production Verification ตรวจ Manifest, MIME และ Precache assets ทุกไฟล์

## เอกสาร Release

- `CHANGELOG.md`
- `RELEASE_REPORT_V0.25.2_TH.md`
- `docs/TEST_REPORT.md`
- `docs/DEPLOYMENT.md`
- `docs/MIGRATION.md`
- `docs/ROLLBACK.md`
- `docs/KNOWN_LIMITATIONS.md`

## VT-X / ePM XML export (v0.25.2)

The default XML export is now a machine-oriented VT-X/ePM-compatible structure rooted at `DataList`, with component/package/land collections and per-land `FeatureList`. Geometry is normalized to 3 decimal places (angles up to 5) to prevent browser floating-point artifacts from leaking into exported coordinates. The internal simplified `InspectionData` representation is still used as a compatibility working format inside the app where appropriate, but it is no longer the default machine XML export.
