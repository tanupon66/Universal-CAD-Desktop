# อัปเดต Universal CAD Studio v0.18.6

## แก้ปัญหา

- Apply ค้างกับ CAD ขนาดใหญ่
- ปุ่ม Close ไม่ตอบสนองเพราะ Busy Lock
- Export XML ไม่เริ่มดาวน์โหลดในบางเบราว์เซอร์
- Discard ย้อนกลับถึงไฟล์นำเข้าแทน Apply ล่าสุด
- CAD Compare ทำงานหนักโดยไม่จำเป็นตอน Apply
- Export Archive ODB++ ดูเหมือนเป็นปุ่มเสีย

## พฤติกรรมใหม่

- Apply ซิงก์ชื่อและตำแหน่งกับ Mapping โดยไม่ Serialize/Parse XML ซ้ำ
- เพิ่ม/ลบโครงสร้างแล้ว Rebuild Mapping หลังปิด Editor
- Export XML ใช้ Fast XML Builder
- ปุ่ม Export Archive ของ ODB++ แสดงคำอธิบายแทนการเงียบ
- Busy เกิน 15 วินาที กดปิดอีกครั้งเพื่อปลด Lock ได้
