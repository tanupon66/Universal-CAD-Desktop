import { ZipArchive, createZip } from './zip-reader.js';
import { bytesFromText, createTar, gzip, gunzip, parseTar, scoreCadXml, textFromBytes } from './archive-reader.js';
import { convertOdbPackageToInspectionXml } from './odb-parser.js';
import { isUnixCompress, unlzw } from './unix-compress.js';
import { detectCadFormat, validateArchivePath } from './format-detector.js';
import { adaptCadText, adaptCadStream } from './import-adapters.js';
import { ArchiveError } from './cad-errors.js';

const MAX_DEPTH = 5;
const MAX_SCAN_BYTES = 120 * 1024 * 1024;
const MAX_UNKNOWN_SCAN_BYTES = 24 * 1024 * 1024;
const LARGE_TEXT_PREFIX_BYTES = 320 * 1024;
const MAX_ARCHIVE_FILES = 20000;
const MAX_EXPANDED_BYTES = 512 * 1024 * 1024;
const MAX_COMPRESSION_RATIO = 250;

function asBytes(input) {
  if (input instanceof Uint8Array) return input;
  if (input instanceof ArrayBuffer) return new Uint8Array(input);
  if (ArrayBuffer.isView(input)) return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  throw new TypeError('Unsupported package input');
}

function lowerName(name = '') { return String(name).toLowerCase(); }
function isZipName(name) { return /\.zip$/i.test(name); }
function isTgzName(name) { return /\.(?:tgz|tar\.gz|gz)$/i.test(name); }
function isTarName(name) { return /\.tar$/i.test(name); }
function isXmlName(name) { return /\.(?:xml|cad|fab|gcd|cpo|job|dat|txt)$/i.test(name); }
function isArchiveName(name) { return isZipName(name) || isTgzName(name) || isTarName(name); }
function isOdbRelevantName(name) {
  const value = String(name || '').replace(/\\/g, '/').toLowerCase();
  return /(?:^|\/)steps\/[^/]+\/layers\/comp_\+_(?:top|bot)\/components(?:[23])?(?:\.z)?$/.test(value)
    || /(?:^|\/)steps\/[^/]+\/eda\/data(?:\.z)?$/.test(value)
    || /(?:^|\/)matrix\/matrix(?:\.z)?$/.test(value)
    || /(?:^|\/)steps\/[^/]+\/profile(?:\.z)?$/.test(value);
}

function hasZipMagic(bytes) { return bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && [0x03, 0x05, 0x07].includes(bytes[2]); }
function hasGzipMagic(bytes) { return bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b; }
function hasTarMagic(bytes) {
  if (bytes.length < 512) return false;
  const magic = new TextDecoder('ascii').decode(bytes.slice(257, 263));
  return magic.startsWith('ustar');
}
function looksLikeXml(bytes) {
  const sample = textFromBytes(bytes.slice(0, Math.min(bytes.length, 4096))).replace(/^\uFEFF/, '').trimStart();
  return sample.startsWith('<?xml') || sample.startsWith('<');
}

function joinPath(parent, name) { return parent ? `${parent} → ${name}` : name; }

async function parseFileNode(name, bytes, displayPath, depth, diagnostics) {
  const data = asBytes(bytes);
  if (depth > MAX_DEPTH) {
    diagnostics.push(`Skipped archive nesting deeper than ${MAX_DEPTH} levels: ${displayPath}`);
    return { root: { kind: 'file', name, bytes: data }, candidates: [] };
  }

  if (hasZipMagic(data) || isZipName(name)) return parseZipNode(name, data, displayPath, depth, diagnostics);
  // Classic Unix compress (.Z) is common in ODB++ and older CAD exports. At the
  // package root we can safely unwrap it and continue through the normal XML/TAR
  // detection path. Nested .Z entries remain owned by the ODB parser so archive
  // rebuild never writes uncompressed bytes back under a .Z filename.
  if (depth === 0 && (isUnixCompress(data) || /\.z$/i.test(name))) {
    try {
      const unpacked = unlzw(data);
      const innerName = String(name || 'cad.Z').replace(/\.z$/i, '') || 'cad.xml';
      diagnostics.push(`Decompressed Unix compress (.Z): ${displayPath}`);
      return parseFileNode(innerName, unpacked, `${displayPath} → ${innerName}`, depth + 1, diagnostics);
    } catch (error) {
      diagnostics.push(`Unable to decompress Unix compress (.Z) ${displayPath}: ${error.message}`);
    }
  }
  if (hasGzipMagic(data) || isTgzName(name)) {
    try {
      const unpacked = await gunzip(data);
      if (hasTarMagic(unpacked)) return parseTarNode(name, unpacked, displayPath, depth, diagnostics, true);
      if (looksLikeXml(unpacked)) {
        const innerName = String(name || 'cad.gz').replace(/\.(?:tgz|tar\.gz|gz)$/i, '') || 'cad.xml';
        return parseFileNode(innerName, unpacked, `${displayPath} → ${innerName}`, depth + 1, diagnostics);
      }
    } catch (error) {
      diagnostics.push(`Unable to decompress GZIP ${displayPath}: ${error.message}`);
    }
  }
  if (hasTarMagic(data) || isTarName(name)) return parseTarNode(name, data, displayPath, depth, diagnostics, false);

  const fileNode = { kind: 'file', name, bytes: data };
  if (data.length > MAX_SCAN_BYTES) return { root: fileNode, candidates: [] };
  let text = '';
  try { text = textFromBytes(data); } catch { text = ''; }
  const detection = detectCadFormat({ name, bytes: data, text });
  let score = scoreCadXml(text) + (isXmlName(name) ? 1 : 0);
  if (['inspection-xml', 'ipc-2581', 'gencad-1.4', 'fabmaster-ascii'].includes(detection.format)) {
    try {
      const adapted = adaptCadText(text, { fileName: displayPath, detection });
      diagnostics.push(...(adapted.warnings || []).map((warning) => `${displayPath}: ${warning}`));
      if (adapted.unsupportedRecords?.length) diagnostics.push(`${displayPath}: ${adapted.unsupportedRecords.length} source record(s) were not imported; see the Diagnostic Report.`);
      score = Math.max(score, detection.format === 'ipc-2581' ? 900 : detection.format === 'gencad-1.4' ? 880 : detection.format === 'fabmaster-ascii' ? 860 : 100);
      return { root: fileNode, candidates: [{ node: fileNode, text: adapted.xmlText, originalText: text, score, displayPath, format: adapted.sourceFormat, converted: adapted.sourceFormat !== 'inspection-xml', adapterInfo: adapted, detection }] };
    } catch (error) {
      diagnostics.push(`Unable to read ${displayPath}: ${error.message}`);
      return { root: fileNode, candidates: [] };
    }
  }
  if (detection.format === 'fabmaster-legacy') {
    diagnostics.push(`${displayPath}: a legacy manufacturing-ASCII variant was detected, but no adapter is available for it.`);
    return { root: fileNode, candidates: [] };
  }
  return { root: fileNode, candidates: score > 1 ? [{ node: fileNode, text, score, displayPath, format: 'inspection-xml', detection }] : [] };
}

async function parseZipNode(name, bytes, displayPath, depth, diagnostics) {
  const archive = new ZipArchive(bytes);
  const entries = archive.list();
  if (entries.length > MAX_ARCHIVE_FILES) throw new ArchiveError(`ZIP contains ${entries.length} entries, exceeding the limit of ${MAX_ARCHIVE_FILES}.`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_FILE_COUNT_LIMIT' });
  let expandedTotal = 0;
  for (const meta of entries) {
    const pathCheck = validateArchivePath(meta.name);
    if (!pathCheck.safe) throw new ArchiveError(`Unsafe path in ZIP: ${meta.name} (${pathCheck.reason})`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_PATH_TRAVERSAL' });
    expandedTotal += Number(meta.uncompressedSize || 0);
    const compressed = Math.max(1, Number(meta.compressedSize || 0));
    if (Number(meta.uncompressedSize || 0) / compressed > MAX_COMPRESSION_RATIO && Number(meta.uncompressedSize || 0) > 1024 * 1024) throw new ArchiveError(`Suspicious compression ratio detected for ${meta.name}.`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_BOMB_RATIO' });
  }
  if (expandedTotal > MAX_EXPANDED_BYTES) throw new ArchiveError(`Expanded ZIP size ${expandedTotal} bytes exceeds the configured limit.`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_EXPANDED_SIZE_LIMIT' });
  const node = { kind: 'zip', name, archive, entries: [], sourceBytes: bytes };
  const candidates = [];

  for (const meta of entries) {
    const entry = { ...meta, path: meta.name, child: null };
    node.entries.push(entry);
    if (meta.isDirectory) continue;
    const likelyArchive = isArchiveName(meta.name);
    const likelyText = isXmlName(meta.name);
    const likelyOdb = isOdbRelevantName(meta.name);
    const limit = likelyArchive || likelyText || likelyOdb ? MAX_SCAN_BYTES : MAX_UNKNOWN_SCAN_BYTES;
    if (Number(meta.uncompressedSize || 0) > limit) {
      // Large manufacturing ASCII extracts frequently contain millions of trace/graphic rows.
      // v0.25 used to silently skip them at MAX_SCAN_BYTES. Sniff only a small
      // decompressed prefix, then stream the member if its content signature is
      // a supported A!/J!/S! extract. This keeps memory bounded while preserving
      // the immutable ZIP bytes for archive export.
      if (likelyText) {
        try {
          const prefixBytes = await archive.readPrefix(meta.name, LARGE_TEXT_PREFIX_BYTES);
          const prefixText = textFromBytes(prefixBytes);
          const detection = detectCadFormat({ name: meta.name, bytes: prefixBytes, text: prefixText });
          if (detection.format === 'fabmaster-ascii') {
            const fileNode = { kind: 'file', name: meta.name, bytes: null, streamed: true, sourceSize: Number(meta.uncompressedSize || 0) };
            entry.child = fileNode;
            diagnostics.push(`Detected a large manufacturing-ASCII file ${joinPath(displayPath, meta.name)} (${Number(meta.uncompressedSize || 0)} bytes); using the streaming parser instead of loading the entire file.`);
            const adapted = await adaptCadStream(archive.openStream(meta.name), {
              fileName: joinPath(displayPath, meta.name), detection, totalBytes: Number(meta.uncompressedSize || 0),
            });
            diagnostics.push(...(adapted.warnings || []).map((warning) => `${joinPath(displayPath, meta.name)}: ${warning}`));
            if (adapted.unsupportedRecords?.length) diagnostics.push(`${joinPath(displayPath, meta.name)}: ${adapted.unsupportedRecords.length} source record type(s) were not imported; see the Diagnostic Report.`);
            diagnostics.push(`${joinPath(displayPath, meta.name)}: streaming scan ${adapted.scannedLines || 0} lines → ${adapted.components || 0} Components / ${adapted.lands || 0} Lands`);
            candidates.push({
              node: fileNode, text: adapted.xmlText, score: 860, displayPath: joinPath(displayPath, meta.name), format: adapted.sourceFormat,
              converted: true, adapterInfo: adapted, detection,
            });
          } else {
            diagnostics.push(`Skipped large file ${joinPath(displayPath, meta.name)} (${Number(meta.uncompressedSize || 0)} bytes): detected ${detection.format || 'unknown'} and no streaming adapter is available.`);
          }
        } catch (error) {
          diagnostics.push(`Unable to read large file ${joinPath(displayPath, meta.name)}: ${error.message}`);
        }
      }
      continue;
    }
    let entryBytes;
    try { entryBytes = await archive.read(meta.name, 'uint8array'); }
    catch (error) { diagnostics.push(`Unable to read ${joinPath(displayPath, meta.name)}: ${error.message}`); continue; }
    const shouldInspect = likelyArchive || likelyText || likelyOdb || hasZipMagic(entryBytes) || hasGzipMagic(entryBytes) || hasTarMagic(entryBytes) || looksLikeXml(entryBytes);
    if (!shouldInspect) continue;
    const parsed = await parseFileNode(meta.name, entryBytes, joinPath(displayPath, meta.name), depth + 1, diagnostics);
    entry.child = parsed.root;
    candidates.push(...parsed.candidates);
  }
  return { root: node, candidates };
}

async function parseTarNode(name, tarBytes, displayPath, depth, diagnostics, gzipped) {
  const entries = parseTar(tarBytes);
  if (entries.length > MAX_ARCHIVE_FILES) throw new ArchiveError(`TAR contains ${entries.length} entries, exceeding the limit of ${MAX_ARCHIVE_FILES}.`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_FILE_COUNT_LIMIT' });
  let expandedTotal = 0;
  for (const entry of entries) {
    const pathCheck = validateArchivePath(entry.path || entry.name);
    if (!pathCheck.safe) throw new ArchiveError(`Unsafe path in TAR: ${entry.path || entry.name} (${pathCheck.reason})`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_PATH_TRAVERSAL' });
    expandedTotal += Number(entry.bytes?.length || entry.size || 0);
  }
  if (expandedTotal > MAX_EXPANDED_BYTES) throw new ArchiveError(`Expanded TAR size ${expandedTotal} bytes exceeds the configured limit.`, { stage: 'archive-preflight', fileName: displayPath, code: 'ARCHIVE_EXPANDED_SIZE_LIMIT' });
  const node = { kind: gzipped ? 'tgz' : 'tar', name, entries: [], sourceBytes: tarBytes };
  const candidates = [];
  for (const original of entries) {
    const entry = { ...original, child: null };
    node.entries.push(entry);
    if (entry.isDirectory) continue;
    const entryName = entry.path || entry.name;
    const likelyArchive = isArchiveName(entryName);
    const likelyText = isXmlName(entryName);
    const likelyOdb = isOdbRelevantName(entryName);
    const limit = likelyArchive || likelyText || likelyOdb ? MAX_SCAN_BYTES : MAX_UNKNOWN_SCAN_BYTES;
    if (Number(entry.bytes?.length || 0) > limit) continue;
    const shouldInspect = likelyArchive || likelyText || likelyOdb || hasZipMagic(entry.bytes) || hasGzipMagic(entry.bytes) || hasTarMagic(entry.bytes) || looksLikeXml(entry.bytes);
    if (!shouldInspect) continue;
    const parsed = await parseFileNode(entryName, entry.bytes, joinPath(displayPath, entryName), depth + 1, diagnostics);
    entry.child = parsed.root;
    candidates.push(...parsed.candidates);
  }
  return { root: node, candidates };
}

export async function readCadPackageFile(file) {
  const diagnostics = [];
  // Standalone very-large manufacturing ASCII .cad/.fab: sniff with File.slice(), then
  // consume File.stream() directly so we never create both a 250+ MiB byte
  // array and a second full-size JavaScript string at the same time.
  if (Number(file?.size || 0) > MAX_SCAN_BYTES && isXmlName(file?.name || '') && typeof file?.stream === 'function') {
    try {
      const prefixBytes = new Uint8Array(await file.slice(0, LARGE_TEXT_PREFIX_BYTES).arrayBuffer());
      const prefixText = textFromBytes(prefixBytes);
      const detection = detectCadFormat({ name: file.name, mimeType: file.type, bytes: prefixBytes, text: prefixText });
      if (detection.format === 'fabmaster-ascii') {
        diagnostics.push(`Detected a large manufacturing-ASCII file ${file.name} (${file.size} bytes); using the streaming parser.`);
        const adapted = await adaptCadStream(file.stream(), { fileName: file.name, detection, totalBytes: file.size });
        diagnostics.push(...(adapted.warnings || []).map((warning) => `${file.name}: ${warning}`));
        diagnostics.push(`${file.name}: streaming scan ${adapted.scannedLines || 0} lines → ${adapted.components || 0} Components / ${adapted.lands || 0} Lands`);
        const root = { kind: 'file', name: file.name, bytes: null, streamed: true, sourceSize: file.size };
        const candidate = { node: root, text: adapted.xmlText, score: 860, displayPath: file.name, format: adapted.sourceFormat, converted: true, adapterInfo: adapted, detection };
        return { name: file.name || 'package', root, candidates: [candidate], diagnostics };
      }
      diagnostics.push(`File ${file.name} is ${file.size} bytes and was detected as ${detection.format || 'unknown'}; this streaming adapter supports only the A!/J!/S! manufacturing-ASCII variant.`);
      return { name: file.name || 'package', root: { kind: 'file', name: file.name, bytes: null, streamed: true, sourceSize: file.size }, candidates: [], diagnostics };
    } catch (error) {
      diagnostics.push(`Streaming preflight failed for ${file.name}: ${error.message}`);
      return { name: file.name || 'package', root: { kind: 'file', name: file.name, bytes: null, streamed: true, sourceSize: file.size }, candidates: [], diagnostics };
    }
  }
  const bytes = new Uint8Array(await file.arrayBuffer());
  const parsed = await parseFileNode(file.name || 'package', bytes, file.name || 'package', 0, diagnostics);
  const candidates = [...parsed.candidates];
  try {
    const odb = await convertOdbPackageToInspectionXml(parsed.root);
    if (odb) {
      candidates.push({
        node: null,
        text: odb.xmlText,
        score: 1000 + odb.components + Math.min(odb.lands, 1000) / 1000,
        displayPath: `ODB++ → XML (${odb.sourceFiles.join(', ')})`,
        format: 'odb++',
        converted: true,
        odbInfo: odb,
      });
      diagnostics.push(`Detected ODB++ with ${odb.components} components / ${odb.lands} lands.`);
      diagnostics.push(...odb.warnings.slice(0, 5));
    }
  } catch (error) {
    diagnostics.push(`Unable to normalize ODB++: ${error.message}`);
  }
  candidates.sort((a, b) => b.score - a.score || a.displayPath.localeCompare(b.displayPath));
  return { name: file.name || 'package', root: parsed.root, candidates, diagnostics };
}

async function buildNode(node, replacementNode, replacementBytes) {
  if (node.kind === 'file') return node === replacementNode ? replacementBytes : node.bytes;
  if (node.kind === 'zip') {
    const entries = [];
    for (const entry of node.entries) {
      let bytes = new Uint8Array();
      if (!entry.isDirectory) bytes = entry.child ? await buildNode(entry.child, replacementNode, replacementBytes) : await node.archive.read(entry.name, 'uint8array');
      entries.push({ name: entry.name, isDirectory: entry.isDirectory, bytes });
    }
    return createZip(entries);
  }
  if (node.kind === 'tar' || node.kind === 'tgz') {
    const entries = [];
    for (const entry of node.entries) {
      const bytes = entry.isDirectory ? new Uint8Array() : (entry.child ? await buildNode(entry.child, replacementNode, replacementBytes) : entry.bytes);
      entries.push({ ...entry, bytes, size: bytes.length });
    }
    const tar = createTar(entries);
    return node.kind === 'tgz' ? gzip(tar) : tar;
  }
  throw new Error(`Archive kind ${node.kind} is not supported.`);
}

export async function rebuildCadPackage(packageInfo, candidate, xmlText) {
  if (!packageInfo?.root || !candidate?.node) throw new Error('Archive information is incomplete.');
  return buildNode(packageInfo.root, candidate.node, bytesFromText(xmlText));
}

export function packageOutputInfo(packageInfo, side = 'all') {
  const rootKind = packageInfo?.root?.kind || 'file';
  const original = String(packageInfo?.name || 'cad');
  const suffix = side === 'all' ? 'top_bottom' : side;
  if (rootKind === 'zip') return { extension: '.zip', mime: 'application/zip', filename: `${original.replace(/\.zip$/i, '')}_${suffix}.zip`, label: 'ZIP' };
  if (rootKind === 'tgz') return { extension: '.tgz', mime: 'application/gzip', filename: `${original.replace(/\.(?:tgz|tar\.gz|gz)$/i, '')}_${suffix}.tgz`, label: 'TGZ' };
  if (rootKind === 'tar') return { extension: '.tar', mime: 'application/x-tar', filename: `${original.replace(/\.tar$/i, '')}_${suffix}.tar`, label: 'TAR' };
  return { extension: '.xml', mime: 'application/xml', filename: `${original.replace(/\.[^.]+$/i, '')}_${suffix}.xml`, label: 'XML' };
}
