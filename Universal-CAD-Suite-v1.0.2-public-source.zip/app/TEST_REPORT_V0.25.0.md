# Test Report — Universal CAD Studio v0.25.0

Date: 2026-08-20

## Baseline v0.24.0

| Command | Result | Passed | Failed | Skipped |
|---|---|---:|---:|---:|
| `npm run typecheck` | PASS | 89 modules | 0 | 0 |
| `npm run test:all` | PASS | 47 scripts | 0 | 0 |
| `npm run build` | PASS | 1 build | 0 | 0 |
| `npm run verify:production` | PASS | production verifier | 0 | 0 |

## Final v0.25.0

| Command | Result | Passed | Failed | Skipped |
|---|---|---:|---:|---:|
| `npm run typecheck` | PASS | 94 JavaScript modules | 0 | 0 |
| `npm run test:all` | PASS | 50 scripts | 0 | 0 |
| `npm run lint` | PASS | policy checks | 0 | 0 |
| `npm run build` | PASS | static build | 0 | 0 |
| `npm run verify:production` | PASS | HTTP/MIME/manifest/build metadata + 41 precache assets | 0 | 0 |
| `node scripts/verify-pcb-cross-export.mjs /mnt/data/R4125-B0013-02_R01_ODB-A_top_bottom.xml` | PASS | 2 cross-format semantic checks | 0 | 0 |

### Lint note

`npm run lint` prints one review warning for existing controlled dynamic `innerHTML` in `app.js`. The security gate itself passes. The lint script fails on `eval`, `new Function` and empty catch handlers.

### Git metadata note

`npm run build` reports commit hash as unavailable because the delivered source ZIP has no `.git` directory. This is expected and is not treated as a build failure.

## New v0.25.0 tests

### `test:pcb-ascii-import`

Verifies:

- GenCAD 1.4 content signature and import
- FABmaster A!/J!/S! content signature and import
- package identity and Land counts
- standalone package-reader routing
- nested ZIP GenCAD candidate
- `.cad` with FABmaster content routes by content
- `.fab` with GenCAD content routes by content
- common `UNITS USER 1000` conversion
- legacy FABmaster detected but not falsely supported
- recognized empty/malformed CAD/FAB does not create an empty successful project

### `test:pcb-ascii-roundtrip`

Verifies:

- Inspection XML → GenCAD `.cad` → adapter → Inspection semantic subset
- Inspection XML → FABmaster `.fab` → adapter → Inspection semantic subset
- Component/package/rotation/counts and rectangular Land geometry within defined tolerance
- writers report `partial: true`

### `test:v025`

Verifies:

- `.fab/.gcd` file input acceptance
- Export Format selector and menu actions
- `pcb-ascii-formats.js` runtime integration
- content adapters wired in detector/import layer
- source-format-aware archive write-back branches
- archive guard for formats without a matching writer
- new module is in source offline precache

## Existing regression suite

All pre-existing test scripts remain enabled. No failing test was disabled to make v0.25.0 pass.
