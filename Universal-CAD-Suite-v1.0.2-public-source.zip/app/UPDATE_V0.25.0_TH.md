# Universal CAD Studio v0.25.0 — CAD/FAB Cross-format Update

## เพิ่มใหม่

- Content-based detector สำหรับ GenCAD 1.4 และ FABmaster ASCII A!/J!/S!
- Import `.cad` แบบ GenCAD 1.4 เข้า Universal/Working Model เดิม
- Import `.fab` แบบ FABmaster ASCII และ `.cad` ที่มี A!/J!/S! signature
- Export จาก Applied Revision เป็น Inspection XML, GenCAD 1.4 `.cad` หรือ FABmaster ASCII `.fab`
- Format selector ใน CAD Editor และ File menu สำหรับแต่ละ writer
- GenCAD/FABmaster semantic subset round-trip tests
- Fixture ขนาดเล็กที่ไม่มีข้อมูลลับสำหรับทั้งสองรูปแบบ
- Diagnostic แยก FABmaster legacy/FATF ที่ตรวจพบแต่ยังไม่รองรับ

## ความเข้ากันได้

- Schema ยังคงเป็น 2 ไม่มีการเปลี่ยน field เดิม
- Original Source ยังคง immutable
- Grid/Land Map, Name Inspector, Apply, Transaction, Undo/Redo, Autosave, Mapping และ Excel export ไม่ถูกเปลี่ยน API
- PWA/Static Hosting/Offline runtime เดิมยังคงอยู่

## ข้อจำกัดที่ต้องทราบ

Writer `.cad` และ `.fab` ใน v0.25.0 เป็น partial writer: รองรับ Board/Component placement/rectangular Land-Padstack subset ของ Working Model แต่ยังไม่สร้าง netlist/routes/vias/custom polygon records ที่ไม่มีข้อมูลในโมเดลกลาง จึงห้ามถือว่าเป็น full manufacturing round-trip สำหรับทุก EDA/Machine format
