# วิธีอัปเดต Universal CAD Studio v0.16.0

## แนะนำ: อัปโหลดเวอร์ชันเต็ม

1. สำรองโฟลเดอร์เว็บไซต์เดิม
2. ลบไฟล์รุ่นเดิมบน GitHub Pages หรือ Cloudflare Pages
3. แตก `universal-cad-editor-v0.16.0-full.zip`
4. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์ขึ้นแทนชุดเดิม
5. เปิดเว็บแล้วกด `Ctrl + Shift + R`

## อัปโหลดทับแบบ Patch

แตก `universal-cad-editor-v0.16.0-update.zip` แล้วอัปโหลดไฟล์ทั้งหมดทับของเดิม โดยไฟล์หลักที่เปลี่ยนคือ:

- `index.html`
- `styles.css`
- `app.js`
- `sw.js`
- `manifest.webmanifest`
- `package.json`
- เอกสารประกอบ

## เมื่อยังเห็น UI เดิม

เปิด DevTools → Application → Service Workers → Unregister จากนั้นล้าง Site data และเปิดหน้าใหม่

Cache รุ่นใหม่: `universal-cad-studio-v0.16.0`
