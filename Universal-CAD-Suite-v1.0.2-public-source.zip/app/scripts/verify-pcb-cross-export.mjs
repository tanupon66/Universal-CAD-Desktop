import fs from 'node:fs';
import path from 'node:path';
import { parseInspectionXml } from '../parsers.js';
import { createCadEditorModel } from '../cad-editor.js';
import { exportGenCad14, convertGenCadToInspectionXml, exportFabmasterAscii, convertFabmasterExtractToInspectionXml } from '../pcb-ascii-formats.js';

const inputPath = process.argv[2];
if (!inputPath) {
  console.error('Usage: node scripts/verify-pcb-cross-export.mjs <inspection-xml>');
  process.exit(2);
}
const source = fs.readFileSync(inputPath, 'utf8');
const before = parseInspectionXml(source);
const model = createCadEditorModel(source);
function maxGeometryDelta(a, b) {
  let max = 0;
  for (let ci = 0; ci < Math.min(a.components.length, b.components.length); ci += 1) {
    const ca = a.components[ci]; const cb = b.components[ci];
    max = Math.max(max, Math.abs(Number(ca.centerX) - Number(cb.centerX)), Math.abs(Number(ca.centerY) - Number(cb.centerY)));
    for (let li = 0; li < Math.min(ca.lands.length, cb.lands.length); li += 1) {
      const la = ca.lands[li]; const lb = cb.lands[li];
      for (const key of ['left', 'top', 'width', 'length']) max = Math.max(max, Math.abs(Number(la[key]) - Number(lb[key])));
    }
  }
  return max;
}
const cases = [
  ['GenCAD 1.4', exportGenCad14, (text) => convertGenCadToInspectionXml(text, { fileName: 'verify.cad' }), '.cad'],
  ['FABmaster ASCII', exportFabmasterAscii, (text) => convertFabmasterExtractToInspectionXml(text, { fileName: 'verify.fab' }), '.fab'],
];
for (const [label, exporter, importer, extension] of cases) {
  const exported = exporter(model, { side: 'all', fileName: path.basename(inputPath), metadata: { appVersion: '0.25.2', revisionNumber: 1, exportTime: new Date().toISOString() } });
  const after = parseInspectionXml(importer(exported.text).xmlText);
  if (after.components.length !== before.components.length || after.totalLands !== before.totalLands) throw new Error(`${label}: semantic count mismatch`);
  const delta = maxGeometryDelta(before, after);
  console.log(JSON.stringify({ format: label, extension, components: after.components.length, lands: after.totalLands, maxGeometryDeltaMm: delta, writerPartial: exported.partial, warningCount: exported.warnings.length }, null, 2));
}
