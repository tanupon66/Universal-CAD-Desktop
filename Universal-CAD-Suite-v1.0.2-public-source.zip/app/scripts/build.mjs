import { cp, mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = fileURLToPath(new URL('../', import.meta.url));
const dist = path.join(root, 'dist');
const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
const buildDate = new Date().toISOString();
let commit = 'unavailable';
try { commit = execFileSync('git', ['rev-parse', '--short', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(); } catch (error) { console.warn(`build: Git commit unavailable (${error.message})`); }
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
const excluded = new Set(['dist', 'tests', 'scripts', 'docs', '.git']);
const excludedFiles = new Set(['preview-name-rules.html']);
for (const entry of await readdir(root, { withFileTypes: true })) {
  if (excluded.has(entry.name) || excludedFiles.has(entry.name) || entry.name === 'package.json' || entry.name === 'package-lock.json') continue;
  if (entry.name.startsWith('FINAL_TEST_LOG_BASELINE')) continue;
  const source = path.join(root, entry.name);
  const target = path.join(dist, entry.name);
  if (entry.isDirectory()) await cp(source, target, { recursive: true });
  else if (entry.name === 'LICENSE' || /\.(?:html|css|js|json|webmanifest|png|svg|ico)$/i.test(entry.name)) await cp(source, target);
}
await writeFile(path.join(dist, 'build-info.json'), JSON.stringify({ appVersion: pkg.version, buildDate, commit, schemaVersion: 2 }, null, 2));

async function walk(directory, prefix = '') {
  const results = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const relative = path.posix.join(prefix, entry.name);
    if (entry.isDirectory()) results.push(...await walk(path.join(directory, entry.name), relative));
    else results.push(relative);
  }
  return results;
}
const runtimeFiles = (await walk(dist))
  .filter((name) => !['precache-manifest.js'].includes(name))
  .filter((name) => /\.(?:html|css|js|json|webmanifest|png|svg|ico)$/i.test(name))
  .sort();
const precacheAssets = ['./', ...runtimeFiles.map((name) => `./${name}`)];
await writeFile(path.join(dist, 'precache-manifest.js'), `self.__PRECACHE_ASSETS = ${JSON.stringify(precacheAssets, null, 2)};\n`);
console.log(`build: static production package created at dist/ (${pkg.version}, ${commit}, ${precacheAssets.length} precache assets)`);
