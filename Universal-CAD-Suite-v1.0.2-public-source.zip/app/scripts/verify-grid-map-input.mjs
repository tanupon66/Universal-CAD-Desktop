import { readFile } from 'node:fs/promises';
import { parseInspectionXml } from '../parsers.js';
import { buildGeneratedLandMapPlan, detectLandGrid } from '../land-grid-mapper.js';
import { createGridMapExcelModel, buildGridMapExcelBlob } from '../grid-map-excel.js';

const [, , input, componentName] = process.argv;
if (!input) { console.error('Usage: node scripts/verify-grid-map-input.mjs <inspection.xml> [component-name]'); process.exit(2); }
const parsed=parseInspectionXml(await readFile(input,'utf8'));
const component=(parsed.components||[]).find(item=>!componentName || item.name===componentName) || parsed.components?.[0];
if(!component) throw new Error('ไม่พบ Component ในไฟล์');
const grid=detectLandGrid(component);
const plan=buildGeneratedLandMapPlan(grid,{namingMode:'grid',gapMode:'compact',rowStart:'A',columnStart:1});
const model=createGridMapExcelModel(component,{grid,plan,boardName:parsed.board?.Name,metadata:{projectId:'verification',revisionNumber:0,validationStatus:'not-run'}});
const blob=await buildGridMapExcelBlob(model);
console.log(JSON.stringify({
  board:parsed.board?.Name,component:component.name,package:component.packageName,
  grid:{rows:model.grid.rowCount,columns:model.grid.columnCount,lands:model.grid.landCount,missing:model.grid.missingCount,collisions:model.grid.collisions.length},
  excel:{bytes:blob.size,sheets:['Grid Land Map','Mapping Data'],first:model.cells[0]?`${model.cells[0].newName} ↔ ${model.cells[0].cadName}`:null,last:model.cells.at(-1)?`${model.cells.at(-1).newName} ↔ ${model.cells.at(-1).cadName}`:null}
},null,2));
