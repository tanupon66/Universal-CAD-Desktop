import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
async function walk(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (['dist', '.git', 'node_modules', 'vendor'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...await walk(full));
    else if (/\.(?:js|mjs|html)$/.test(entry.name)) files.push(full);
  }
  return files;
}
const violations = [];
for (const file of await walk(root)) {
  const text = await readFile(file, 'utf8');
  const rel = path.relative(root, file);
  if (/\beval\s*\(/.test(text)) violations.push(`${rel}: eval is forbidden`);
  if (/\bnew\s+Function\s*\(/.test(text)) violations.push(`${rel}: Function constructor is forbidden`);
  if (/\.catch\s*\(\s*\([^)]*\)\s*=>\s*\{\s*\}\s*\)/.test(text) || /catch\s*(?:\([^)]*\))?\s*\{\s*\}/.test(text)) violations.push(`${rel}: empty catch handlers are forbidden`);
  if (/\.innerHTML\s*=\s*(?!['"`]|\[)/.test(text) && !rel.startsWith('tests/')) {
    // Kept as warning because legacy code uses controlled templates. New file-derived text must use textContent.
    console.warn(`lint warning: review dynamic innerHTML in ${rel}`);
  }
}
if (violations.length) throw new Error(violations.join('\n'));
console.log('lint: security policy checks passed');
