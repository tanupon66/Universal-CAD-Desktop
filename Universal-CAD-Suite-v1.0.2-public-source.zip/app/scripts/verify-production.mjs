import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const dist = path.join(root, 'dist');
await stat(path.join(dist, 'index.html'));

const mime = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};
const server = createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
    const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
    const target = path.resolve(dist, relative);
    if (!target.startsWith(path.resolve(dist) + path.sep) && target !== path.resolve(dist, 'index.html')) {
      response.writeHead(403); response.end('Forbidden'); return;
    }
    const body = await readFile(target);
    response.writeHead(200, { 'content-type': mime[path.extname(target)] || 'application/octet-stream', 'cache-control': 'no-store' });
    response.end(body);
  } catch {
    response.writeHead(404); response.end('Not found');
  }
});
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
const address = server.address();
const base = `http://127.0.0.1:${address.port}`;
try {
  const required = [
    ['/', 'text/html'], ['/manifest.webmanifest', 'application/manifest+json'], ['/sw.js', 'text/javascript'],
    ['/app.js', 'text/javascript'], ['/styles.css', 'text/css'], ['/icons/icon-192.png', 'image/png'],
    ['/build-info.json', 'application/json'], ['/precache-manifest.js', 'text/javascript'],
  ];
  for (const [url, expectedType] of required) {
    const response = await fetch(base + url, { cache: 'no-store' });
    assert.equal(response.status, 200, `${url} must return HTTP 200`);
    assert.match(response.headers.get('content-type') || '', new RegExp(expectedType.replace(/[+]/g, '\\+')), `${url} MIME type`);
  }
  const manifest = await (await fetch(base + '/manifest.webmanifest')).json();
  assert.equal(manifest.start_url, './');
  assert.equal(manifest.scope, './');
  assert.match(manifest.display, /standalone|minimal-ui|fullscreen/);
  assert.ok(manifest.icons?.some((icon) => icon.sizes === '192x192'));
  assert.ok(manifest.icons?.some((icon) => icon.sizes === '512x512'));
  const build = await (await fetch(base + '/build-info.json')).json();
  assert.equal(build.appVersion, manifest.version);
  assert.equal(build.schemaVersion, 2);
  const precacheText = await (await fetch(base + '/precache-manifest.js')).text();
  const literal = precacheText.match(/self\.__PRECACHE_ASSETS\s*=\s*(\[[\s\S]*\]);?\s*$/)?.[1];
  assert.ok(literal, 'generated precache manifest must contain an asset array');
  const assets = JSON.parse(literal);
  assert.ok(assets.includes('./'));
  for (const asset of assets) {
    const url = asset === './' ? '/' : '/' + asset.replace(/^\.\//, '');
    const response = await fetch(base + url, { cache: 'no-store' });
    assert.equal(response.status, 200, `precache asset ${asset} must be deployable`);
  }
  const sw = await (await fetch(base + '/sw.js')).text();
  assert.match(sw, /precache-manifest\.js/);
  assert.match(sw, /SKIP_WAITING/);
  assert.match(sw, /clients\.claim/);
  console.log(`verify:production passed — HTTP, MIME, manifest, build metadata and ${assets.length} precache assets verified`);
} finally {
  await new Promise((resolve) => server.close(resolve));
}
