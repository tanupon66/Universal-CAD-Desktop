import fs from 'node:fs';
import path from 'node:path';
import { readCadPackageFile } from '../archive-package.js';
import { parseInspectionXml } from '../parsers.js';

const input = process.argv[2];
if (!input) {
  console.error('Usage: node scripts/verify-large-fabmaster.mjs <file.cad|file.fab|archive.zip>');
  process.exit(2);
}
const source = fs.readFileSync(input);
const blob = new Blob([source], { type: /\.zip$/i.test(input) ? 'application/zip' : 'text/plain' });
const file = {
  name: path.basename(input), size: blob.size, type: blob.type,
  arrayBuffer: () => blob.arrayBuffer(), stream: () => blob.stream(), slice: (...args) => blob.slice(...args),
};
const before = process.memoryUsage(); const started = performance.now();
const info = await readCadPackageFile(file); const elapsedMs = performance.now() - started;
const candidate = info.candidates[0];
if (!candidate) {
  console.error(JSON.stringify({ ok: false, diagnostics: info.diagnostics }, null, 2));
  process.exit(1);
}
const parsedStarted = performance.now(); const parsed = parseInspectionXml(candidate.text); const parseXmlMs = performance.now() - parsedStarted;
const after = process.memoryUsage();
console.log(JSON.stringify({
  ok: true,
  file: file.name,
  format: candidate.format,
  displayPath: candidate.displayPath,
  streaming: Boolean(candidate.adapterInfo?.streaming),
  scannedLines: candidate.adapterInfo?.scannedLines ?? null,
  components: parsed.components.length,
  lands: parsed.totalLands,
  packages: candidate.adapterInfo?.packages ?? null,
  unit: candidate.adapterInfo?.unit ?? null,
  board: parsed.board,
  compatibilityXmlBytes: new TextEncoder().encode(candidate.text).length,
  importMs: Math.round(elapsedMs),
  parseCompatibilityXmlMs: Math.round(parseXmlMs),
  memory: {
    rssBefore: before.rss, rssAfter: after.rss, heapUsedBefore: before.heapUsed, heapUsedAfter: after.heapUsed,
  },
  diagnostics: info.diagnostics.slice(0, 12),
}, null, 2));
