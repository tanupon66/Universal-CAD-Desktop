# Universal CAD Studio v0.25.0 — Release Report

Release date: 2026-08-20  
App version: 0.25.0  
Schema version: 2  
Runtime: Static Browser/PWA (Vanilla ES Modules)  

## 1. Baseline ก่อนแก้

Baseline คือ v0.24.0 full source ที่ส่งมอบก่อนหน้า ก่อนเพิ่ม CAD/FAB ได้รันจริง:

- `npm run typecheck` — ผ่าน 89 JavaScript modules
- `npm run test:all` — ผ่าน 47/47 test scripts
- `npm run build` — ผ่าน
- `npm run verify:production` — ผ่าน

ไม่มีการรื้อ Grid/Land Map, Name Inspector, Transaction Engine, Autosave, Mapping, Validation หรือ PWA ใหม่ทั้งชุด

## 2. Root cause

1. `.cad` ไม่ใช่ format เดียว: โปรแกรมเดิมรับ extension `.cad` แต่ไม่มี content adapter จึงอาศัย XML scoring/inspection path เป็นหลัก
2. `adaptCadText()` เดิมเรียก XML security/well-formed validation ก่อน format routing ทำให้ ASCII CAD format ไม่สามารถผ่าน Adapter ได้
3. Archive scanner เดิมไม่ถือ `.fab/.gcd` เป็น text CAD candidate
4. Exporter เดิมมีเฉพาะ Inspection XML/Archive; ไม่มี writer ที่แปลง Applied Working Model เป็น GenCAD/FABmaster
5. เมื่อเพิ่ม converted text format เข้า archive หากใช้ writer เดิมโดยไม่แก้ จะเสี่ยงนำ normalized XML ไปใส่ใต้ filename `.cad/.fab`; v0.25.0 จึงทำ source-format-aware archive write-back และ block format ที่ไม่มี writer

## 3. Architecture changes

- เพิ่ม `pcb-ascii-formats.js` เป็น first-party Format Adapter/Writer module โดยไม่เปลี่ยน Universal CAD schema
- Format Detector ใช้ content signature ก่อน extension สำหรับ GenCAD/FABmaster
- GenCAD/FABmaster Import จะ Normalize เป็น Inspection-compatible Working Model เดิม จากนั้น Editor/Mapping/Validation ใช้ flow เดิม
- Original Source bytes/text ไม่ถูกแก้; Apply ยัง Commit ผ่าน Project Session/Revision เดิม
- Export `.cad/.fab` ใช้ Applied Revision และ preflight เดิม; Working Model ที่ยังไม่ Apply ถูก block เช่นเดียวกับ XML export
- Archive write-back เลือก writer ตาม source candidate: Inspection XML / GenCAD / FABmaster เท่านั้น; ODB++/IPC-2581 ที่ไม่มี matching writer จะถูก block

## 4. Files changed

Core/runtime:

- `pcb-ascii-formats.js` (ใหม่)
- `format-detector.js`
- `import-adapters.js`
- `archive-package.js`
- `app.js`
- `index.html`
- `precache-manifest.js`
- `package.json`
- `manifest.webmanifest`
- `sw.js`

Tests/fixtures:

- `tests/fixtures/sample-gencad.cad` (ใหม่, self-authored non-secret fixture)
- `tests/fixtures/sample-fabmaster.fab` (ใหม่, self-authored non-secret fixture)
- `tests/test-pcb-ascii-import.mjs` (ใหม่)
- `tests/test-pcb-ascii-export-roundtrip.mjs` (ใหม่)
- `tests/test-v025-cad-fab-static.mjs` (ใหม่)
- version/accept-list regression tests ที่อ้าง current version
- `scripts/verify-pcb-cross-export.mjs` (ใหม่, optional external-file verifier)

Documentation:

- `README.md`, `CHANGELOG.md`, `UPDATE_V0.25.0_TH.md`
- `docs/FORMAT_SUPPORT.md`, `docs/KNOWN_LIMITATIONS.md`, `docs/MIGRATION.md`, `docs/FILES_CHANGED.md`, `docs/WORKFLOW.md`

## 5. Bugs fixed

- `.cad` ASCII ที่ไม่ใช่ XML ไม่ถูกส่งเข้า XML well-formed validator ก่อน detector อีกต่อไป
- `.fab/.gcd` ใน archive ถูก scan เป็น candidate ได้
- `.cad` extension ที่มี FABmaster A!/J!/S! content จะถูก route เป็น FABmaster แทน GenCAD โดยไม่เดาจาก extension
- `.fab` ที่มี GenCAD signature จะถูก route เป็น GenCAD
- detected unsupported FABmaster legacy/FATF จะไม่สร้าง Project ว่างแล้วรายงานว่าสำเร็จ
- Archive export จะไม่เขียน normalized XML ใต้ filename `.cad/.fab`
- IPC-2581/ODB++ archive source ที่ไม่มี matching writer ถูก block แทนการเปลี่ยนชนิดข้อมูลใน archive
- GenCAD device/part mapping ถูกใช้เพื่อรักษา package identity ใน semantic subset round-trip
- GenCAD quoted output ตัด CR/LF เพื่อป้องกัน record-line injection จากชื่อที่มาจาก source/user

## 6. Features added

### Import

- GenCAD 1.4 ASCII `.cad`
- FABmaster ASCII A!/J!/S! `.fab`
- A!/J!/S! content ที่ใช้นามสกุล `.cad`
- nested `.cad/.fab/.gcd` candidates ภายใน ZIP/TGZ/TAR ตาม archive scanner เดิม

### Export

CAD Editor มี Format selector:

- Inspection XML `.xml`
- GenCAD 1.4 `.cad`
- FABmaster ASCII `.fab`

`Ctrl+E` ใช้ format ที่เลือก ส่วน File menu มี explicit command แยกแต่ละ format

### GenCAD subset writer

เขียน `$HEADER`, `$BOARD`, `$PADS`, `$PADSTACKS`, `$SHAPES`, `$COMPONENTS`, `$DEVICES` และ section structure ที่จำเป็น โดยใช้ Board/Component/rectangular Land ของ Applied Revision

### FABmaster subset writer

เขียน A/J/S sections สำหรับ Component placement, rectangular pad records, pin placement และ board outline metadata

## 7. Migration

- Schema ยังคง version 2
- ไม่มี existing field ถูก rename
- v0.24.0 Project Backup/Autosave/Grid-Land aliases/Mapping history เปิดต่อได้โดยไม่ต้อง data migration
- Export format selection เป็น runtime UI state ไม่บังคับเพิ่ม field ใน project เก่า
- Service Worker cache เปลี่ยนเป็น v0.25.0 จึงต้อง deploy production build ทั้งชุด

## 8. Tests executed

Final test suite: 50/50 scripts passed, 0 failed, 0 skipped.

เพิ่ม coverage สำหรับ:

- GenCAD signature/import/package routing
- FABmaster A!/J!/S! import/package routing
- extension mismatch vs content signature
- nested ZIP GenCAD candidate
- common GenCAD `UNITS USER 1000`
- detected legacy FABmaster rejection
- malformed/empty recognized CAD/FAB ไม่สร้าง empty success
- XML → GenCAD → re-import semantic subset
- XML → FABmaster → re-import semantic subset
- UI export selector/File menu/PWA module wiring
- source-format-aware archive writer guard

รายละเอียดคำสั่งและผลอยู่ใน `TEST_REPORT_V0.25.0.md` และ `FINAL_TEST_LOG_V0.25.0.txt`

## 9. Build result

- Type check: PASS
- Security lint: PASS; มี review warning เดิมสำหรับ controlled legacy dynamic `innerHTML` แต่ไม่ใช่ lint failure
- Production build: PASS
- Production HTTP/MIME/manifest/build metadata/precache verifier: PASS
- Production precache: 41 assets
- Git commit hash: `unavailable` เพราะ source package ที่ได้รับไม่มี `.git` directory; build ไม่ปลอมค่า commit

## 10. PWA verification

- App ยังคง Static PWA / Browser-only
- `manifest.webmanifest` version 0.25.0
- `sw.js` cache key version 0.25.0 schema 2
- new `pcb-ascii-formats.js` อยู่ใน source offline precache และ generated production precache
- Production verifier ตรวจ HTTP/MIME/manifest/build metadata และ precache assets ผ่าน
- ไม่มี Node.js server requirement ใน runtime

ไม่ได้อ้างว่าได้ทดสอบ PWA install/offline reload บนอุปกรณ์ SMT/target device จริง

## 11. Supported formats

- Inspection CAD XML/CPO-like XML สำหรับ schema ที่ regression tests รองรับ
- Existing CSV/TXT CAD XY/BOM, XLSX mapping/report workflows
- Existing archive/ODB++ import subsets ตาม v0.24.0
- Grid/Land Map Excel เดิม

## 12. Partially supported formats

### GenCAD 1.4

Import/Export รองรับ semantic subset: board bounds/thickness, units, component placement/layer/rotation, device/part/package identity, pad/padstack, shape pin และ rectangular/circular pad size ที่ normalize เป็น Land ได้

ยังไม่ preserve/generate netlist, routes, vias และ arbitrary polygon pad geometry อย่างครบถ้วน

### FABmaster A!/J!/S!

Import/Export รองรับ semantic subset: component placement, recognized units, rectangular padstack size, pin placement และ board bounds/outline subset

ยังไม่ preserve/generate nets, traces/zones, vias, custom pad shapes และ full layer stack อย่างครบถ้วน

### IPC-2581 / ODB++ / Gerber / Excellon

คงสถานะ partial/diagnostic ตาม v0.24.0 ไม่มีการยกระดับ claim ในรุ่นนี้

## 13. Unsupported formats

- FABmaster legacy/FATF colon-section variant เช่น `:BOARDINFO/:PARTLIST/...` — detector รู้จักแต่ยังไม่มี adapter
- proprietary `.cad/.fab` variants ที่ไม่ตรง signature ที่รองรับ
- full machine-specific SMT program writer ที่ไม่มี specification/sample ที่ยืนยันได้

Input ที่ตรวจไม่รู้จักจะไม่ถูกสร้างเป็น Project ว่างแบบสำเร็จ

## 14. Known limitations

- `.cad/.fab` writers เป็น partial manufacturing-data writers ไม่ใช่ complete electrical/copper round-trip
- downstream EDA/Machine software แต่ละรายอาจต้องการ optional records เพิ่มเติม จึงต้อง validate กับ software เป้าหมายก่อน production use
- GenCAD output ใช้ precision 6 decimal inches; real XML verification มี max geometry delta ประมาณ 0.0000166 mm หลัง export/re-import
- FABmaster output ใช้ millimeter decimals; real XML verification มี numerical delta ระดับ floating-point (~1.14e-13 mm)
- ไม่มีการทดสอบกับ proprietary e-PM/Vayo/SMT machine จริง

## 15. Deployment instructions

1. ใช้ `universal-cad-editor-v0.25.0-production-build.zip`
2. แตก ZIP แล้ว upload **ทุกไฟล์ใน build พร้อมกัน** ไป Cloudflare Pages/GitHub Pages/Static Hosting
3. ห้ามอัปโหลดเฉพาะ `app.js`; HTML, Service Worker และ precache ต้องเป็น version เดียวกัน
4. เปิดออนไลน์หนึ่งครั้งเพื่อให้ Service Worker v0.25.0 activate
5. หากพบ update waiting ให้กด Update แล้ว reload
6. ทดสอบ import/export ด้วยไฟล์ production ขององค์กรก่อนใช้กับเครื่องจริง

## 16. Rollback instructions

1. เก็บ Project Backup ก่อน deploy v0.25.0
2. หากต้อง rollback ให้ deploy production build v0.24.0 **ทั้งชุด**
3. Reload ออนไลน์เพื่อให้ service worker/cache version เปลี่ยนกลับ
4. Project schema ยังเป็น 2 จึงสามารถเปิด backup v0.24.0 ได้ตามเดิม
5. ห้ามนำ `.cad/.fab` ที่ v0.25.0 สร้างไปถือเป็น source-of-truth แทน Original Source; Original Source/Project Backup ต้องเป็น rollback source หลัก

## Real-file cross-format verification

ใช้ Inspection XML ที่ผู้ใช้เคยแนบ (`R4125-B0013-02_R01_ODB-A_top_bottom.xml`) รัน `scripts/verify-pcb-cross-export.mjs` จริง:

- GenCAD 1.4: 1 Component / 72 Lands → re-import 1 / 72, max geometry delta 0.000016600000009248106 mm
- FABmaster ASCII: 1 Component / 72 Lands → re-import 1 / 72, max geometry delta 1.1368683772161603e-13 mm
- ทั้งสอง writer รายงาน `partial: true` และ warning 1 รายการตามข้อจำกัด writer
