# อัปเดต Universal CAD Studio v0.18.4

## การเปลี่ยนแปลง

1. ลบปุ่ม Apply → Mapping ด้านบนและ Apply ในเมนู File
2. เหลือปุ่ม Apply ด้านล่างเพียงปุ่มเดียว
3. เพิ่มกล่องยืนยัน Yes/No พร้อม Animation ก่อน Apply
4. ปิด Editor แล้วไม่ Apply อัตโนมัติ หากมีข้อมูลยังไม่ Apply จะถามก่อนทิ้ง
5. เพิ่ม Busy overlay และ task lock ป้องกันปุ่มค้างหรือกดคำสั่งซ้อน
6. เพิ่ม Lightweight selection เมื่อเลือกเกิน 160 Components
7. แก้ Escape ขณะเปิดเมนูให้ปิดเฉพาะเมนู ไม่ปิด Editor
8. ตรวจ event handler ของปุ่ม CAD Editor ทุกปุ่มและตรวจ HTML ID ซ้ำ

## วิธีอัปเดต

- เวอร์ชันเต็ม: ลบไฟล์เว็บชุดเดิม แล้วอัปโหลดไฟล์ในโฟลเดอร์ v0.18.4 ทั้งหมด
- Patch: อัปโหลดไฟล์ในแพตช์ทับไฟล์เดิม
- กด Ctrl + Shift + R หลัง Deploy
- หากยังเห็นรุ่นเก่า ให้ Unregister Service Worker และล้าง Site Data
