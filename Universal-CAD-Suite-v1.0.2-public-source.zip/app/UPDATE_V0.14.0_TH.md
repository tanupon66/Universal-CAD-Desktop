# วิธีอัปเดตเป็น v0.14.0

## อัปโหลดแบบเต็ม

แตก `universal-cad-editor-v0.14.0-full.zip` แล้วอัปโหลดไฟล์ทั้งหมดไปยัง GitHub Pages หรือ Cloudflare Pages แทนชุดเดิม

## อัปโหลดแบบ Patch

แตก `universal-cad-editor-v0.14.0-update.zip` แล้วอัปโหลดทับไฟล์เดิม โดยไฟล์สำคัญคือ:

- `index.html`
- `styles.css`
- `app.js`
- `archive-package.js`
- `odb-parser.js`
- `unix-compress.js`
- `sw.js`
- `manifest.webmanifest`

หลังอัปโหลดให้กด `Ctrl + Shift + R` หากยังเห็นเวอร์ชันเดิม ให้เปิด DevTools → Application → Service Workers → Unregister แล้วโหลดใหม่
