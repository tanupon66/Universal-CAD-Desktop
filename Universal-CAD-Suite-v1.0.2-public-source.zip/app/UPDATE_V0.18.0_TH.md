# อัปเดต Universal CAD Studio v0.18.0

## ฟังก์ชันใหม่

- เพิ่ม Undo / Redo ใน CAD Edit
- เพิ่มปุ่ม Undo / Redo และ History status
- รองรับ `Ctrl+Z`, `Ctrl+Y`, `Ctrl+Shift+Z`
- ทำให้เมนู File / Edit / View / Tools เปิดและเรียกคำสั่งจริง
- เพิ่มคำสั่ง Open, Apply, Export, Cut, Copy, Paste, Duplicate, Delete, Fit, Zoom, Grid, Label, Snap, Side, Full screen, Rotate, Flip, A1 และ Validate

## บัคที่แก้

- แก้ชื่อ CAD แล้วหน้าแรกยังแสดงชื่อเดิม
- Auto Fix และการแก้ชื่อรายแถวซิงก์กับ Viewer ทันที
- Mapping table, Detail panel, Duplicate detector และ Editor model ใช้ชื่อใหม่พร้อมกัน
- CAD Name Inspector แสดงชื่อปกติด้วย ไม่ซ่อนเฉพาะรายการที่มีปัญหา
- ค่าเริ่มต้นของตัวกรองเปลี่ยนเป็น “ทั้งหมด (รวมชื่อปกติ)”
- เพิ่มสถานะ “ปกติ” สำหรับชื่อที่ไม่มีปัญหา

## ไฟล์สำหรับอัปเดตจาก v0.17.0

อัปโหลดไฟล์ทั้งหมดในแพตช์ทับของเดิม แล้วกด `Ctrl + Shift + R`

Cache ใหม่: `universal-cad-studio-v0.18.0`
