# Universal CAD Studio v0.22.0 — Grid Mapping / Grid Rename Separation

รุ่นนี้แก้ปัญหาชื่อ Land ข้ามเลขบน sparse grid, ย้าย Grid Rename ไปอยู่ใน CAD Name Inspector พร้อม Preview และทำให้ Grid Map ทำหน้าที่ Mapping เท่านั้น

## วิธีใช้ Grid Mapping

1. Import CAD และข้อมูลต้นทาง CSV/TXT/XLSX/Raw Mapping
2. เปิด CAD Editor และเลือก Component 1 ตัว
3. กด **Grid Map**
4. เลือกลำดับแถว/คอลัมน์และทิศทาง
5. ตรวจ Preview `Source → CAD Land`
6. กด **Yes - Apply Grid Mapping**

ผลลัพธ์เป็น Suggested Mapping, ไม่เปลี่ยนชื่อ CAD และรักษา Manual/Confirmed Mapping ตามค่าเริ่มต้น

## วิธีเปลี่ยนชื่อแบบ Grid

1. เลือก Component แล้วกด **ตรวจชื่อ…** หรือเปิดเมนู **ตรวจสอบชื่อ**
2. กด **เปลี่ยนชื่อแบบ Grid พร้อม Preview…**
3. เลือกรูปแบบ:
   - A1/A2 แบบต่อเนื่องไม่ข้ามช่องว่าง
   - A1/A2 ตาม physical grid
   - LAND 1/LAND 2/LAND 3
   - เลขล้วน
4. ตั้งทิศ, start, step, padding, prefix และความยาวชื่อสูงสุด
5. ตรวจ Preview/Validation แล้ว Apply

## Error ที่แก้

`closeLandMapExporter()` ไม่เกิด `Cannot set properties of undefined (setting 'model')` อีกเมื่อ Project ถูก reset หรือเปิดจาก state รุ่นเก่า
