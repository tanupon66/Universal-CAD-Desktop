# Changelog

## 0.25.2 — 2026-08-20

- Fixed machine XML export incompatibility: XML export now emits VT-X/ePM-style `DataList` schema instead of the internal simplified `InspectionData` schema.
- Added `InspectionProjectXml`, `InspectionRegionCollectionSetXml`, `ComponentInformationCollectionXml`, `ComponentNumberCollectionXml`, `LandNumberCollection`, and rectangular `FeatureList` output.
- Normalized geometry coordinates/dimensions to at most 3 decimal places and angles to at most 5 decimal places, eliminating IEEE-754 artifacts such as `158.15399999999997`.
- Export IDs are re-indexed sequentially and internal component/land relationships are rewritten consistently for the machine export snapshot.
- Removed the custom UniversalCAD XML comment from machine-compatible XML output; export audit data remains in the project session/diagnostic state.
- Existing CAD/FAB import/export, Grid/Land Map, transactions, PWA, autosave, mapping, validation and Excel workflows remain unchanged.
- Added VT-X/ePM XML schema + precision regression tests.


## 0.25.1 — 2026-08-20

### Fixed

- Fixed large `.cad/.fab` members inside ZIP being silently skipped when their uncompressed size exceeded the former 120 MiB scan cap.
- Added memory-bounded streaming import for FABmaster/Cadence `A!/J!/S!` files so multi-million trace/graphic rows are scanned without materializing the full decompressed file or every ignored row.
- Direct large `.cad/.fab` preflight now reads only the first 1 MiB before handing the file to the streaming adapter instead of creating a full-file probe buffer.
- Board dimensions for large FABmaster files now prefer `BOARD GEOMETRY / OUTLINE` records over broad J-record drawing extents, preventing the CAD view from zooming out to an unrealistic drawing/panel envelope.
- Large-file diagnostics now report the real archive member, uncompressed byte size, streaming line count, Component/Land count and unsupported record categories instead of returning only “no supported CAD”.

### Verified with user-supplied file

- `CAD_T99O089T00_045_20180921.zip` contains `FAB_T99O089T00_045_20180921.cad` (271,523,369 uncompressed bytes / 3,844,879 parsed lines).
- Streaming import produced 4,714 Components, 16,027 valid Lands, 128 Packages, MIL units and a 313.500008 × 215.829896 mm board profile.
- Six pin rows in the source have an empty `REFDES`; they are intentionally not attached to a Component.

### Compatibility

- Project schema remains version 2.
- No Grid/Land Map, Name Inspector, Transaction, Apply, Undo/Redo, Autosave, Excel or existing CAD/FAB writer API was removed.
- Original ZIP bytes remain immutable; the streaming candidate is only a normalized Working Model view.

## 0.25.0 — 2026-08-20

### Added

- GenCAD 1.4 content detector/import adapter for `.cad` files
- FABmaster ASCII A!/J!/S! detector/import adapter for `.fab` and content-matching `.cad` files
- Cross-format export selector: Inspection XML, GenCAD 1.4 `.cad`, FABmaster ASCII `.fab`
- Partial GenCAD/FABmaster writers using the current Applied CAD Revision
- Non-secret GenCAD/FABmaster fixtures, content-signature tests and XML → CAD/FAB → re-import semantic tests
- Explicit diagnostic for detected but unsupported FABmaster legacy/FATF variants

### Changed

- File type routing now uses format signatures before extension for `.cad`/`.fab` ambiguity
- Archive candidate scanning includes `.fab` and `.gcd` text entries
- CAD Editor Ctrl+E exports the format currently selected in the footer; explicit per-format File menu commands remain available
- Runtime/PWA version updated to 0.25.0 and new parser/writer module is included in offline precache

### Compatibility

- Project schema remains version 2
- Existing Grid/Land Map, Name Inspector, Transaction/Undo/Redo, Apply, Mapping, Autosave and Excel workflows retain their existing APIs
- Original source bytes/text remain immutable; imports normalize into the existing Working Model
- GenCAD/FABmaster writers truthfully report partial coverage and do not claim complete netlist/route/via/custom-polygon preservation

## 0.24.0 — 2026-07-31

### Changed

- Reworked **Grid / Land Map** so the generated name is the source side of the mapping and the existing CAD Land name is the target side
- Grid / Land Map no longer depends on imported XLSX/CSV source records and no longer assumes that `A1`, `A2`, `B1`, `B2` already exist in the source data
- Added selectable generated-name formats: coordinate Grid (`A1`, `A2`, `B1`), `LAND 1...N`, and number-only `1...N`
- Added configurable start row, start column, column step, sequence start, sequence step, zero padding, prefix, separator, suffix, row/column traversal, and all four start corners
- Added compact-gap and physical-gap modes so users can choose whether empty Grid cells consume a coordinate number
- Added per-Land manual alias override directly from the Grid preview without renaming the CAD Land
- Excel export now explicitly shows **New name ↔ CAD Land name** and uses the exact active Preview settings

### Fixed

- Removed the overlapping source-sequence/confirmed-mapping controls from Grid / Land Map
- Fixed the conceptual error where Grid Map paired external source rows instead of generating the new Land Map name requested by the user
- Saved Grid/Land mappings now persist in Autosave and Project Backup through workspace schema 2
- Added Grid/Land mappings to JSON Model export while preserving immutable CAD source data
- Added regression coverage for bottom-right start, column-major traversal, custom row/column starts, steps, padding, manual override, and CAD-name preservation

### Compatibility

- Project/CAD schema remains version 2; workspace records migrate safely because the new `gridLandMappings` field is optional
- Older projects open with an empty Grid/Land mapping store and no CAD data is changed
- The CAD Name Inspector remains the only workflow that renames CAD Land names
- Static PWA, offline shell, Cloudflare Pages and GitHub Pages deployment remain supported

## 0.23.0 — 2026-07-31

### Changed

- Unified **Grid Map** and **Land Map** into one `Grid / Land Map` workflow and one preview/source of truth
- Replaced PowerPoint/SVG Land Map output with local Excel `.xlsx` output
- Excel contains an editable physical `Grid Map` sheet and a normalized `Land Data` sheet with Mapping status, IDs, coordinates and dimensions
- Removed the separate toolbar/footer/menu action and modal for `Export Land Map`

### Fixed

- Eliminated duplicated export controls, standalone Land Map state, Object URL lifecycle and the previous close-state failure surface
- Grid preview and Excel export now use the same order, row direction, column direction, proposed Mapping plan and fallback LAND sequence
- When no source records are available, the preview displays the same generated LAND sequence that will appear in Excel instead of `LAND —`
- Removed the vendored PowerPoint runtime and stale PWA precache entries

### Compatibility

- Project schema remains version 2; no CAD, Mapping, Backup or Autosave migration is required
- Grid Mapping still changes Mapping only; CAD name changes remain in the Name Inspector workflow
- Static PWA, offline shell, Cloudflare Pages and GitHub Pages deployment remain supported

## 0.22.0 — 2026-07-31

### Fixed

- Fixed sparse-grid naming that consumed empty physical cells and could jump from `B4` to `B6`; the new compact coordinate mode numbers occupied Lands continuously
- Fixed `closeLandMapExporter()` crashing with `Cannot set properties of undefined (setting 'model')` after reset/import by using a single CAD editor state factory and a compatibility state guard
- Fixed successful imports being recorded as `success: false` in performance diagnostics
- Fixed Mapping transaction snapshots dropping mapping history and audit fields during Undo/Redo
- Fixed alphanumeric CAD target IDs being compared through numeric coercion
- Removed a duplicate Applied-Revision preflight call in SVG Land Map export
- Removed obsolete naming controls/listeners and the deployable legacy preview page that duplicated the current workflow

### Changed

- **Grid Map** is now mapping-only: it pairs imported source records with occupied CAD Lands and never changes CAD Land names
- Grid mapping preserves Manual/Confirmed targets, marks generated pairs as Suggested, records audit history and ignores empty grid cells when advancing the source sequence
- Grid-style renaming moved to **ตรวจสอบชื่อ** with a dedicated Preview and validation before Apply
- The CAD dock now exposes one naming entry point instead of multiple overlapping renumber actions

### Added

- Compact coordinate naming (`A1, A2…`) that does not skip numbers across sparse rows
- Physical coordinate naming for users who intentionally need empty grid positions to affect the label
- Sequential naming modes: `LAND 1, LAND 2, LAND 3…` and number-only `1, 2, 3…`
- Start number, step, zero padding, prefix, row/column order and directional controls
- Regression fixture for a sparse 6,807-Land component and direct test for the reported Land Map close-state crash

### Compatibility

- Schema remains version 2; v0.20.0/v0.21.0 projects, backups and autosave records remain compatible
- No source CAD object is renamed by Grid Map; naming changes still pass through the CAD Name Inspector working model
- Runtime remains a static Browser/PWA deployment with no Node.js server requirement

## 0.21.0 — 2026-07-31

### Added

- Board-level rotate left/right 90°, rotate 180°, mirror left-right and mirror top-bottom with confirmation and Undo/Redo
- Automatic Land grid detection and whole-row/whole-column rename headers
- Grid direction, separator, duplicate/collision validation and atomic Apply
- Editable Land Map export to PowerPoint and SVG with mapping/sequential numbering
- Local PptxGenJS bundle and license for fully static/offline export
- Actual 72-Land LGA XML verification and four new regression scripts

### Fixed

- Preserve-source XML writer now updates Board Width/Height after Board rotation
- Land Map preview Object URL cleanup when modal/editor closes
- SVG export metadata is generated once from Applied Revision metadata
- PWA precache includes Board/Grid/Land Map modules and local PPTX runtime

### Compatibility

- Schema remains version 2; v0.20.0 projects/backups/autosave remain compatible
- Original source remains immutable; Board/Grid changes stay in Working Model until Apply
- Static PWA and Cloudflare Pages/GitHub Pages deployment remain supported

## 0.20.0 — 2026-06-26

### Fixed

- ทำ Apply เป็น atomic preparation/commit flow และ Rollback Editor, Mapping, file view และ Project Revision เมื่อผิดพลาด
- แก้ large CAD task ที่ส่ง argument เข้า `runCadEditorTask` ผิดตำแหน่งจน task callback กลายเป็น string เมื่อเกิน threshold
- แก้ Mapping อ่าน CAD Revision เก่าและรองรับ CAD-only mapping โดยไม่บังคับ Raw Data
- แก้ Archive apply ไม่ให้แก้ candidate bytes ของ Original Source in-place
- แก้ Modal Apply/Export/Confirm ให้ Cancel, Close, Escape และ cleanup scroll/pointer/focus/loading ทำงานผ่าน `finally`
- แก้ Recovery ที่ส่ง parsed model เข้า Editor API ซึ่งเดิมรับเฉพาะ XML string
- แก้ Standalone XML writer ให้รักษา Board Name และไม่แปลง numeric attribute ว่างเป็น `0`
- แก้ Service Worker asset list แบบ manual ที่เสี่ยงตกหล่นโมดูลใหม่และโหลด JavaScript คนละเวอร์ชัน
- แก้ Autosave และ Service Worker update background errors ที่เคยถูกกลืนด้วย empty catch; เพิ่ม lint gate ป้องกันการกลับมา

### Added

- Universal CAD Model schema v2, Project Session, Revision, Change Set และ Compatibility View
- Transaction Engine พร้อม validate-before-commit, inverse command, undo/redo และ rollback
- Typed errors: Import, Parse, Archive, Validation, Geometry, Transaction, Mapping, Export, Storage, Worker และ Migration
- Geometry safety และ Land split/merge/difference operations; Editor UI มี Cut ½ และ Merge ที่ Undo/Redo ได้
- Format Detector จาก extension/MIME/magic bytes/archive structure/XML root/namespace/encoding
- IPC-2581 partial adapter, CSV/TXT XY/BOM importer และ secure archive/XML checks
- Validation Center และ Export Preflight พร้อม severity Info/Warning/Error/Blocking Error
- Mapping audit/status/manual preservation/conflict detection
- CSV/Excel formula-injection protection และ safe filenames
- IndexedDB Autosave/Recovery, Project Backup, Import Backup, Duplicate/Delete Project, Clear temporary cache และ Storage usage
- Central unit/coordinate transformation matrix และ spatial index สำหรับ hit testing
- Performance diagnostics สำหรับ import/mapping/render/apply/export durations โดยไม่บันทึก CAD payload
- Static production build, generated precache manifest, build metadata และ production HTTP verifier
- Round-trip semantic test: XML import → export → re-import → compare

### Compatibility

- Legacy parser/editor/mapping field shapes ยังคงใช้งานผ่าน Compatibility Adapter
- ไม่มี field เดิมถูก rename
- Project เก่าถูก wrap เป็น schema v2 revision 0 เมื่อ Apply/Autosave/Import Backup
- MIT `LICENSE` เดิมถูกรักษาและถูกรวมใน Production Build

### Known limitations

- IPC-2581 เป็น partial adapter และยังไม่มี full writer
- Gerber/Excellon ยังไม่มี geometry viewer/editor/writer ครบถ้วน
- ODB++ import รองรับเฉพาะโครงสร้างที่ parser รู้จัก; ยังไม่เขียนกลับเป็น ODB++ `components.Z`/`eda/data.Z`
- Interactive arbitrary polygon Trim/Boolean preview UI ยังไม่ครบ; core geometry/transaction APIs มีบาง operation และ UI เปิดใช้ safe rectangular Cut/Merge
- ยังไม่ได้ย้าย parser/geometry ทั้งหมดไป Web Worker; ใช้ cancellable chunking, pagination และ spatial index แทนในรุ่นนี้
- ไม่ได้ทดสอบกับเครื่อง SMT จริง
