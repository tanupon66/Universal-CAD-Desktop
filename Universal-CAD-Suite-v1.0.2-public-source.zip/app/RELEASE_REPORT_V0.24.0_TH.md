# รายงาน Release — Universal CAD Studio v0.24.0

## 1. Baseline ก่อนแก้

Baseline คือ v0.23.0 ซึ่งรวม Grid Map และ Land Map แล้ว แต่ Grid Map ยังใช้ source record จาก XLSX/CSV เป็นฝั่งต้นทาง จึงไม่ตรงกับ Workflow ที่ต้องการสร้างชื่อใหม่เอง เช่น `A1` หรือ `LAND 1` แล้ว Mapping ไปยังชื่อ Land เดิมใน CAD

## 2. Root cause

- UI และ logic ตีความ `A1/A2` หรือเลข LAND เป็น source record ที่มีอยู่ก่อน แทนที่จะเป็น generated mapping alias
- `buildGridMappingPlan()` จับคู่ external source row กับ CAD target จึงใช้งานไม่ได้เมื่อไม่มี Raw/XLSX source
- Excel ใช้คำว่า Source Mapping และ fallback sequence ทำให้ความหมายของชื่อใหม่กับชื่อ CAD ไม่ชัดเจน
- การตั้งค่าเริ่มต้น, step, prefix/suffix และการแก้เฉพาะจุดกระจายอยู่คนละ Workflow

## 3. Architecture changes

เพิ่ม generated Grid/Land mapping layer แยกจาก CAD name และแยกจาก external Mapping:

- `buildGeneratedLandMapPlan()` สร้างชื่อใหม่จาก configuration
- แต่ละรายการเก็บ `newName ↔ cadName ↔ XML Land ID`
- `gridLandMappings` เก็บต่อ Project/Component
- Autosave workspace schema เพิ่มจาก 1 เป็น 2 โดย field ใหม่เป็น optional
- CAD Name Inspector ยังคงเป็น Workflow เดียวที่เปลี่ยนชื่อ CAD จริง

## 4. Files changed

- `app.js`
- `index.html`
- `styles.css`
- `land-grid-mapper.js`
- `grid-map-excel.js`
- `xlsx-report.js`
- `package.json`
- `manifest.webmanifest`
- `sw.js`
- `diagnostics.js`
- `scripts/verify-grid-map-input.mjs`
- `tests/test-land-grid-mapper.mjs`
- `tests/test-grid-map-excel.mjs`
- `tests/test-v024-grid-land-map-static.mjs`
- เอกสาร Release/Changelog

## 5. Bugs fixed

- Grid/Land Map ไม่ต้องมี XLSX/CSV source อีกต่อไป
- Generated name ไม่ถูกสับสนกับ CAD name
- การเริ่มจากมุมล่างขวา/บนซ้ายและ Column-major ทำงานตาม configuration
- Compact mode ไม่กินลำดับจากช่องว่าง
- Excel ไม่เติมคำ `LAND` ซ้ำโดยบังคับ และแสดงชื่อใหม่ตาม Preview จริง
- Mapping ที่ Apply แล้วถูกกู้คืนจาก Autosave/Project Backup ได้

## 6. Features added

- Grid name เช่น `A1, A2, B1, B2`
- `LAND 1...N`
- Number only
- Row start, column start, column step
- Sequence start, step, padding
- Prefix, separator, suffix
- Row-major/column-major
- Top/bottom และ left/right direction
- Compact/physical gap
- Manual override ราย Land
- Excel 2 ชีตแสดง New name ↔ CAD Land name

## 7. Migration

Project/CAD schema ยังคงเป็น 2 ส่วน Workspace schema เป็น 2 โดยโปรเจกต์เก่าที่ไม่มี `gridLandMappings` จะสร้าง store ว่างอัตโนมัติ ไม่มีการเปลี่ยน field เดิมหรือแก้ XML ต้นฉบับ

## 8. Tests executed

ดู `TEST_REPORT_V0.24.0.md` และ `FINAL_TEST_LOG_V0.24.0.txt` ผลสุดท้าย 47/47 scripts ผ่าน ไม่มี test ข้าม

## 9. Build result

`npm run build` ผ่านและสร้าง Static Production Build v0.24.0 โดยไม่ต้องใช้ Node.js Server ใน Runtime

## 10. PWA verification

Manifest, Service Worker, cache version, generated precache manifest, HTTP และ MIME verification ผ่าน ระบบยัง Deploy บน GitHub Pages/Cloudflare Pages และมี Offline fallback

## 11. Supported formats

ความสามารถ Import/Export format เดิมจาก v0.23.0 ยังคงอยู่ การอัปเดตนี้เปลี่ยนเฉพาะ Grid/Land mapping layer และ Excel output

## 12. Partially supported formats

IPC-2581, Gerber, Excellon และ ODB++ writer ยังคงมีข้อจำกัดตามรายงาน v0.23.0

## 13. Unsupported formats

รูปแบบ proprietary ที่ไม่มี Adapter จะถูกปฏิเสธพร้อม Diagnostic โดยไม่สร้าง Project ว่าง

## 14. Known limitations

- Grid detection ยังอาศัย geometry clustering; Land ที่เบี่ยงพิกัดมากอาจต้องปรับ geometry ก่อน
- Manual override ทำได้ราย Land แต่ยังไม่มีการ paste ตาราง override หลายพันรายการจาก Clipboard ในรุ่นนี้
- Grid/Land mapping alias ไม่ถูกเขียนลง Inspection XML เพราะ XML schema เดิมไม่มี field สำหรับ alias; ข้อมูลอยู่ใน Project Backup/Autosave/JSON/Excel
- ไม่ได้ทดสอบกับเครื่อง SMT จริง

## 15. Deployment instructions

แตก Production Build ZIP แล้วอัปโหลดไฟล์ภายในทั้งหมดไปยัง GitHub Pages, Cloudflare Pages หรือ Static Hosting ห้ามอัปโหลดเฉพาะ `app.js` เพราะ Service Worker, HTML และ precache manifest ต้องตรงกัน

## 16. Rollback instructions

เก็บ Production Build v0.23.0 ไว้เป็นชุด หากต้อง rollback ให้อัปโหลดไฟล์ v0.23.0 ทั้งชุด แล้วล้าง Service Worker/cache หรือเปิดแอปหนึ่งครั้งเพื่อให้ Service Worker รุ่นเดิม activate ห้ามผสมไฟล์สองเวอร์ชัน
