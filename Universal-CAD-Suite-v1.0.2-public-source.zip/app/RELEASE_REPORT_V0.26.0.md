# Universal CAD Studio v0.26.0 Release Report

## Status
Production gate passed. Static PWA; no runtime Node server required.

## Major additions
- NPI Workspace with compatibility profiles, conversion-loss reporting, CAD health, visual validation markers, package library/recognition, package-level mapping, CAD/BOM/placement reconciliation, smart revision comparison, three-way source/working/export comparison, revision timeline, coordinate calibration, panel arrays, project workspace summary, golden-template analysis/compare/merge, and custom export profiles.
- BOM Export Designer: CSV/XLSX, column or row orientation, reorderable fields; Location can be moved to column B or any position.
- Grid/Land Map 2.0 sequencing modes retained and expanded without renaming CAD implicitly.
- English-only runtime UI and neutral product terminology.
- Refreshed responsive visual system while preserving static PWA architecture.

## Compatibility
Existing schema remains version 2. Existing CAD editor, mapping, Apply transactions, Undo/Redo, validation, autosave/recovery, board transforms, Grid/Land Map, XML/CAD/FAB import/export and Excel exports remain present.

## Final gate
- Type check: 102 JavaScript modules passed.
- Security lint: passed; two controlled dynamic-innerHTML locations remain review warnings (app.js, npi-workspace-ui.js).
- Automated tests: 53/53 passed; failed 0; skipped 0.
- Production build: passed.
- Production verifier: passed HTTP/MIME/manifest/build metadata and 45 precache assets.
- Git commit metadata: unavailable because the supplied working source was not a Git repository; build records `unavailable` rather than inventing a hash.

## Known limitations
- Some CAD/FAB writers remain partial for electrical/layer records not represented in the normalized model.
- Golden-template structural merge is conservative and requires compatible XML roots.
- Browser/device installation and real production equipment acceptance were not claimed or simulated by this release gate.
