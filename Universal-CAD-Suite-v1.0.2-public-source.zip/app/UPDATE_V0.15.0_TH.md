# วิธีอัปเดตเป็น Universal CAD Editor v0.15.0

## แนะนำ: อัปโหลดเวอร์ชันเต็ม

1. สำรองโฟลเดอร์เว็บไซต์เดิม
2. ลบไฟล์เว็บไซต์ชุดเดิม
3. แตก `universal-cad-editor-v0.15.0-full.zip`
4. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์ `universal-cad-editor-v0.15.0` ขึ้น GitHub Pages หรือ Cloudflare Pages
5. เปิดเว็บไซต์แล้วกด `Ctrl + Shift + R`

## อัปเดตแบบทับไฟล์

แตก `universal-cad-editor-v0.15.0-update.zip` แล้วอัปโหลดทับไฟล์เดิม โดยต้องอัปโหลดอย่างน้อย:

- `index.html`
- `styles.css`
- `app.js`
- `cad-editor.js`
- `sw.js`
- `manifest.webmanifest`

## ล้าง Cache หากยังเห็น UI รุ่นเก่า

Chrome DevTools → Application → Service Workers → **Unregister** แล้วโหลดหน้าใหม่

Cache รุ่นนี้: `universal-cad-editor-v0.15.0`
