# Rollback Instructions

## Application rollback

1. เก็บ Production Build ZIP ของรุ่นก่อนหน้า
2. Deploy contents ของ build รุ่นก่อนหน้าทั้งชุด ไม่คัดเฉพาะ `app.js`
3. ตรวจว่า `package version`, manifest version, UI title/badge และ service-worker cache version ของ build นั้นตรงกัน
4. เปิดออนไลน์และรอ worker รุ่น rollback install; กด Update หากมี waiting worker
5. หาก hosting/CDN เก็บไฟล์เก่า ให้ purge cache ของ `index.html`, `sw.js`, `precache-manifest.js`, manifest และ JS

## Project rollback

- ก่อนเปลี่ยนรุ่น ให้ใช้ **Export Project Backup**
- หาก transaction ปัจจุบันผิดพลาด ใช้ Undo/Redo หรือ re-import backup; Apply failure rollback อัตโนมัติ
- หาก Autosave ล่าสุดไม่ต้องการ ให้เปิด Storage Manager, duplicate record ก่อน แล้วจึง delete/clear temporary cache
- Original Source ไม่ถูกแก้ จึงสามารถ import source เดิมอีกครั้งได้

## Source-control rollback สำหรับผู้พัฒนา

Source archive ที่ใช้สร้าง v0.23.0 ไม่มี `.git` metadata จึงไม่สามารถยืนยัน commit hash สำหรับรุ่นนี้ได้จากสภาพแวดล้อม Build. ให้ tag/commit source หลังนำเข้า repository ของคุณ แล้ว rollback ด้วย `git revert` จาก commit/tag ที่คุณสร้างเอง ห้ามอาศัย hash จากรายงานรุ่นเก่า.
