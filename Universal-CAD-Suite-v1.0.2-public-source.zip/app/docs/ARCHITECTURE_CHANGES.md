# Architecture Changes — v0.20.0

## ก่อนแก้

PWA ใช้ native ES modules และ mutable singleton state ใน `app.js`. Parser, CAD Editor, Mapping และ Export ทำงานได้ แต่ถือ object คนละชุดและไม่มี revision transaction/storage boundary

## หลังแก้

### Data lifecycle

1. **Original Source** — text/bytes และ archive entries ที่นำเข้า; immutable
2. **Parsed Source Model** — normalized result จาก adapter; ไม่ใช่ editing source โดยตรง
3. **Working Model** — copy-on-write model สำหรับ Editor/preview/transaction
4. **Applied Revision** — model ที่ validate และ commit แล้ว พร้อม revision/change set
5. **Export Snapshot** — immutable snapshot ของ applied revision + validation/metadata สำหรับ writer

### Source of truth

`project-session.js` จัดการ current project/revision. `universal-cad-model.js` กำหนด schema v2. `state.xmlData`, `cadFiles[role].data`, Editor model และ mapping rows เดิมยังอยู่เพื่อ compatibility แต่ถูก refresh หลัง project commit เท่านั้น

### Universal model entities

Project, Source Files, Board Definition, Panel Definition/Instance, Layer, Component, Package, Land, Pin, Net, Hole, Fiducial, BOM, Coordinate System, Units, Transformation, Metadata, Validation Issue, Revision และ Change Set

### Transaction boundary

`transaction-engine.js` ใช้ command + inverse command บน working copy. ทุก command validate ก่อน commit, เพิ่ม revision/change set และสามารถ undo/redo. Apply UI ใช้ project-level checkpoint เพื่อ rollback legacy views และ session พร้อมกัน

### Import boundary

`format-detector.js` ตรวจ extension/MIME/magic/archive/XML metadata. `import-adapters.js` และ `delimited-import.js` แปลง source เข้า normalized model โดย report unsupported records. Archive reader มี traversal/bomb limits

### Validation/export boundary

`validation-center.js` สร้าง issues ตาม severity และ preflight. Exporter ใช้ `createProjectExportSnapshot` จาก revision ล่าสุด; CSV/XLSX ผ่าน `export-safety.js`

### Storage boundary

`project-storage.js` เก็บ complete revision record ใน IndexedDB `universal-cad-studio` schema version 1. Autosave debounce หลัง transaction/import complete เท่านั้น; record มี recovery marker และ CAD archive expanded copies ไม่ถูกเก็บซ้ำโดยไม่จำเป็น

### PWA boundary

Build script สร้าง static `dist/`, `build-info.json` และ `precache-manifest.js`. Service Worker cache ผูก app/schema version และมี explicit update flow

## Compatibility decisions

- ไม่เปลี่ยน framework และไม่ rewrite `app.js` ทั้งหมด
- ไม่ rename legacy fields
- เพิ่ม adapters/session เหนือ parser/editor เดิม
- internal API ที่ต้องขยายใช้ overload/additive exports
- archive/XML writers เดิมถูกห่อด้วย snapshot/preflight แทนการแทนที่ทั้งหมด
- ไม่มี runtime server/native binary dependency
