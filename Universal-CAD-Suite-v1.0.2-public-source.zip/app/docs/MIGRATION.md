# Migration Note — v0.19.x to v0.20.0

## Project data

- Legacy in-memory CAD ถูก wrap เป็น Universal CAD schema v2 revision 0 เมื่อ Import/Apply/Autosave
- ไม่มี legacy field ถูก rename; Compatibility View ยังคง shape เดิม
- Mapping เดิมที่ import จาก backup ยังคงใช้ได้และจะถูก tag ด้วย active revision เมื่อ commit ครั้งถัดไป
- Full Project Backup v0.20.0 เป็น additive; Mapping Backup เดิมยัง import ได้

## Browser storage

- IndexedDB database: `universal-cad-studio`
- Database version: 1
- Project schema version: 2
- Autosave record ต้องมี complete recovery marker ก่อนจึงเสนอ Recovery
- Autosave ไม่เขียนทับ Original Source และไม่ลบ project เก่าเมื่อ import ใหม่

## Service Worker/cache

- Cache name เปลี่ยนเป็น `universal-cad-studio-v0.20.0-schema2`
- activation ลบ cache รุ่นเก่าที่มี prefix เดียวกัน
- หน้า app แจ้งเมื่อ worker ใหม่ waiting; กด Update เพื่อ `skipWaiting` แล้ว reload หลัง `controllerchange`

## Migration safety

1. Export Project Backup จาก v0.19 ก่อนอัปเดต หากมีงานสำคัญเปิดค้าง
2. Deploy `dist/` v0.20.0 ทั้งชุด ห้ามคัดเฉพาะบางไฟล์
3. เปิดออนไลน์หนึ่งครั้งเพื่อ install service worker/cache ใหม่
4. Import project/backup หรือเลือก Recovery เมื่อแอปพบ complete record
5. ตรวจ Revision/Validation ก่อน Export

หาก migration validation ล้มเหลว ระบบจะไม่ commit record ใหม่และแสดง `MigrationError`/Diagnostic แทนการเขียนทับข้อมูลเดิม

## v0.20.0 → v0.21.0

- Schema remains 2; no project data migration is required.
- New Board/Grid/Land Map fields are UI/runtime-only and do not rename legacy fields.
- Cache name changes to `universal-cad-studio-v0.21.0-schema2`; deploy the complete asset set so the Service Worker cannot mix versions.

## v0.21.0 → v0.22.0

- Project schema remains 2; no CAD data field is renamed and no destructive migration is required.
- Legacy runtime/editor states that do not contain `cadEditor.landMap` or `cadEditor.gridMapper` are repaired through the state compatibility factory when opened or reset.
- Grid Map no longer writes CAD names. Existing CAD names remain unchanged; imported/manual mappings remain in the Mapping model.
- Grid-style CAD renaming is now performed from CAD Name Inspector and uses its existing rename map/validation workflow.
- Existing Manual/Confirmed mappings are preserved by default when applying Grid Mapping. New grid-generated pairs are Suggested mappings and retain audit history.
- Cache changes to `universal-cad-studio-v0.22.0-schema2`. Deploy the full production package so HTML, JavaScript, precache manifest and Service Worker cannot be mixed with v0.21.0.

## v0.22.0 → v0.23.0

- Project schema remains 2 and no persistent CAD/Mapping field is renamed.
- The transient `cadEditor.landMap` UI state is removed; it was never part of Project Backup or Autosave schema.
- Grid Mapping data and Manual/Confirmed Mapping records remain compatible.
- PowerPoint/SVG output is removed and replaced by Excel from the unified Grid/Land Map modal.
- Cache changes to `universal-cad-studio-v0.23.0-schema2`; deploy the full package to avoid mixing the old PPTX runtime with the new JavaScript/HTML.

## v0.23.0 → v0.24.0

- Project/CAD schema ยังเป็น 2
- Workspace schema เพิ่มเป็น 2 และเพิ่ม optional field `gridLandMappings`
- Backup/Autosave เก่าที่ไม่มี field นี้จะสร้าง mapping store ว่างอัตโนมัติ
- Mapping Alias ไม่เขียนลง Inspection XML และไม่เปลี่ยน `cadName`
- Deploy ต้องเปลี่ยนไฟล์ทั้งชุดเพื่อให้ Service Worker cache เป็น v0.24.0

## v0.24.0 → v0.25.0

- Project/CAD schema remains version 2; no persistent field is renamed and no destructive migration is required.
- GenCAD/FABmaster imports are normalized through Compatibility Adapters into the same Working Model used by XML; Original Source text/bytes remain immutable.
- Existing v0.24.0 Grid/Land aliases, Name Inspector state, Mapping history, Autosave and Project Backup continue to load unchanged.
- Export format selection is UI/runtime state only and is not required in old Project Backup records.
- Archive rewrite is now source-writer aware: Inspection XML, GenCAD 1.4 and FABmaster ASCII can be written back to a matching nested source record; ODB++/IPC-2581 archive rewrite is blocked until matching writers exist.
- Service Worker cache changes to `universal-cad-studio-v0.25.0-schema2`; deploy the complete production build at once.

## v0.25.0 → v0.25.1

No Project schema migration is required. Schema remains 2. The release changes only import/runtime handling for large FABmaster files and PWA cache versioning. Deploy the complete v0.25.1 production package so the Service Worker does not mix v0.25.0 JavaScript with v0.25.1 modules.
