# Root Causes and Fixes — v0.20.0

## 1. Apply ล้มเฉพาะไฟล์/ข้อมูลขนาดใหญ่

**Root cause:** caller ของ `runCadEditorTask` ส่งจำนวน/ลำดับ argument ผิด ทำให้ parameter ที่ควรเป็น callback กลายเป็นข้อความเมื่อเข้า async threshold path

**Fix:** แก้ signature/caller, validate callback และเพิ่ม responsiveness/apply regression test

## 2. Apply สำเร็จแต่ Mapping ยังเป็นข้อมูลเก่า

**Root cause:** code publish `file.data`/`editedText` ก่อน mapping preparation เสร็จ และ catch mapping error เป็น warning จึงไม่มี atomic boundary

**Fix:** prepare XML, parsed CAD, working model, mapping, validation และ revision แยกจาก state จริง จากนั้น commit พร้อมกัน; failure คืน rollback snapshot ทั้งชุด

## 3. TGZ ใช้ได้แต่ XML/Archive บางชนิดผิดพลาด

**Root cause:** import path แตกต่างกัน, detector พึ่ง extension/entry assumptions, nested root ไม่ถูก normalize และ standalone XML path ขาด archive metadata ที่ TGZ path มี

**Fix:** เพิ่ม content-based Format Detector, XML root/namespace/encoding handling, nested archive search, safe candidate selection และ standalone/archived XML compatibility tests

## 4. Original Source ถูกแก้ระหว่าง Apply

**Root cause:** archive candidate bytes ถูกแทนที่ใน object เดียวกับ imported package

**Fix:** immutable source record + copy-on-write rebuild; Export Snapshot สร้าง archive ใหม่โดย preserve entries เดิม

## 5. Editor, Mapping และ Export ไม่ตรงกัน

**Root cause:** มี mutable snapshots หลายชุด (`file.data`, `state.xmlData`, editor model, mapping rows) และ exporter แต่ละตัวเลือก source เอง

**Fix:** Universal CAD Project Session เป็น revision source of truth; legacy state เป็น compatibility view ที่ update หลัง commit เท่านั้น; Mapping/Validation/Export รับ revision/snapshot เดียวกัน

## 6. Mapping บังคับ Raw Data และ Reference ที่ไม่ใช่ตัวเลขถูกตีความผิด

**Root cause:** mapping builder เดิมถูก gate ด้วย XLSX และ normalization มีสมมติฐานเชิงลำดับตัวเลข

**Fix:** CAD-only mapping, pair-independent mapping input, string-safe IDs และสถานะ/audit ใหม่; manual mapping ถูกเก็บพร้อม revision/history

## 7. Modal/Overlay ค้าง

**Root cause:** async paths คืนค่า/throw ก่อน reset loading; browser confirm และ custom overlay ใช้ lifecycle คนละชุด; pending action/scroll/pointer state ไม่คืนทุก branch

**Fix:** centralized modal cleanup, `try/catch/finally`, double-submit guard, Escape/Cancel/Close handling, focus/scroll/pointer restoration และ cancel regression tests

## 8. Test baseline รันซ้ำไม่ได้

**Root cause:** 4 package scripts บังคับ path ZIP ภายนอก แต่ไม่มี fixture/argument ใน repository

**Fix:** เพิ่ม fixture ขนาดเล็กที่ไม่มีข้อมูลลับและให้ scripts default ไป fixture ภายใน โดยยังรับ external fixture ได้

## 9. PWA โหลดโมดูลเก่า/ใหม่ปะปนได้

**Root cause:** precache list เขียนมือ, cache name/version ไม่ครอบคลุม schema และไม่มี waiting-worker update UI ที่ชัดเจน

**Fix:** generate precache manifest จาก `dist`, cache key = app version + schema version, delete old caches, network-first สำหรับ JS/CSS/manifest/JSON, `updateViaCache: none`, waiting update button และ controller reload

## 10. Recovery และ XML round trip สูญเสีย metadata

**Root cause:** recovery passed parsed model เข้า API ที่รับ string เท่านั้น; standalone writer ไม่เขียน Board Name และ `Number(null)` กลายเป็น 0

**Fix:** backward-compatible overload, null-safe numeric serialization และ semantic round-trip test
