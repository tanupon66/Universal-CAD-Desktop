# Known Limitations — v0.25.0

1. GenCAD 1.4 import/export is a **semantic subset**, not a complete electrical/copper writer. Board bounds, placement and rectangular Land/Padstack data are handled; netlist/routes/vias and arbitrary polygon pads are not generated when absent from the Working Model.
2. FABmaster A!/J!/S! import/export is a **semantic subset**. Component placement, rectangular padstack/pin placement and board outline are handled. Nets, traces/zones, vias, custom pad shapes and full layer stack are not fully preserved.
3. FABmaster legacy/FATF section files such as `:BOARDINFO/:PARTLIST/...` are detected and rejected with a diagnostic; they are not silently treated as supported.
4. `.cad` is ambiguous, so content signature takes priority over extension. Unknown proprietary `.cad` variants are rejected instead of producing an empty project.
5. GenCAD non-orthogonal rotated rectangular pads are reduced to the axis-aligned Land representation available in the current Working Model and produce a warning.
6. Automatic Grid detection is intended for BGA/LGA/regular or sparse rectangular grids. Radial, strongly staggered or arbitrary geometry may require manual mapping.
7. Grid Map Excel exports one selected Component per workbook; batch multi-Component workbooks are not yet implemented.
8. Board Mirror changes coordinates and angle but does not automatically swap Top/Bottom.
9. IPC-2581 remains a partial adapter and has no full writer.
10. ODB++ recognized structures can be imported, but modified `components.Z`/`eda/data.Z` cannot yet be written back as complete ODB++.
11. Gerber/Excellon detection and diagnostics exist, but complete geometry editors/writers are not implemented.
12. Full modal table virtualization and complete Web Worker migration remain partial.
13. Browser E2E/offline reload is not certified by the container test environment; static Service Worker, manifest, HTTP/MIME and precache verification are executed instead.
14. No SMT machine or proprietary simulator validation was performed. Exported `.cad`/`.fab` should be validated against the exact downstream machine/software before production use.

## v0.25.1

- Large-file streaming is implemented for FABmaster/Cadence A!/J!/S! only. Very-large GenCAD still requires a future streaming section parser.
- FABmaster netlist/traces/zones are not yet represented in the current Inspection compatibility model; they are reported rather than silently treated as imported.
