# Baseline Report — v0.19.0

- Runtime: Vanilla JavaScript ES modules, HTML, CSS.
- State management: mutable singleton `state` in `app.js`.
- Parsers: regular-expression XML parser, custom XLSX/ZIP/TAR/GZIP/Unix-compress readers, ODB++ conversion adapter.
- Storage: no project IndexedDB autosave; only browser install prompt/service worker state.
- Build tool: none; source files were deployed directly.
- PWA: manifest + service worker, network-first cache.
- Baseline scripts: 29.
- Passed without external input: 25.
- Failed because an external ZIP argument was mandatory: 4 (`test:parser`, `test:duplicates`, `test:cad`, `test:compare-real`).
- Production build command: absent.
- Type-check command: absent.
- Lint command: absent.

Baseline command log is retained in `FINAL_TEST_LOG_BASELINE_V0.19.0.txt`.
