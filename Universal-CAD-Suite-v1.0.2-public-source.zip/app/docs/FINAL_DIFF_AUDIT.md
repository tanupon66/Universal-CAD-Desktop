# Final Diff Audit — v0.20.0

Audit scope: tracked runtime diff from baseline `efaaf67` through the final release source.

## Unused imports

A named-import occurrence scan plus manual review found one unused import, `cadEditorModelToData` in `app.js`; it was removed. Re-run result: no unused named import found by the repository heuristic.

## Dead code / mock / placeholder data

- No `TODO`, `FIXME`, mock-data or demo-data execution path was added to runtime modules.
- HTML `placeholder=` attributes are input hints only and are not substituted for real CAD processing.
- Test fixtures are isolated under `tests/` and are not copied into `dist/`.

## Race condition / stale state

- Apply uses a busy guard and project checkpoint; prepared XML/model/mapping/revision are published only after all required steps complete.
- Failure restores file, editor, mapping and project-session checkpoints.
- Autosave queues the latest complete transaction and serializes writes through one `inFlight` promise.
- Mapping refresh uses the active applied CAD compatibility view; manual mapping history is retained and impacted records can be marked conflict.
- Export blocks unapplied working changes and performs preflight against the project session current applied model.

## Promise and error handling

- Empty `catch {}` and `.catch(() => {})` handlers were removed.
- `scripts/lint.mjs` now fails on empty catch handlers, `eval` and `new Function`.
- Background Autosave errors enter the Global Error diagnostic flow.
- Service Worker update-check errors are logged with context rather than discarded.
- Global `error` and `unhandledrejection` handlers create user-safe diagnostics; full stack details stay in the downloadable diagnostic, not the main message.

## Loading / modal cleanup

- Apply/export task wrappers reset busy state in `finally`.
- Cancel aborts the active operation through its cancellation context rather than only hiding the overlay.
- Confirm/close/Escape paths clear pending actions and restore focus, body scroll and pointer interaction.
- Double-submit is guarded while commit is active.

## Event listener / timer lifecycle

- New global listeners are application-lifetime listeners in a single-page Vanilla PWA; they are registered once during module initialization.
- No repeated modal-open path adds duplicate global listeners.
- Service Worker update listener is attached once after registration.
- Autosave timeout is cleared on reschedule/cancel/flush; service-worker network timeout is cleared in `finally`; busy watchdog is cleared when task state closes.

## Object URL / Worker cleanup

- The only runtime `URL.createObjectURL` path is the download helper; it schedules `URL.revokeObjectURL` after the browser receives the click.
- No `Worker` instance is created in v0.20.0, so there is no orphan Worker to terminate. A full Worker pipeline remains a documented limitation.

## HTML/script safety

- No `eval` or `Function` constructor exists in runtime/test/build code.
- File/user-derived values used in legacy HTML templates pass through `escapeHtml`; new lists/diagnostics use `textContent` and DOM nodes.
- Lint retains one review warning for legacy dynamic `innerHTML` because a regex cannot prove template safety; the occurrences were manually reviewed. Constant empty-state templates and numeric-only histogram templates are controlled.

## Source model / Mapping / Export consistency

- Direct `state.xmlData` reads that remain are Compatibility View reads. The view is updated only after revision commit and restored on rollback.
- Export metadata always comes from `createProjectExportSnapshot`.
- XML/archive writer receives the applied editor model; export is rejected while `model.changed` is true, preventing export from an older parsed source.
- Original archive entries remain immutable; archive export rebuilds a new byte array.

## Service Worker/cache

- Runtime assets are generated from `dist/` into `precache-manifest.js`.
- Cache key includes app version and schema version.
- Activation deletes older app caches.
- JS/CSS/manifest/JSON use network-first with cached fallback; update registration uses `updateViaCache: none` and explicit waiting-worker activation.

## Audit result

No tracked whitespace error, unused named import, empty catch, forbidden dynamic-code constructor or unrevoked runtime download Object URL was found after the final corrections. Browser-level memory profiling and real offline reload remain target-device verification items, not claimed as automated in the container.

## v0.21.0 addendum

- New first-party modules have no `eval`, `new Function` or empty catch handlers.
- PptxGenJS is a vendored MIT third-party bundle and is excluded from first-party security-pattern lint; its file and license are required by regression tests.
- Land Map Object URLs are revoked on refresh, modal close and CAD Editor close.
- Board transform validates all Land rectangles before mutating the model.
- PowerPoint export is local-only and does not upload CAD data.

## v0.22.0 addendum

- Removed unused `applyGridRenamePlan` import and unused DOM element references.
- DOM reference audit: no used-but-undefined, defined-but-unused or missing HTML IDs.
- Named import heuristic: no unused named imports.
- Removed legacy `preview-name-rules.html` from source root and Production Build.
- Removed obsolete `landGridResetButton`, `landGridSeparator`, `renumber-selected` and `renumber-all` workflows.
- Confirmed Land Map Object URL is revoked on close/reset and legacy missing state is restored through `ensureCadToolState()`.
- Confirmed no `eval`, `new Function` or empty catch in first-party source/tests.
- Version consistency passed for package, manifest, Service Worker, UI and app diagnostics/export metadata.
- Final detailed audit is recorded in `FINAL_AUDIT_V0.22.0.txt`.

## v0.23.0 addendum

- Removed standalone `land-map-export.js`, Land Map modal/state/actions, SVG/PPTX export controls and the vendored PptxGenJS runtime.
- Added one `Grid / Land Map` modal whose Preview, Apply Mapping and Excel export share the same grid/order/direction/mapping plan.
- Added `grid-map-excel.js` and reused the existing safe XLSX writer; no native binary, server or online dependency was introduced.
- Runtime/static scan found no obsolete Land Map IDs/functions/command or PptxGenJS reference in production source.
- Version consistency passed for package, manifest, Service Worker, UI, application diagnostics and production build.
- Security lint passed with one existing review warning for controlled legacy dynamic `innerHTML`; no policy failure, `eval` or `new Function` was found.
- Final details are recorded in `FINAL_AUDIT_V0.23.0.txt`.

## v0.25.0 addendum

- Compared the final v0.25.0 source tree against the v0.24.0 baseline. Changes are limited to the new PCB ASCII format layer, detector/import/archive routing, export UI/integration, version/PWA metadata, release documentation and regression tests.
- Added `pcb-ascii-formats.js` as a first-party browser-only module. No npm runtime dependency, native binary, server dependency, `eval`, `new Function` or empty catch handler was introduced.
- Content signatures take precedence over filename extension for `.cad` / `.fab`: GenCAD 1.x is recognized by its `$HEADER` / `GENCAD` structure; FABmaster extract is recognized by its A!/J!/S! section structure. A known colon-section FABmaster legacy/FATF variant is detected but deliberately rejected until a safe adapter exists.
- GenCAD and FABmaster import normalize into the existing Inspection-compatible Working Model. Editor, Mapping, Grid/Land Map, Validation, Apply, Revision, Undo/Redo and Autosave continue to use the same existing model/session path rather than a parallel state copy.
- Cross-format export uses the current Applied Revision and existing export-preflight guard. GenCAD/FABmaster writers are explicitly marked partial and report unsupported electrical/copper records instead of claiming a complete round-trip.
- Archive export now writes a nested source candidate only when a matching source writer exists (`inspection-xml`, `gencad-1.4`, `fabmaster-ascii`). Converted ODB++ / IPC-2581 archive sources without a matching writer are blocked instead of writing Inspection XML under the original filename/extension.
- GenCAD quoted fields have CR/LF stripped before record output, preventing source/user text from injecting extra line records. Existing archive traversal/bomb/XML entity and spreadsheet formula-injection guards remain enabled and covered by the regression suite.
- Named-import heuristic on the changed runtime modules found no unused named imports. New export DOM IDs each exist exactly once in `index.html` and have active callers in `app.js`.
- Runtime `URL.createObjectURL` remains centralized in the existing download helper and is followed by `URL.revokeObjectURL`; no Worker was introduced in v0.25.0.
- `package.json` still has no runtime or dev dependencies, preserving the static/browser-only PWA deployment model.
- Final gate: 94 JavaScript modules passed syntax/type-surface checking; security lint passed with one existing controlled `innerHTML` review warning; 50/50 test scripts passed with 0 failed and 0 skipped; production build and HTTP/MIME/manifest verifier passed with 41 precache assets.
- Real Inspection XML cross-export verification preserved 1 component / 72 lands through both XML → GenCAD → re-import and XML → FABmaster → re-import. Maximum rectangular geometry deltas were approximately 0.0000166 mm and 1.14e-13 mm respectively.
- Git commit metadata is unavailable because the delivered source tree does not contain `.git`; the build records `unavailable` rather than inventing a commit hash.

## v0.25.1 addendum

The hotfix is limited to ZIP streaming access, large FABmaster import routing/parser, bounded direct-file probing, related tests/scripts, version metadata and documentation. No Grid/Land Map, rename, transaction, validation, autosave, Excel or writer feature was removed. Original archive bytes remain the immutable source.
