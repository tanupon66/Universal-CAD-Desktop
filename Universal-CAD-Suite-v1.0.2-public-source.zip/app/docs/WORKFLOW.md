# Example Workflow — Import → Edit → Apply → Mapping → Validate → Export

1. **Import** — Drop XML/ZIP/TGZ/TAR/XLSX/CSV/TXT. Review detected format, encoding, archive candidate, counts, warnings/errors and unsupported records
2. **Open CAD** — CAD-only input appears immediately; choose Original/Generated revision when both exist
3. **Edit Working Model** — select Component/Land, rename/move/rotate/change side, Cut ½/Merge/Split Component as applicable; operations create history entries
4. **Preview/Undo** — inspect visual result and validation; use Undo/Redo before commit
5. **Apply** — press the single Apply button; modal shows change count and validation summary; press **Yes - ยืนยัน** or Cancel
6. **Transaction** — app prepares serialized XML, parsed model, mapping delta and new revision. Any failure restores the previous checkpoint
7. **Mapping** — Mapping Table refreshes from Applied Revision; CAD-only/BOM/XY pairs can be used; manual matches retain method, score, confirmation, timestamp, revision and previous mapping
8. **Validate** — review Info/Warning/Error/Blocking Error. Warning override requires reason; blocking issue prevents writer path unless authorized override policy applies
9. **Export Preflight** — exporter captures Project ID, Revision, export time, source/export format, validation status and accepted warnings
10. **Export** — choose Project Backup, JSON Model, CSV/XLSX placement, BOM, Mapping/Validation report or supported XML/archive output
11. **Recovery** — after a complete revision, debounced autosave writes IndexedDB. Reload offers Recovery only for complete schema-compatible records

## v0.25.0 Cross-format CAD/FAB workflow

1. Import `.cad`, `.fab`, XML or an archive. The detector reads the content signature before trusting the extension.
2. GenCAD 1.4 or FABmaster ASCII is normalized into the same Working Model used by the existing Editor/Mapping/Validation pages; the original file remains immutable.
3. Edit and Apply exactly as in v0.24.0. Grid/Land Map and Name Inspector behavior is unchanged.
4. In CAD Editor choose **Format**: `Inspection XML`, `GenCAD 1.4 (.cad)` or `FABmaster ASCII (.fab)` and choose Top/Bottom scope.
5. Export runs Applied-Revision preflight. If Working Model has unapplied changes, export is blocked until Apply.
6. `.cad/.fab` writers emit the supported placement/Land subset and surface partial-writer warnings. They do not fabricate missing netlist/routes/vias/custom polygon data.
7. If the source lives inside ZIP/TGZ/TAR, `Export Archive` writes back in the same format only when a matching writer exists. It will not place normalized XML text under a `.cad/.fab` filename.
