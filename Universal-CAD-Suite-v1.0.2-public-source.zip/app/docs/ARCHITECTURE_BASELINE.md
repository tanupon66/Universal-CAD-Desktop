# Architecture Baseline — Universal CAD Editor v0.19.0

## Runtime and deployment

The application is a browser-only Progressive Web App built with HTML, CSS and native ES modules. There is no UI framework, state library, bundler, application server or native binary dependency. Static hosting is the deployment target. `index.html` loads `app.js`; `app.js` owns the browser state and imports focused parser/editor/archive/report modules. `sw.js` provides offline caching and `manifest.webmanifest` defines installation metadata.

## Current source of truth

Before this upgrade, the active source of truth was split:

- Imported immutable text was held in `cadFiles[role].text`, but archive candidate bytes could be modified in place.
- Parsed CAD was held in `cadFiles[role].data` and mirrored to `state.xmlData`.
- Editor working data was held in `cadFiles[role].editorModel` and `state.cadEditor.model`.
- Mapping used `state.xmlData` plus `state.xlsxData`.
- Export paths selected data independently: Mapping CSV/JSON read `state.mappingData`; CAD XML/Archive exports serialized the editor model; report export read parsed CAD.

This made `cadFiles[role].data`, `state.xmlData`, the editor model and mapping rows independent mutable snapshots rather than views of one revision.

## Root cause of Editor / Mapping / Export divergence

1. Apply published `file.data` and `file.editedText` before Mapping synchronization completed.
2. Mapping synchronization errors were caught and converted to a non-blocking warning, so Apply could report success while Mapping still referenced the previous revision.
3. Archive XML candidate bytes were overwritten during Apply, so the imported source package was not immutable.
4. Exporters did not share one revision-aware snapshot contract.
5. Mapping could only be built when both parsed CAD and XLSX raw data existed.
6. Browser state had no project/revision identifier, schema version or atomic persistence boundary.

## Refactor boundaries

Safe to refactor:

- Add a revision-aware project controller above existing parser/editor functions.
- Add immutable source records, working/applied/export snapshots and change sets.
- Route Apply, Mapping, Validation and Export through the active revision.
- Add compatibility adapters that expose legacy `state.xmlData`, `file.data` and `state.mappingData` views.
- Add typed application errors, diagnostics, storage and format detection modules.

Must remain compatible:

- Existing XML parser and CAD editor model fields.
- Existing `cadFiles.original/generated` roles and active CAD UI.
- Existing license flow and offline behavior.
- Existing archive reader/writer behavior for formats already supported.
- Existing mapping table shape until callers are migrated.
- Existing project backup JSON fields.

## Migration strategy

Legacy in-memory/imported projects are wrapped as schema version 2 projects on first Apply or Autosave. Source bytes/text are copied into immutable source records. Existing parsed CAD becomes revision 0. Existing editor data becomes the working model. Existing mapping rows are retained through a compatibility adapter and tagged with the active revision. No user field is renamed. Recovery data is migrated only after validation and is written under a new IndexedDB database/version, leaving old browser data untouched until migration succeeds.

## Internal API changes

Internal APIs remain backward compatible. New project/revision APIs are additive. Legacy views are updated only after a project transaction commits. A failed Apply restores all legacy views from a rollback snapshot.
