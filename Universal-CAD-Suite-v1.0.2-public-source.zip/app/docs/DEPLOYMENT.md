# Deployment Note — Static PWA

## Build

```bash
npm run typecheck
npm run lint
npm run test:all
npm run build
npm run verify:production
```

Production output อยู่ใน `dist/`. Runtime ไม่ต้องมี Node.js; Node ใช้เฉพาะ build/test

## Cloudflare Pages

- Framework preset: None
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: repository root
- Node version: รุ่นที่รองรับ native `fetch` และ ES modules (Node 18+)
- ไม่มี Functions/Workers/API server ที่จำเป็น

อัปโหลดทั้ง `dist/` ใน deploy เดียวเพื่อป้องกัน HTML/JS/Service Worker คนละรุ่น

## Static hosting

- ต้อง serve `.js` เป็น JavaScript MIME, `.webmanifest` เป็น manifest/JSON-compatible MIME และ `.json` เป็น JSON
- ต้องใช้ HTTPS สำหรับ PWA install/service worker ยกเว้น localhost
- อย่า rewrite request ของ `.js`, `.json`, `.webmanifest`, icon หรือ `sw.js` ไป `index.html`
- ให้ `sw.js`, `precache-manifest.js`, `manifest.webmanifest`, `index.html` และ `build-info.json` revalidate/no-cache ได้
- Runtime JavaScript ใช้ network-first และมี cached fallback ผ่าน service worker

## หลัง Deploy

1. เปิด `index.html` และตรวจ badge version เป็น v0.23.0
2. DevTools > Application: Manifest โหลด, start_url/scope ถูกต้อง, icons 192/512 พร้อม
3. Service Workers: registered/activated ไม่มี error
4. Reload ออนไลน์หนึ่งครั้งให้ precache ครบ
5. เปลี่ยน Offline ใน DevTools แล้ว reload; shell และโมดูล CAD หลักควรเปิดได้
6. Deploy รุ่นใหม่และตรวจว่าปุ่ม “มีเวอร์ชันใหม่ · อัปเดต” แสดงเมื่อ worker waiting

## Cloudflare cache recommendation

ตั้ง Browser Cache TTL ต่ำหรือ `no-cache` สำหรับ `index.html`, `sw.js`, `precache-manifest.js`, `manifest.webmanifest`, `build-info.json`; icons สามารถ cache ยาวได้ รุ่นนี้ไม่ใช้ hashed filenames จึงต้อง deploy ทั้งชุดและอาศัย network-first/versioned service-worker cache
