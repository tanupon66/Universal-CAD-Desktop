# Files Changed — v0.23.0

## Core/UI

- `app.js` — unified Grid/Land Map workflow, Excel export from the active Mapping preview, removed standalone Land Map state/modal/actions
- `index.html` — one `Grid / Land Map` entry point and `Export Excel` button inside the Grid modal
- `styles.css` — removed obsolete PowerPoint/SVG Land Map layout styles
- `grid-map-excel.js` — creates the shared Grid/Mapping Excel model
- `xlsx-report.js` — adds editable `Grid Map` and normalized `Land Data` workbook generation
- Removed `land-map-export.js` and `vendor/pptxgen.min.js`/license

## PWA/version

- `package.json`, `manifest.webmanifest`, `sw.js`, `precache-manifest.js`, UI/build metadata — aligned to v0.23.0

## Tests

- Added `tests/test-grid-map-excel.mjs`
- Added `tests/test-v023-grid-excel-static.mjs`
- Updated smoke/PWA/version tests and removed obsolete PowerPoint Land Map tests
- Added `scripts/verify-grid-map-input.mjs` for real Inspection XML verification

## v0.24.0

- `app.js`: generated alias mapping store, configurable Grid/Land UI logic, autosave/backup/JSON persistence
- `index.html`, `styles.css`: new naming configuration and manual override controls
- `land-grid-mapper.js`: generated Grid/LAND/number plan and start-direction logic
- `grid-map-excel.js`, `xlsx-report.js`: New name ↔ CAD Land Excel model/output
- `scripts/verify-grid-map-input.mjs`: actual-file verification for the new model
- `tests/test-land-grid-mapper.mjs`, `tests/test-grid-map-excel.mjs`, `tests/test-v024-grid-land-map-static.mjs`: regression coverage
- Version/PWA metadata and release documentation aligned to v0.24.0

## v0.25.0

- `pcb-ascii-formats.js` — new GenCAD 1.4 and FABmaster ASCII detectors/helpers, import adapters and partial cross-format writers
- `format-detector.js` — content-signature routing for GenCAD, FABmaster A!/J!/S! and detected-only legacy FABmaster/FATF
- `import-adapters.js` — routes recognized ASCII PCB formats into the normalized Inspection/Working Model without treating them as XML
- `archive-package.js` — scans `.fab/.gcd` entries and preserves source-format identity for nested candidates
- `app.js` — XML/.cad/.fab export selector, explicit File menu writers, source-format-aware Archive export and safe blocking for formats without a matching archive writer
- `index.html` — `.fab/.gcd` input support and export format selector
- `package.json`, `manifest.webmanifest`, `sw.js`, `precache-manifest.js` — v0.25.0/PWA runtime alignment
- `tests/fixtures/sample-gencad.cad`, `tests/fixtures/sample-fabmaster.fab` — small non-secret fixtures
- `tests/test-pcb-ascii-import.mjs`, `tests/test-pcb-ascii-export-roundtrip.mjs`, `tests/test-v025-cad-fab-static.mjs` — format routing, semantic subset round-trip and UI/PWA wiring coverage
- `scripts/verify-pcb-cross-export.mjs` — optional verification against a supplied Inspection XML without becoming a required test fixture

## v0.25.1

- `zip-reader.js` — ZIP member stream/prefix access
- `archive-package.js` — large member sniff/stream routing
- `import-adapters.js`, `pcb-ascii-formats.js` — FABmaster streaming adapter/parser
- `app.js` — bounded format probe
- `tests/test-large-fabmaster-stream.mjs`, `scripts/verify-large-fabmaster.mjs` — regression/real-file verification
- version/PWA metadata and v0.25.1 release documents
