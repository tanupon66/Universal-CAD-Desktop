# Format Support Matrix — v0.25.0

| Format | Detect | Import/View | Edit/Apply | Export/Round-trip | Status |
|---|---:|---:|---:|---:|---|
| Inspection CAD XML / CPO-like XML | Yes | Yes | Yes | Inspection XML semantic test | Supported for tested schema |
| GenCAD 1.4 ASCII (`.cad`) | Yes by `$HEADER` / `GENCAD 1.x` / sections | Board bounds, component placement, package/device reference, rectangular/circular pad size, padstack and shape pins | Normalized Component/Land subset can be edited | GenCAD 1.4 `.cad`; semantic subset round-trip tested | **Partial** |
| FABmaster ASCII A!/J!/S! (`.fab`; also `.cad` when content matches) | Yes by A/J/S section headers | Component placement, padstack size, pin placement, board bounds metadata | Normalized Component/Land subset can be edited | FABmaster ASCII `.fab`; semantic subset round-trip tested | **Partial** |
| FABmaster legacy/FATF `:BOARDINFO/:PARTLIST/...` | Yes | No adapter yet | No | No | Detected, unsupported variant |
| XML with UTF BOM / alternate extension | Yes | Yes when root/schema recognized | Yes | XML | Supported for recognized schema |
| XML/CAD text in ZIP/TGZ/TAR/TAR.GZ/GZIP | Yes | Recognized nested text candidates are scanned | Yes after normalize | Rebuilt archive only where source writer path supports it | Partial by container/source format |
| ODB++ with recognized `components.Z` / `eda/data.Z` | Yes | Yes | Converted working CAD can be edited | XML/Project archive; no complete ODB++ writer | Partial |
| IPC-2581 XML | Yes by root/namespace | Placement/package/pin/land subset | Normalized subset can be edited | No full IPC-2581 writer | Partial |
| CAD XY CSV/TXT | Yes by content/delimiter | Yes for mapping records | Mapping/manual confirmation | CSV/JSON report | Supported for tested fields |
| BOM CSV/TXT | Yes by headers/content | Yes for mapping records | Mapping/manual confirmation | CSV/JSON report | Supported for tested fields |
| XLSX CAD/measurement/BOM workflow | Yes | Existing parser/workflow retained | Mapping/report | XLSX/CSV reports | Supported for existing workbook patterns |
| Gerber | Yes | Diagnostic only | No complete geometry editor | No writer | Not yet supported for CAD editing |
| Excellon | Yes | Diagnostic only | No complete drill editor | No writer | Not yet supported for CAD editing |

## `.cad` is not one file format

The detector does **not** trust the extension alone. A `.cad` file can be GenCAD 1.4 or an A!/J!/S!-style extraction from another EDA flow. v0.25.0 inspects content signatures first and routes the file to the matching adapter. A file with a `.fab` extension but GenCAD content is likewise routed as GenCAD.

## GenCAD 1.4 subset

Imported: board outline bounds/thickness when available, units (`INCH`, `MM`, common `USER 1000`), rectangular/circular pad dimensions, padstack-to-pad association, shape pins, component placement/layer/rotation, and device/part/package identity where present.

Current limitations: signals/netlist and routes are detected but are not represented in the Inspection XML compatibility view; arbitrary non-rectangular pad geometry is reduced to the geometry supported by the Working Model; non-orthogonal land rotation is represented as an axis-aligned rectangle with a warning.

The writer emits a GenCAD 1.4 structure with `$HEADER`, `$BOARD`, `$PADS`, `$PADSTACKS`, `$SHAPES`, `$COMPONENTS`, `$DEVICES` and required empty sections. It exports current Board/Component/rectangular Land data but does not claim a complete electrical/copper round-trip.

## FABmaster ASCII A!/J!/S! subset

Imported: `REFDES` component placement sections, `PAD_NAME` padstack dimensions, `SYM_NAME/SYM_MIRROR/PIN_*` pin placement, recognized units (`MILS`, `MILLIMETERS`, `INCHES`, `MICRONS`) and board bounds from metadata where available.

Current limitations: nets, traces/zones, vias, custom pad shapes, full layer stack and other records are not yet preserved in the normalized compatibility model. The writer outputs component placement, rectangular Land/Padstack rows, pin rows and a board outline section, and marks itself partial.

## v0.24+ Grid/Land Map

- Excel `.xlsx` local/offline remains supported.
- Generated alias formats remain Grid coordinate, LAND sequence and number-only.
- Mapping is generated-name ↔ existing CAD Land name/XML ID and does not rename CAD unless the Name Inspector is used.

## v0.25.1 large-file note

FABmaster/Cadence A!/J!/S! `.cad/.fab` supports streaming import for very large standalone files and members inside ZIP. Only records needed for the current Working Model are retained. Net/trace/graphic records outside the normalized model are scanned/diagnosed without being materialized. Large GenCAD does not yet have the same streaming section parser.
