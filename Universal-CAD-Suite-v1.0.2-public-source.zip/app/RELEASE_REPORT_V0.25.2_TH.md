# Universal CAD Studio v0.25.2 — Release Report

## 1. Baseline ก่อนแก้
- Base: v0.25.1
- Baseline functions retained: PWA/offline, Mapping, Grid/Land Map, CAD Editor, Apply transaction, Undo/Redo, Autosave/Recovery, Validation, XML/CAD/FAB/Excel export.
- The v0.25.1 machine XML export used the simplified internal `InspectionData` schema.

## 2. Root cause
1. Machine-unreadable UniversalCAD XML was structurally different from the supplied ePM-readable XML.
2. UniversalCAD root was `InspectionData`; ePM root is `DataList` with machine collections.
3. UniversalCAD omitted `InspectionProjectXml`, `InspectionRegionCollectionSetXml`, `ComponentInformationCollectionXml`, `ComponentNumberCollectionXml`, `LandNumberCollection`, package definitions, `DestinationList`, and per-land `FeatureList`.
4. `PositionAngle` was serialized in a different hierarchy.
5. Browser IEEE-754 artifacts leaked directly into XML, e.g. `158.15399999999997`, `0.660000000000025`.
6. UniversalCAD also inserted a custom export comment before the machine data root.

## 3. Architecture changes
- Added a dedicated VT-X/ePM machine XML writer (`vtx-inspection-xml.js`).
- Internal simplified `InspectionData` remains available as a compatibility working representation; it is no longer the default machine XML output.
- The default XML export now produces `DataList` machine structure.
- Export IDs are re-indexed sequentially in the export snapshot and component/land references are rewritten consistently.
- Geometry values are normalized to max 3 decimal places; angle max 5 decimals.
- Per-land rectangle `FeatureList` is generated from current Applied Revision geometry.
- Machine XML intentionally excludes the UniversalCAD metadata comment; export audit metadata remains in project/diagnostic state.

## 4. Files changed
- `app.js`
- `cad-editor.js`
- `vtx-inspection-xml.js` (new)
- `index.html`
- `package.json`
- `manifest.webmanifest`
- `sw.js`
- `precache-manifest.js`
- `README.md`
- `CHANGELOG.md`
- version-sensitive regression tests
- `tests/test-vtx-xml-export.mjs` (new)

## 5. Bugs fixed
- XML exported from UniversalCAD no longer uses the 9-element-type simplified schema as the machine file.
- Floating-point coordinate artifacts are removed from machine XML.
- Component and land IDs are normalized for export.
- Missing machine package/land collections and land shape features are generated.
- PWA cache includes the new VT-X XML writer module.

## 6. Features added
- VT-X / ePM-compatible Inspection XML export option as the default `.xml` export.
- Machine-number formatting profile.
- Structural regression test against the ePM-style schema.

## 7. Migration
- Project schema remains 2.
- No stored project migration is required.
- Old projects can be opened normally; only the exported XML representation changes.

## 8. Tests executed
- `npm run typecheck` — PASS, 98 JavaScript modules.
- `npm run lint` — PASS; existing controlled `innerHTML` review warning remains.
- `npm run test:all` — PASS, 52/52 scripts, 0 failed, 0 skipped.
- `npm run build` — PASS.
- `npm run verify:production` — PASS, 42 precache assets.
- User XML conversion verification — PASS XML parse, 1 Component, 72 Lands, 360 Features.
- Schema profile comparison: fixed output has 30 unique element types; ePM reference has 30; no missing/extra element types.

## 9. Build result
- Production static PWA build succeeded.
- Git commit is `unavailable` because the extracted source package is not a Git working tree.

## 10. PWA verification
- Manifest/version/static HTTP/MIME/precache verification passed.
- New `vtx-inspection-xml.js` is precached.
- Application remains static-hostable and browser-only.

## 11. Supported formats
Unchanged from v0.25.1 plus corrected VT-X/ePM XML machine export.

## 12. Partially supported formats
GenCAD/FABmaster writers remain partial as documented in v0.25.1.

## 13. Unsupported formats
No previously unsupported format is claimed as fully supported by this hotfix.

## 14. Known limitations
- Structural compatibility with the supplied ePM XML is verified, but physical-machine import has not been executed in this environment.
- Generated `ComponentNumber` uses `ComponentType="OTHER"` when the Working Model does not contain an authoritative ePM component type.
- `ComponentWindow` is derived from current land geometry when no authoritative component-body geometry exists.
- Rectangular `FeatureList` is generated because the current Working Model represents lands as rectangles.

## 15. Deployment instructions
Deploy the complete `dist/` contents together. Do not replace only `app.js`; Service Worker, manifest, precache manifest and new XML writer must be the same version.

## 16. Rollback instructions
Keep the prior v0.25.1 production build. To roll back, deploy the entire v0.25.1 package and refresh/activate its Service Worker as one release.
