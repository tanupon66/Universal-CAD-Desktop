# วิธีอัปเดต Universal CAD Studio v0.17.0

## แนะนำ: อัปโหลดเวอร์ชันเต็ม

1. สำรองไฟล์เว็บไซต์เดิม
2. ลบไฟล์เก่าบน GitHub Pages หรือ Cloudflare Pages
3. แตก `universal-cad-editor-v0.17.0-full.zip`
4. อัปโหลดไฟล์ภายในโฟลเดอร์ขึ้นเว็บไซต์
5. เปิดเว็บแล้วกด `Ctrl + Shift + R`

## อัปโหลดทับ v0.16.0

แตก `universal-cad-editor-v0.17.0-update.zip` แล้วอัปโหลดไฟล์ทั้งหมดทับของเดิม

ไฟล์หลักที่เปลี่ยน:

- `index.html`
- `styles.css`
- `app.js`
- `cad-inspector.js`
- `sw.js`
- `manifest.webmanifest`

## ฟังก์ชันใหม่

- ตัดชื่อที่ยาวเกินกำหนด โดยเลือกเก็บตัวหน้าหรือตัวหลัง
- แก้ชื่อซ้ำด้วยการแทนอักขระ เช่น `_` → `1`, `2`, `3...`
- เติมเลขท้ายอัตโนมัติเมื่อชื่อไม่มีอักขระที่กำหนด
- ตรวจ Collision หลังตัดชื่อและแก้ซ้ำจนกว่าจะไม่ซ้ำภายใน Component
- Preview ตัวอย่างกฎก่อน Apply
- บันทึกกฎใน Backup JSON

Cache รุ่นใหม่: `universal-cad-studio-v0.17.0`
