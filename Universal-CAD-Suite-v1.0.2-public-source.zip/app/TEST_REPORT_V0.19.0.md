# Universal CAD Studio v0.19.0 — Test Report

วันที่ทดสอบ: 26 มิถุนายน 2026

## ผลรวม

- ตรวจ syntax ของ JavaScript และชุดทดสอบทั้งหมด: ผ่าน
- ตรวจ HTML ID ซ้ำ: ไม่พบ (`365` ID ไม่ซ้ำกัน)
- ตรวจ ID ที่ `app.js` เรียกใช้แต่ไม่มีใน HTML: ไม่พบ
- ชุดทดสอบอัตโนมัติที่ไม่ต้องใช้ไฟล์ตัวอย่างภายนอก: **ผ่าน 26/26 ชุด**

## ขอบเขตที่ผ่าน

- App smoke และ static DOM
- Apply confirmation, cancel, busy-state และ pending close
- Apply → Viewer/Mapping synchronization
- Mapping rebuild เมื่อ Split/ย้าย Land ข้าม Component
- CAD Editor model, validation, serialize XML และ TGZ
- ZIP → TGZ → XML nested archive round-trip
- ODB++ TGZ conversion และ Unix `.Z`
- XML ที่ใช้นามสกุลอื่นด้วย content detection
- Land marquee multi-selection
- Split Land โดยคง XML Land ID
- ป้องกัน Split/Delete Land ทั้ง Component
- Undo/Redo และเมนูคำสั่ง
- Land-mode safety: Duplicate/Delete/Rotate/Flip/Nudge ไม่ตกไปแก้ Component
- CAD comparison และ name rules
- Component report, XLSX report, CSV/JSON export static flow
- Board fullscreen, responsive layout และ menu viewport
- Large-board responsive pipeline

## Performance test

ชุด large-board responsive pipeline ผ่าน โดยการรันล่าสุด:

- synchronous conversion: ประมาณ `356 ms`
- asynchronous conversion: ประมาณ `1,075 ms`
- UI heartbeat: `416`

ค่าจริงขึ้นอยู่กับเครื่องและเบราว์เซอร์

## ชุดทดสอบที่ต้องใช้ไฟล์ภายนอก

สคริปต์ต่อไปนี้ต้องรับ path ของไฟล์โครงการ/ตัวอย่างเฉพาะ จึงไม่ได้รวมในตัวเลข 26/26:

- `tests/test-parsers.mjs`
- `tests/test-cad-inspector.mjs`
- `tests/test-duplicates.mjs`
- `tests/test-cad-compare-real.mjs`
- `tests/build-report.mjs`

ไม่ได้พบความล้มเหลวจากโค้ดในสคริปต์เหล่านี้ แต่ต้องใช้ไฟล์ตัวอย่างที่ตรงกับเงื่อนไขของแต่ละชุด

## ข้อจำกัดการรับรอง

การตรวจครั้งนี้ครอบคลุม source audit, model/integration tests และ static UI wiring ไม่สามารถรับรองว่าไม่มีบัคทุกกรณีกับไฟล์ CAD จากผู้ผลิตทุกรูปแบบ จึงมี error handling และ diagnostics สำหรับไฟล์ที่ parser ไม่รู้จักไว้ด้วย
