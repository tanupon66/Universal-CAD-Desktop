# ผลวิเคราะห์อาการค้าง v0.18.6

## สาเหตุหลักในรุ่นก่อน

1. Confirm dialog ยังค้างอยู่ขณะ Apply ทำงาน
2. Validate, แปลงข้อมูล, Serialize XML, Clone Snapshot, Mapping sync และ Render ทำต่อเนื่องบน Main Thread
3. Mapping sync ใช้ `.find()` ใน Component ซ้ำสำหรับทุก Mapping row
4. Apply วาด Viewer และ Render ตารางที่ถูก Overlay บังอยู่โดยไม่จำเป็น
5. Busy overlay ปิดกั้นปุ่ม X และไม่มีวิธียกเลิกงาน

## วิธีแก้

- เปลี่ยนงาน Apply/Export เป็นขั้นตอนย่อยที่ `yield` ให้ Browser
- เพิ่ม Progress, Cancel token และ Safe close
- Commit state หลังขั้นตอนเตรียมข้อมูลทั้งหมดสำเร็จเท่านั้น
- ใช้ Map index สำหรับ Mapping sync
- เลื่อนการ Render หน้าแรกไปหลัง Editor ถูกปิด
- เก็บ XML ที่ Apply แล้วแยกจาก XML ต้นฉบับ
- คืน Busy state และข้อความปุ่มด้วย `finally`
