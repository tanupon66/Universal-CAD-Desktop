'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { fastMachineSeed, formatMachineIdFromSeed } = require('../desktop/machine-id.cjs');
const { createEnrollmentCode, parseEnrollmentCode, fingerprintPublicKey } = require('../license-core/host-seal.cjs');
const { createSignedEntitlement, entitlementDigest } = require('../license-core/entitlement-format.cjs');
const { createMachineLicense, evaluateMachineLicense } = require('../license-core/machine-license.cjs');
const { PRODUCT_ID } = require('../license-core/license-format.cjs');
const { resolveEdition, SUITE_VERSION, ENGINE_VERSION } = require('../license-core/feature-catalog.cjs');

assert.equal(SUITE_VERSION, '1.0.2');
assert.equal(ENGINE_VERSION, '0.26.0');

// Native fallback must always produce a usable ID without WMI/CIM.
for (const sample of [
  { macs:['aa:bb:cc:dd:ee:ff'], arch:'x64', platform:'win32', hostname:'PC1' },
  { macs:[], machineGuid:'guid-123', arch:'x64', platform:'win32', hostname:'PC2' },
  { macs:[], machineGuid:'', arch:'x64', platform:'win32', hostname:'PC3' },
]) {
  const id = formatMachineIdFromSeed(fastMachineSeed(sample));
  assert.match(id, /^UCAD-(?:[A-F0-9]{4}-){5}[A-F0-9]{4}$/);
}

// Same NIC remains stable across a Windows reinstall even if MachineGuid changes.
const a = formatMachineIdFromSeed(fastMachineSeed({macs:['10:20:30:40:50:60'],machineGuid:'OLD',arch:'x64'}));
const b = formatMachineIdFromSeed(fastMachineSeed({macs:['10:20:30:40:50:60'],machineGuid:'NEW',arch:'x64'}));
assert.equal(a,b);

// Enrollment code copy/paste can contain whitespace/newlines.
const host = crypto.generateKeyPairSync('x25519', { publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });
const hostId = 'UCAD-HOST-AAAA-BBBB-CCCC-DDDD-EEEE-FFFF';
const code = createEnrollmentCode({hostId,publicKeyPem:host.publicKey});
const wrapped = `${code.slice(0,20)}\n  ${code.slice(20,50)}\r\n${code.slice(50)}`;
assert.equal(parseEnrollmentCode(wrapped).hostId, hostId);

// Direct machine-license chain: master -> entitlement -> delegated grant -> Studio.
const master = crypto.generateKeyPairSync('ed25519', { publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });
const delegated = crypto.generateKeyPairSync('ed25519', { publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });
const edition = resolveEdition('pro',['cad.edit','mapping','export.xml'],'Universal CAD Studio Pro');
const fp = fingerprintPublicKey(delegated.publicKey);
const ent = createSignedEntitlement({
  entitlementId:crypto.randomUUID(), product:PRODUCT_ID, suiteVersion:SUITE_VERSION, engineVersion:ENGINE_VERSION,
  customerName:'Direct Customer', customerId:'D001', entitlementLabel:'Direct Pro', licenseHostId:`UCAD-HOST-DIRECT-${fp.slice(0,24).toUpperCase()}`,
  licenseHostKeyFingerprint:fp, seats:1, validFrom:'2026-01-01', validUntil:'2027-12-31', editionId:edition.id, editionName:edition.name,
  productDisplayName:edition.displayName, features:edition.features, delegatedPublicKeyPem:delegated.publicKey,
  issuedAt:'2026-08-21T00:00:00.000Z', issuer:'Test Master', nonce:crypto.randomBytes(18).toString('base64url')
}, {schema:'ucad-direct-issuer-v1',mode:'direct'}, master.privateKey);
const grant = {grantId:crypto.randomUUID(), entitlementId:ent.payload.entitlementId, entitlementDigest:entitlementDigest(ent), seatNumber:1, computerLabel:'PC', machineId:a, validFrom:'2026-01-01', validUntil:'2027-12-31', issuedAt:'2026-08-21T00:00:00.000Z', nonce:crypto.randomBytes(18).toString('base64url')};
const lic = createMachineLicense({entitlement:ent,grant},delegated.privateKey);
assert.equal(evaluateMachineLicense(lic,master.publicKey,a,{now:new Date('2026-08-21T12:00:00')}).ok,true);

// Static guards for the v1.0.2 recovery/rebind/product changes.
const hostIdentity = fs.readFileSync(path.join(__dirname,'../customer-license-tool/host-identity.cjs'),'utf8');
assert.match(hostIdentity,/persistent-random/);
assert.doesNotMatch(hostIdentity,/computeMachineId/);
const customerMain = fs.readFileSync(path.join(__dirname,'../customer-license-tool/main.cjs'),'utf8');
assert.match(customerMain,/customer:rebind-seat/);
assert.doesNotMatch(customerMain,/recovery backup can only be restored on the original License Host/);
const masterMain = fs.readFileSync(path.join(__dirname,'../master-license-manager/main.cjs'),'utf8');
assert.match(masterMain,/master:generate-direct/);
assert.match(masterMain,/master:remove-key/);

console.log('v1.0.2 license resilience/direct/rebind tests: PASS');
