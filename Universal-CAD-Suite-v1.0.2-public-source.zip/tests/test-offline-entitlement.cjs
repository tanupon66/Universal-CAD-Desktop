'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { machineSeedFromFacts, formatMachineIdFromSeed, legacySeedFromSnapshot, COMMAND_TIMEOUT_MS } = require('../desktop/machine-id.cjs');
const { PRODUCT_ID } = require('../license-core/license-format.cjs');
const { createEnrollmentCode, parseEnrollmentCode, sealForHost, unsealForHost, fingerprintPublicKey } = require('../license-core/host-seal.cjs');
const { createSignedEntitlement, verifyEntitlement, entitlementDigest } = require('../license-core/entitlement-format.cjs');
const { createMachineLicense, evaluateMachineLicense } = require('../license-core/machine-license.cjs');
const { createOwnerLicense, evaluateOwnerLicense } = require('../license-core/owner-license.cjs');
const { createRecoveryBundle, openRecoveryBundle } = require('../customer-license-tool/recovery.cjs');
const { resolveEdition, ALL_FEATURE_IDS, SUITE_VERSION, ENGINE_VERSION } = require('../license-core/feature-catalog.cjs');

// Windows reinstall stability: MachineGuid changes, hardware-bound identity must not.
const facts = { systemUuid:'A1B2-C3D4-E5F6', baseboardSerial:'BOARD-12345', biosSerial:'BIOS-98765', processorId:'CPU-ABCD' };
const seed1 = machineSeedFromFacts(facts, 'WINDOWS-GUID-OLD');
const seed2 = machineSeedFromFacts(facts, 'WINDOWS-GUID-NEW');
assert.equal(seed1, seed2);
assert.equal(formatMachineIdFromSeed(seed1), formatMachineIdFromSeed(seed2));
const changedBoard = { ...facts, baseboardSerial:'BOARD-CHANGED' };
assert.notEqual(formatMachineIdFromSeed(seed1), formatMachineIdFromSeed(machineSeedFromFacts(changedBoard, 'WINDOWS-GUID-NEW')));
assert.ok(COMMAND_TIMEOUT_MS <= 3000, 'Hardware ID command timeout must stay bounded for older computers');
assert.equal(legacySeedFromSnapshot({facts,machineGuid:'WINDOWS-GUID-OLD'}), 'win|WINDOWS-GUID-OLD|A1B2-C3D4-E5F6');

const master = crypto.generateKeyPairSync('ed25519', { publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });
const host = crypto.generateKeyPairSync('x25519', { publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });
const hostId = `UCAD-HOST-${formatMachineIdFromSeed(seed1).replace(/^UCAD-/, '')}`;
const enrollmentCode = createEnrollmentCode({ hostId, publicKeyPem:host.publicKey });
const enrollment = parseEnrollmentCode(enrollmentCode);
assert.equal(enrollment.hostId, hostId);

const delegated = crypto.generateKeyPairSync('ed25519', { publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });
const selectedFeatures = ['cad.edit', 'mapping', 'npi.workspace', 'npi.bom'];
const edition = resolveEdition('pro', selectedFeatures, 'Universal CAD Studio Pro Custom');
assert.deepEqual(edition.features, [...selectedFeatures].sort());
const sealedIssuer = sealForHost(delegated.privateKey, host.publicKey);
assert.equal(unsealForHost(sealedIssuer, host.privateKey), delegated.privateKey);
const entitlement = createSignedEntitlement({
  entitlementId:crypto.randomUUID(), product:PRODUCT_ID, suiteVersion:SUITE_VERSION, engineVersion:ENGINE_VERSION,
  customerName:'Factory A', customerId:'FA001', entitlementLabel:'10 Pro Seats', licenseHostId:hostId,
  licenseHostKeyFingerprint:fingerprintPublicKey(host.publicKey), seats:10, validFrom:'2026-08-01', validUntil:'2027-08-01',
  editionId:edition.id, editionName:edition.name, productDisplayName:edition.displayName, features:edition.features,
  delegatedPublicKeyPem:delegated.publicKey, issuedAt:'2026-08-20T00:00:00.000Z', issuer:'Test Master', nonce:crypto.randomBytes(18).toString('base64url'),
}, sealedIssuer, master.privateKey);
assert.equal(verifyEntitlement(entitlement, master.publicKey).ok, true);

const machineId = formatMachineIdFromSeed(seed1);
const grant = { grantId:crypto.randomUUID(), entitlementId:entitlement.payload.entitlementId, entitlementDigest:entitlementDigest(entitlement), seatNumber:1, computerLabel:'QC-PC-01', machineId, validFrom:'2026-08-01', validUntil:'2027-08-01', issuedAt:'2026-08-20T00:10:00.000Z', nonce:crypto.randomBytes(18).toString('base64url') };
const machineLicense = createMachineLicense({ entitlement, grant }, delegated.privateKey);
const evaluated = evaluateMachineLicense(machineLicense, master.publicKey, machineId, { now:new Date('2026-08-20T12:00:00') });
assert.equal(evaluated.ok, true);
assert.equal(evaluated.payload.productDisplayName, 'Universal CAD Studio Pro Custom');
assert.deepEqual(evaluated.payload.features, [...selectedFeatures].sort());
assert.equal(evaluateMachineLicense(machineLicense, master.publicKey, 'UCAD-0000-0000-0000-0000-0000-0000', { now:new Date('2026-08-20T12:00:00') }).code, 'MACHINE_MISMATCH');

// Owner Universal license is intentionally not machine-bound and always carries every feature.
const ownerLicense = createOwnerLicense({ licenseId:crypto.randomUUID(), ownerName:'UCAD Owner', validFrom:'2026-01-01', validUntil:'2036-01-01', suiteVersion:SUITE_VERSION, engineVersion:ENGINE_VERSION, issuedAt:'2026-08-20T00:00:00.000Z', nonce:crypto.randomBytes(18).toString('base64url') }, master.privateKey);
for (const arbitraryMachine of [machineId, 'UCAD-1111-2222-3333-4444-5555-6666']) {
  const r = evaluateOwnerLicense(ownerLicense, master.publicKey, { now:new Date('2026-08-20T12:00:00') });
  assert.equal(r.ok, true);
  assert.deepEqual(r.payload.features, [...ALL_FEATURE_IDS].sort());
  assert.equal(r.payload.machineId, 'ANY');
}

// Recovery backup preserves host delegated key and seat ledger and rejects bad password.
const hostRecord = { schema:'ucad-license-host-identity-v1', hostId, publicKeyPem:host.publicKey, privateKeyPem:host.privateKey, createdAt:'2026-08-20T00:00:00.000Z' };
const ledger = { schema:'ucad-customer-ledger-v1', pools:{ [entitlement.payload.entitlementId]:{ entitlement, allocations:[{seatNumber:1,machineId,computerLabel:'QC-PC-01'}] } } };
const recovery = createRecoveryBundle({ hostRecord, ledger, password:'very-strong-recovery-password' });
const opened = openRecoveryBundle(recovery, 'very-strong-recovery-password');
assert.equal(opened.hostId, hostId);
assert.equal(opened.hostRecord.privateKeyPem, host.privateKey);
assert.equal(Object.keys(opened.ledger.pools).length, 1);
assert.throws(() => openRecoveryBundle(recovery, 'wrong-password-123'));

console.log('offline entitlement/reinstall/owner tests: PASS');
