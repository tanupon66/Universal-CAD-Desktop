'use strict';
const crypto = require('node:crypto');
const { normalizeMachineId, todayLocal, isIsoDate } = require('./license-format.cjs');
const { verifyEntitlement, entitlementDigest } = require('./entitlement-format.cjs');

const MACHINE_LICENSE_SCHEMA = 'ucad-machine-license-v2';
const ALGORITHM = 'Ed25519';

function stableGrant(grant) {
  const shaped = {
    schemaVersion: 2,
    grantId: String(grant.grantId || ''),
    entitlementId: String(grant.entitlementId || ''),
    entitlementDigest: String(grant.entitlementDigest || '').toLowerCase(),
    seatNumber: Number(grant.seatNumber || 0),
    computerLabel: String(grant.computerLabel || '').trim(),
    machineId: normalizeMachineId(grant.machineId),
    validFrom: String(grant.validFrom || ''),
    validUntil: String(grant.validUntil || ''),
    issuedAt: String(grant.issuedAt || ''),
    nonce: String(grant.nonce || ''),
  };
  return Buffer.from(JSON.stringify(shaped), 'utf8');
}

function validateGrant(grant) {
  const g = JSON.parse(stableGrant(grant).toString('utf8'));
  const errors = [];
  if (!g.grantId) errors.push('grantId is required.');
  if (!g.entitlementId) errors.push('entitlementId is required.');
  if (!/^[a-f0-9]{64}$/.test(g.entitlementDigest)) errors.push('entitlementDigest is invalid.');
  if (!Number.isInteger(g.seatNumber) || g.seatNumber < 1) errors.push('seatNumber is invalid.');
  if (!g.machineId.startsWith('UCAD-')) errors.push('Machine ID is invalid.');
  if (!isIsoDate(g.validFrom) || !isIsoDate(g.validUntil)) errors.push('Validity dates are invalid.');
  if (g.validUntil < g.validFrom) errors.push('validUntil must not be before validFrom.');
  if (!g.issuedAt || Number.isNaN(Date.parse(g.issuedAt))) errors.push('issuedAt is invalid.');
  if (g.nonce.length < 16) errors.push('nonce is invalid.');
  return errors;
}

function createMachineLicense({ entitlement, grant }, delegatedPrivateKeyPem) {
  const shaped = JSON.parse(stableGrant(grant).toString('utf8'));
  const errors = validateGrant(shaped);
  if (errors.length) throw new Error(errors.join(' '));
  if (shaped.entitlementId !== entitlement?.payload?.entitlementId) throw new Error('Entitlement ID mismatch.');
  if (shaped.entitlementDigest !== entitlementDigest(entitlement)) throw new Error('Entitlement digest mismatch.');
  const signature = crypto.sign(null, stableGrant(shaped), delegatedPrivateKeyPem).toString('base64');
  return { schema: MACHINE_LICENSE_SCHEMA, algorithm: ALGORITHM, entitlement, grant: shaped, signature };
}

function verifyMachineLicense(document, masterPublicKeyPem) {
  if (!document || document.schema !== MACHINE_LICENSE_SCHEMA || document.algorithm !== ALGORITHM) return { ok:false, code:'FORMAT', message:'Machine license format is not supported.' };
  const ent = verifyEntitlement(document.entitlement, masterPublicKeyPem);
  if (!ent.ok) return { ...ent, code:`ENTITLEMENT_${ent.code}` };
  const errors = validateGrant(document.grant);
  if (errors.length) return { ok:false, code:'GRANT', message:errors.join(' ') };
  const g = JSON.parse(stableGrant(document.grant).toString('utf8'));
  if (g.entitlementId !== ent.payload.entitlementId || g.entitlementDigest !== entitlementDigest(document.entitlement)) return { ok:false, code:'CHAIN', message:'Machine license is not chained to this entitlement.' };
  if (g.seatNumber > ent.payload.seats) return { ok:false, code:'SEAT', message:'Seat number exceeds entitlement capacity.' };
  if (g.validFrom < ent.payload.validFrom || g.validUntil > ent.payload.validUntil) return { ok:false, code:'VALIDITY', message:'Machine license validity exceeds entitlement validity.' };
  let sig;
  try { sig = Buffer.from(String(document.signature || ''), 'base64'); } catch { return { ok:false, code:'SIGNATURE', message:'Machine license signature is invalid.' }; }
  const valid = crypto.verify(null, stableGrant(g), ent.payload.delegatedPublicKeyPem, sig);
  if (!valid) return { ok:false, code:'SIGNATURE', message:'Machine license delegated signature verification failed.' };
  return { ok:true, entitlement:ent.payload, grant:g, document };
}

function evaluateMachineLicense(document, masterPublicKeyPem, machineId, options = {}) {
  const verified = verifyMachineLicense(document, masterPublicKeyPem);
  if (!verified.ok) return verified;
  const currentMachine = normalizeMachineId(machineId);
  if (verified.grant.machineId !== currentMachine) return { ok:false, code:'MACHINE_MISMATCH', message:'This license was issued for a different computer.', ...verified };
  const now = options.now instanceof Date ? options.now : new Date(options.now || Date.now());
  const today = todayLocal(now);
  if (today < verified.grant.validFrom) return { ok:false, code:'NOT_YET_VALID', message:`License starts on ${verified.grant.validFrom}.`, ...verified };
  if (today > verified.grant.validUntil) return { ok:false, code:'EXPIRED', message:`License expired on ${verified.grant.validUntil}.`, ...verified };
  if (options.lastSeenUtcMs && Number.isFinite(Number(options.lastSeenUtcMs))) {
    const toleranceMs = Number(options.clockRollbackToleranceMs ?? 5 * 60 * 1000);
    if (now.getTime() + toleranceMs < Number(options.lastSeenUtcMs)) return { ok:false, code:'CLOCK_ROLLBACK', message:'System clock appears to have been moved backwards.', ...verified };
  }
  const e = verified.entitlement;
  const payload = {
    licenseId: verified.grant.grantId,
    entitlementId: e.entitlementId,
    customerName: e.customerName,
    customerId: e.customerId,
    computerLabel: verified.grant.computerLabel,
    machineId: verified.grant.machineId,
    seatNumber: verified.grant.seatNumber,
    seatCount: e.seats,
    validFrom: verified.grant.validFrom,
    validUntil: verified.grant.validUntil,
    editionId: e.editionId,
    editionName: e.editionName,
    productDisplayName: e.productDisplayName,
    features: e.features,
    suiteVersion: e.suiteVersion,
    engineVersion: e.engineVersion,
    issuedAt: verified.grant.issuedAt,
  };
  return { ok:true, code:'VALID', payload, today, entitlement:e, grant:verified.grant };
}

function serializeMachineLicense(doc) { return `${JSON.stringify(doc, null, 2)}\n`; }
function parseMachineLicenseText(text) { return JSON.parse(String(text || '').trim()); }

module.exports = {
  MACHINE_LICENSE_SCHEMA,
  stableGrant,
  validateGrant,
  createMachineLicense,
  verifyMachineLicense,
  evaluateMachineLicense,
  serializeMachineLicense,
  parseMachineLicenseText,
};
