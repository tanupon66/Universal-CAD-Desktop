'use strict';
const crypto = require('node:crypto');
const { PRODUCT_ID, isIsoDate } = require('./license-format.cjs');
const { SUITE_VERSION, ENGINE_VERSION, normalizeFeatures } = require('./feature-catalog.cjs');
const { normalizeHostId, fingerprintPublicKey } = require('./host-seal.cjs');

const ENTITLEMENT_SCHEMA = 'ucad-entitlement-v1';
const ALGORITHM = 'Ed25519';

function normalizePayload(payload) {
  return {
    schemaVersion: 1,
    entitlementId: String(payload.entitlementId || ''),
    product: String(payload.product || PRODUCT_ID),
    suiteVersion: String(payload.suiteVersion || SUITE_VERSION),
    engineVersion: String(payload.engineVersion || ENGINE_VERSION),
    customerName: String(payload.customerName || '').trim(),
    customerId: String(payload.customerId || '').trim(),
    entitlementLabel: String(payload.entitlementLabel || '').trim(),
    licenseHostId: normalizeHostId(payload.licenseHostId),
    licenseHostKeyFingerprint: String(payload.licenseHostKeyFingerprint || '').toLowerCase(),
    seats: Number(payload.seats || 0),
    validFrom: String(payload.validFrom || ''),
    validUntil: String(payload.validUntil || ''),
    editionId: String(payload.editionId || 'standard').toLowerCase(),
    editionName: String(payload.editionName || 'Standard').trim(),
    productDisplayName: String(payload.productDisplayName || 'Universal CAD Studio Standard').trim(),
    features: normalizeFeatures(payload.features),
    delegatedPublicKeyPem: String(payload.delegatedPublicKeyPem || '').trim(),
    issuedAt: String(payload.issuedAt || ''),
    issuer: String(payload.issuer || 'Universal CAD Master License Manager'),
    nonce: String(payload.nonce || ''),
  };
}

function stableDocument(payload, sealedIssuer) {
  const sealedDigest = crypto.createHash('sha256').update(JSON.stringify(sealedIssuer || {})).digest('hex');
  return Buffer.from(JSON.stringify({ payload: normalizePayload(payload), sealedDigest }), 'utf8');
}

function validatePayload(payload) {
  const p = normalizePayload(payload);
  const errors = [];
  if (!p.entitlementId) errors.push('entitlementId is required.');
  if (p.product !== PRODUCT_ID) errors.push('Product does not match.');
  if (!p.customerName) errors.push('Customer name is required.');
  if (!p.licenseHostId.startsWith('UCAD-HOST-')) errors.push('License Host ID is invalid.');
  if (!/^[a-f0-9]{64}$/.test(p.licenseHostKeyFingerprint)) errors.push('License Host key fingerprint is invalid.');
  if (!Number.isInteger(p.seats) || p.seats < 1 || p.seats > 100000) errors.push('Seats must be an integer from 1 to 100000.');
  if (!isIsoDate(p.validFrom) || !isIsoDate(p.validUntil)) errors.push('Validity dates must be YYYY-MM-DD.');
  if (isIsoDate(p.validFrom) && isIsoDate(p.validUntil) && p.validUntil < p.validFrom) errors.push('validUntil must not be before validFrom.');
  if (!p.editionName || !p.productDisplayName) errors.push('Edition name is required.');
  if (!p.features.length) errors.push('At least one feature must be enabled.');
  try { crypto.createPublicKey(p.delegatedPublicKeyPem); } catch { errors.push('Delegated public key is invalid.'); }
  if (!p.issuedAt || Number.isNaN(Date.parse(p.issuedAt))) errors.push('issuedAt is invalid.');
  if (p.nonce.length < 16) errors.push('nonce is invalid.');
  return errors;
}

function createSignedEntitlement(payload, sealedIssuer, masterPrivateKeyPem) {
  const shaped = normalizePayload(payload);
  const errors = validatePayload(shaped);
  if (errors.length) throw new Error(errors.join(' '));
  const signature = crypto.sign(null, stableDocument(shaped, sealedIssuer), masterPrivateKeyPem).toString('base64');
  return { schema: ENTITLEMENT_SCHEMA, algorithm: ALGORITHM, payload: shaped, sealedIssuer, signature };
}

function verifyEntitlement(document, masterPublicKeyPem) {
  if (!document || document.schema !== ENTITLEMENT_SCHEMA || document.algorithm !== ALGORITHM) return { ok:false, code:'FORMAT', message:'Entitlement format is not supported.' };
  const errors = validatePayload(document.payload);
  if (errors.length) return { ok:false, code:'PAYLOAD', message:errors.join(' ') };
  let sig;
  try { sig = Buffer.from(String(document.signature || ''), 'base64'); } catch { return { ok:false, code:'SIGNATURE', message:'Entitlement signature is invalid.' }; }
  const ok = crypto.verify(null, stableDocument(document.payload, document.sealedIssuer), masterPublicKeyPem, sig);
  if (!ok) return { ok:false, code:'SIGNATURE', message:'Entitlement signature verification failed.' };
  return { ok:true, payload: normalizePayload(document.payload), document };
}

function entitlementDigest(document) {
  return crypto.createHash('sha256').update(JSON.stringify(document)).digest('hex');
}

function validateEnrollmentAgainstEntitlement(entitlement, enrollment) {
  if (normalizeHostId(entitlement.payload.licenseHostId) !== normalizeHostId(enrollment.hostId)) throw new Error('This entitlement belongs to a different License Host.');
  if (entitlement.payload.licenseHostKeyFingerprint !== fingerprintPublicKey(enrollment.publicKeyPem)) throw new Error('License Host public-key fingerprint does not match.');
  return true;
}

function serializeEntitlement(doc) { return `${JSON.stringify(doc, null, 2)}\n`; }
function parseEntitlementText(text) { return JSON.parse(String(text || '').trim()); }

module.exports = {
  ENTITLEMENT_SCHEMA,
  normalizePayload,
  validatePayload,
  createSignedEntitlement,
  verifyEntitlement,
  entitlementDigest,
  validateEnrollmentAgainstEntitlement,
  serializeEntitlement,
  parseEntitlementText,
};
