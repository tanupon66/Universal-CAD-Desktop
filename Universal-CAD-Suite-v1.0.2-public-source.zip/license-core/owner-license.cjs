'use strict';
const crypto = require('node:crypto');
const { PRODUCT_ID, todayLocal, isIsoDate } = require('./license-format.cjs');
const { SUITE_VERSION, ENGINE_VERSION, ALL_FEATURE_IDS } = require('./feature-catalog.cjs');

const OWNER_LICENSE_SCHEMA = 'ucad-owner-universal-license-v1';
const ALGORITHM = 'Ed25519';

function normalizePayload(payload) {
  return {
    schemaVersion: 1,
    licenseId: String(payload.licenseId || ''),
    product: String(payload.product || PRODUCT_ID),
    scope: 'owner-universal',
    ownerName: String(payload.ownerName || 'Owner').trim(),
    productDisplayName: String(payload.productDisplayName || 'Universal CAD Studio Owner').trim(),
    editionId: 'owner',
    editionName: String(payload.editionName || 'Owner Universal').trim(),
    features: [...ALL_FEATURE_IDS].sort(),
    validFrom: String(payload.validFrom || ''),
    validUntil: String(payload.validUntil || ''),
    suiteVersion: String(payload.suiteVersion || SUITE_VERSION),
    engineVersion: String(payload.engineVersion || ENGINE_VERSION),
    issuedAt: String(payload.issuedAt || ''),
    issuer: String(payload.issuer || 'Universal CAD Master License Manager'),
    nonce: String(payload.nonce || ''),
  };
}

function stablePayload(payload) { return Buffer.from(JSON.stringify(normalizePayload(payload)), 'utf8'); }
function validatePayload(payload) {
  const p = normalizePayload(payload); const errors = [];
  if (!p.licenseId) errors.push('licenseId is required.');
  if (p.product !== PRODUCT_ID) errors.push('Product does not match.');
  if (!isIsoDate(p.validFrom) || !isIsoDate(p.validUntil) || p.validUntil < p.validFrom) errors.push('Validity dates are invalid.');
  if (!p.issuedAt || Number.isNaN(Date.parse(p.issuedAt))) errors.push('issuedAt is invalid.');
  if (p.nonce.length < 16) errors.push('nonce is invalid.');
  return errors;
}
function createOwnerLicense(payload, masterPrivateKeyPem) {
  const p = normalizePayload(payload); const errors = validatePayload(p); if (errors.length) throw new Error(errors.join(' '));
  const signature = crypto.sign(null, stablePayload(p), masterPrivateKeyPem).toString('base64');
  return { schema: OWNER_LICENSE_SCHEMA, algorithm: ALGORITHM, payload: p, signature };
}
function verifyOwnerLicense(document, masterPublicKeyPem) {
  if (!document || document.schema !== OWNER_LICENSE_SCHEMA || document.algorithm !== ALGORITHM) return { ok:false, code:'FORMAT', message:'Owner license format is not supported.' };
  const errors = validatePayload(document.payload); if (errors.length) return { ok:false, code:'PAYLOAD', message:errors.join(' ') };
  let sig; try { sig = Buffer.from(String(document.signature || ''), 'base64'); } catch { return { ok:false, code:'SIGNATURE', message:'Owner license signature is invalid.' }; }
  if (!crypto.verify(null, stablePayload(document.payload), masterPublicKeyPem, sig)) return { ok:false, code:'SIGNATURE', message:'Owner license signature verification failed.' };
  return { ok:true, payload: normalizePayload(document.payload), document };
}
function evaluateOwnerLicense(document, masterPublicKeyPem, options={}) {
  const verified = verifyOwnerLicense(document, masterPublicKeyPem); if (!verified.ok) return verified;
  const now = options.now instanceof Date ? options.now : new Date(options.now || Date.now()); const today = todayLocal(now); const p = verified.payload;
  if (today < p.validFrom) return { ok:false, code:'NOT_YET_VALID', message:`Owner license starts on ${p.validFrom}.`, payload:p };
  if (today > p.validUntil) return { ok:false, code:'EXPIRED', message:`Owner license expired on ${p.validUntil}.`, payload:p };
  if (options.lastSeenUtcMs && Number.isFinite(Number(options.lastSeenUtcMs))) {
    const toleranceMs = Number(options.clockRollbackToleranceMs ?? 5 * 60 * 1000);
    if (now.getTime() + toleranceMs < Number(options.lastSeenUtcMs)) return { ok:false, code:'CLOCK_ROLLBACK', message:'System clock appears to have been moved backwards.', payload:p };
  }
  return { ok:true, code:'VALID', payload:{ ...p, customerName:p.ownerName, customerId:'OWNER', computerLabel:'Any machine', machineId:'ANY', seatNumber:'∞', seatCount:'∞' }, today };
}
function serializeOwnerLicense(doc) { return `${JSON.stringify(doc, null, 2)}\n`; }
module.exports = { OWNER_LICENSE_SCHEMA, createOwnerLicense, verifyOwnerLicense, evaluateOwnerLicense, serializeOwnerLicense };
