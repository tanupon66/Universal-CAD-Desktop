'use strict';

const crypto = require('node:crypto');

const MASTER_SCHEMA = 'ucad-master-key-v1';

function deriveKey(password, salt) {
  return crypto.scryptSync(String(password), salt, 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

function encryptPrivateKey(privateKeyPem, password) {
  if (String(password || '').length < 16) throw new Error('Master password must be at least 16 characters.');
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = deriveKey(password, salt);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(Buffer.from(privateKeyPem, 'utf8')), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    schema: MASTER_SCHEMA,
    kdf: 'scrypt-N32768-r8-p1',
    cipher: 'aes-256-gcm',
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    tag: tag.toString('base64'),
    ciphertext: ciphertext.toString('base64'),
  };
}

function decryptPrivateKey(document, password) {
  if (!document || document.schema !== MASTER_SCHEMA) throw new Error('Master key file is not supported.');
  const salt = Buffer.from(document.salt, 'base64');
  const iv = Buffer.from(document.iv, 'base64');
  const tag = Buffer.from(document.tag, 'base64');
  const ciphertext = Buffer.from(document.ciphertext, 'base64');
  const key = deriveKey(password, salt);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  try {
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
  } catch {
    throw new Error('Master password is incorrect or the master key file is damaged.');
  }
}

module.exports = { MASTER_SCHEMA, encryptPrivateKey, decryptPrivateKey };
