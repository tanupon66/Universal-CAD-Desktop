'use strict';
const $ = (id) => document.getElementById(id);
const machineId = $('machineId'), copyBtn = $('copyBtn'), activateBtn = $('activateBtn'), openBtn = $('openBtn');
const message = $('message'), details = $('details'), statusPill = $('statusPill'), appVersion = $('appVersion'), suiteLine = $('suiteLine');

function showMessage(text, success = false) { message.textContent = text; message.classList.remove('hidden','success'); if (success) message.classList.add('success'); }
function escapeHtml(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function renderStatus(status) {
  machineId.textContent = status.machineId || 'Unavailable';
  copyBtn.disabled = !status.machineId;
  activateBtn.disabled = !status.machineId;
  if (!status.ok) {
    statusPill.textContent = status.code === 'EXPIRED' ? 'Expired' : 'Not activated';
    statusPill.classList.remove('valid'); details.classList.add('hidden'); openBtn.classList.add('hidden'); return;
  }
  const p = status.payload;
  statusPill.textContent = 'Active'; statusPill.classList.add('valid');
  details.innerHTML = `<b>Customer</b><span>${escapeHtml(p.customerName || p.ownerName || 'Owner')}</span><b>Edition</b><span>${escapeHtml(p.productDisplayName || p.editionName || 'Licensed')}</span><b>Seat</b><span>${escapeHtml(p.seatNumber || 1)} / ${escapeHtml(p.seatCount || 1)}</span><b>Computer</b><span>${escapeHtml(p.computerLabel || p.machineId || 'Any')}</span><b>License ID</b><span>${escapeHtml(p.licenseId)}</span><b>Validity</b><span>${escapeHtml(p.validFrom)} — ${escapeHtml(p.validUntil)}</span><b>Version</b><span>Suite ${escapeHtml(p.suiteVersion || '1.0.2')} · Engine ${escapeHtml(p.engineVersion || '0.26.0')}</span>`;
  details.classList.remove('hidden'); openBtn.classList.remove('hidden');
}
function withTimeout(promise, ms) { return Promise.race([promise, new Promise((_,reject)=>setTimeout(()=>reject(new Error('Hardware ID initialization timed out.')),ms))]); }

copyBtn.addEventListener('click', async () => { await window.desktopLicense.copyMachineId(); copyBtn.textContent='Copied'; setTimeout(()=>copyBtn.textContent='Copy',1200); });
activateBtn.addEventListener('click', async () => {
  message.classList.add('hidden'); activateBtn.disabled = true;
  try {
    const response = await window.desktopLicense.chooseAndActivate();
    if (response.canceled) return;
    if (response.error) { showMessage(response.error.message); return; }
    renderStatus(response.result);
    showMessage(response.result.consumed ? 'License activated.' : `License activated. ${response.result.consumeWarning || ''}`, true);
    setTimeout(() => window.desktopLicense.openMainApp(), 350);
  } finally { activateBtn.disabled = false; }
});
openBtn.addEventListener('click', () => window.desktopLicense.openMainApp());

(async () => {
  try {
    const [status, info] = await withTimeout(Promise.all([window.desktopLicense.status(), window.desktopLicense.appInfo()]), 8000);
    renderStatus(status);
    appVersion.textContent = `${info.name} · Suite ${info.suiteVersion || info.version} · Engine ${info.engineVersion || '0.26.0'}`;
    suiteLine.textContent = `Suite ${info.suiteVersion || info.version} · Engine ${info.engineVersion || '0.26.0'}`;
    if (!status.ok && !['NO_LICENSE'].includes(status.code)) showMessage(status.message);
  } catch (error) {
    machineId.textContent = 'Hardware ID unavailable';
    statusPill.textContent = 'Initialization error';
    showMessage(`${error.message} Restart the application. If the issue continues, check Windows Management Instrumentation (WMI).`);
  }
})();
