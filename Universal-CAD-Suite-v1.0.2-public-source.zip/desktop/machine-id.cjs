'use strict';

const crypto = require('node:crypto');
const os = require('node:os');
const { execFileSync } = require('node:child_process');

const COMMAND_TIMEOUT_MS = 1200;

function tryCommand(command, args, timeout = COMMAND_TIMEOUT_MS) {
  try {
    return String(execFileSync(command, args, {
      windowsHide: true,
      encoding: 'utf8',
      timeout,
      maxBuffer: 256 * 1024,
      stdio: ['ignore', 'pipe', 'ignore'],
    }) || '').trim();
  } catch { return ''; }
}

function normalizeHardwareValue(value) {
  const text = String(value || '').trim().toUpperCase().replace(/\s+/g, ' ');
  if (!text) return '';
  const compact = text.replace(/[\s-]/g, '');
  const blocked = new Set([
    'TOBEFILLEDBYOEM', 'DEFAULTSTRING', 'SYSTEMSERIALNUMBER', 'NONE', 'UNKNOWN',
    'NOTSPECIFIED', 'NOTAPPLICABLE', '0000000000000000', '00000000000000000000000000000000',
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF',
  ]);
  if (blocked.has(compact)) return '';
  return text;
}

function isLikelyVirtualInterface(name) {
  return /(virtual|vmware|hyper-v|vethernet|loopback|bluetooth|tunnel|tap|vpn|docker|wsl)/i.test(String(name || ''));
}

function nativeNetworkFacts() {
  const physical = [];
  const all = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const item of list || []) {
      if (!item || item.internal || !item.mac || item.mac === '00:00:00:00:00:00') continue;
      const mac = String(item.mac).toLowerCase();
      all.push(mac);
      if (!isLikelyVirtualInterface(name)) physical.push(mac);
    }
  }
  return [...new Set((physical.length ? physical : all).sort())];
}

function windowsMachineGuid() {
  const out = tryCommand('reg.exe', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'], 700);
  const match = out.match(/MachineGuid\s+REG_\w+\s+([^\r\n]+)/i);
  return match ? normalizeHardwareValue(match[1]) : '';
}

function powershellJson(script, timeout = COMMAND_TIMEOUT_MS) {
  const out = tryCommand('powershell.exe', [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
    `$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='SilentlyContinue'; ${script} | ConvertTo-Json -Compress`,
  ], timeout);
  if (!out) return {};
  try { return JSON.parse(out); } catch { return {}; }
}

function windowsHardwareFacts() {
  // Compatibility probe only. Device identity no longer depends on this succeeding.
  const facts = powershellJson(`
    $csp = Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue;
    $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1;
    $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue | Select-Object -First 1;
    $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1;
    [PSCustomObject]@{ systemUuid=$csp.UUID; baseboardSerial=$bb.SerialNumber; biosSerial=$bios.SerialNumber; processorId=$cpu.ProcessorId }
  `, 1200);
  return {
    systemUuid: normalizeHardwareValue(facts.systemUuid),
    baseboardSerial: normalizeHardwareValue(facts.baseboardSerial),
    biosSerial: normalizeHardwareValue(facts.biosSerial),
    processorId: normalizeHardwareValue(facts.processorId),
  };
}

function fallbackFacts() {
  return {
    hostname: normalizeHardwareValue(os.hostname()),
    arch: normalizeHardwareValue(os.arch()),
    platform: normalizeHardwareValue(os.platform()),
    macs: nativeNetworkFacts(),
  };
}

function machineSeedFromFacts(facts, machineGuid = '') {
  const stable = [
    ['UUID', normalizeHardwareValue(facts?.systemUuid)],
    ['BOARD', normalizeHardwareValue(facts?.baseboardSerial)],
    ['BIOS', normalizeHardwareValue(facts?.biosSerial)],
    ['CPU', normalizeHardwareValue(facts?.processorId)],
  ].filter(([, value]) => value);
  if (stable.length >= 2) return `win-hwv2|${stable.map(([k, v]) => `${k}:${v}`).join('|')}`;
  if (stable.length === 1) {
    const guid = normalizeHardwareValue(machineGuid);
    if (guid) return `win-hwv2-fallback|${stable[0][0]}:${stable[0][1]}|GUID:${guid}`;
    return `win-hwv2-single|${stable[0][0]}:${stable[0][1]}`;
  }
  return '';
}

function fastMachineSeed({ macs = [], machineGuid = '', hostname = '', arch = '', platform = '' } = {}) {
  // MAC addresses are available natively from Node and survive Windows reinstall on the same NIC.
  // MachineGuid is secondary because Windows recreates it on reinstall.
  const cleanMacs = [...new Set((macs || []).map(x => String(x).toLowerCase()).filter(Boolean))].sort();
  if (cleanMacs.length) return `win-device-v3|MAC:${cleanMacs.join(',')}|ARCH:${normalizeHardwareValue(arch)}`;
  const guid = normalizeHardwareValue(machineGuid);
  if (guid) return `win-device-v3-guid|GUID:${guid}|ARCH:${normalizeHardwareValue(arch)}`;
  return `device-v3-fallback|${normalizeHardwareValue(platform)}|${normalizeHardwareValue(arch)}|${normalizeHardwareValue(hostname) || 'LOCAL'}`;
}

function legacySeedFromSnapshot(snapshot) {
  const guid = normalizeHardwareValue(snapshot?.machineGuid);
  const uuid = normalizeHardwareValue(snapshot?.facts?.systemUuid);
  return `win|${guid}|${uuid}`;
}

function formatMachineIdFromSeed(seed) {
  const hash = crypto.createHash('sha256').update(String(seed || 'universal-cad-device')).digest('hex').toUpperCase();
  const body = hash.slice(0, 24).match(/.{1,4}/g).join('-');
  return `UCAD-${body}`;
}

function collectMachineIdentity() {
  const startedAt = Date.now();
  const fallback = fallbackFacts();
  if (process.platform !== 'win32') {
    const seed = fastMachineSeed({ ...fallback, machineGuid:'' });
    const id = formatMachineIdFromSeed(seed);
    return { machineId:id, legacyMachineId:id, previousMachineId:id, source:'native', facts:{}, machineGuid:'', fallback, elapsedMs:Date.now()-startedAt };
  }

  const machineGuid = windowsMachineGuid();
  const fastSeed = fastMachineSeed({ ...fallback, machineGuid });
  const fastId = formatMachineIdFromSeed(fastSeed);

  // One short compatibility probe preserves v1.0.1 IDs when WMI works quickly.
  const facts = windowsHardwareFacts();
  const previousSeed = machineSeedFromFacts(facts, machineGuid);
  const previousMachineId = previousSeed ? formatMachineIdFromSeed(previousSeed) : fastId;
  const legacyMachineId = formatMachineIdFromSeed(legacySeedFromSnapshot({ facts, machineGuid }));

  return {
    // Prefer the prior v1.0.1 hardware ID when it is available quickly; otherwise use the native fast ID.
    machineId: previousSeed ? previousMachineId : fastId,
    previousMachineId,
    fallbackMachineId: fastId,
    legacyMachineId,
    source: previousSeed ? 'hardware-compatible' : (fallback.macs.length ? 'network-native' : (machineGuid ? 'windows-guid' : 'local-fallback')),
    facts,
    machineGuid,
    fallback,
    elapsedMs: Date.now() - startedAt,
  };
}

function machineSeed() { return collectMachineIdentity().machineId; }
function legacyWindowsSeed() { const s=collectMachineIdentity(); return legacySeedFromSnapshot(s); }
function computeMachineId() { return collectMachineIdentity().machineId; }
function computeLegacyMachineId() { return collectMachineIdentity().legacyMachineId; }

module.exports = {
  COMMAND_TIMEOUT_MS,
  computeMachineId,
  machineSeed,
  fastMachineSeed,
  machineSeedFromFacts,
  formatMachineIdFromSeed,
  windowsHardwareFacts,
  normalizeHardwareValue,
  computeLegacyMachineId,
  legacyWindowsSeed,
  legacySeedFromSnapshot,
  collectMachineIdentity,
  nativeNetworkFacts,
};
