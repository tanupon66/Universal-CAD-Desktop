'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const { installFeatureGate } = require('./feature-gate.cjs');
contextBridge.exposeInMainWorld('desktopLicense', {
  status: () => ipcRenderer.invoke('license:status'),
  chooseAndActivate: () => ipcRenderer.invoke('license:choose-and-activate'),
  copyMachineId: () => ipcRenderer.invoke('license:copy-machine-id'),
  openMainApp: () => ipcRenderer.invoke('license:open-main-app'),
  appInfo: () => ipcRenderer.invoke('app:info'),
});
contextBridge.exposeInMainWorld('UCAD_DESKTOP', Object.freeze({ enabled:true, suiteVersion:'1.0.2', engineVersion:'0.26.0' }));
installFeatureGate(ipcRenderer);
