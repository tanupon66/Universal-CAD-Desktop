# Universal CAD Suite v1.0.1

**Engine: Universal CAD Studio PWA v0.26.0**

Universal CAD Suite v1.0.1 เป็นรุ่น Desktop/Commercial Licensing รุ่นแรก โดยแยกเลขเวอร์ชันผลิตภัณฑ์ออกจาก Engine ชัดเจน:

- Product Suite: `1.0.1`
- CAD/NPI Engine: `0.26.0`

## โปรแกรม 3 ตัว

1. **Universal CAD Studio** — โปรแกรมใช้งานจริงของลูกค้า
2. **Universal CAD Customer License Tool** — ลูกค้าใช้จัดสรร Seats ภายในบริษัทแบบ Offline
3. **Universal CAD Master License Manager** — อยู่กับเจ้าของผลิตภัณฑ์เท่านั้น ใช้ออก Entitlement, Edition, Features, จำนวน Seats และ Owner Universal License

## Offline multi-seat licensing

ตัวอย่างลูกค้าซื้อ 10 Pro Seats:

1. ลูกค้าเปิด Customer License Tool และส่ง Enrollment Code ให้ผู้ขายครั้งเดียว
2. Master License Manager ออก `.ucadent` ระบุ 10 Seats, Edition, Features และวันหมดอายุ
3. ลูกค้า Import `.ucadent` ที่ License Host
4. ลูกค้ากรอก Machine ID ของ Studio แต่ละเครื่องและสร้าง `.ucadlic` เองได้สูงสุด 10 เครื่อง
5. การออก `.ucadlic` ให้ Machine ID เดิมซ้ำไม่กิน Seat เพิ่ม
6. เครื่องที่ 11 จะออก License ไม่ได้

ลูกค้าไม่ได้รับ Master signing key หรือ Master Password ของเจ้าของผลิตภัณฑ์

## Edition และ Feature Control

มี preset เริ่มต้น:

- Standard
- Pro
- Enterprise
- Custom

Master License Manager สามารถเปิด/ปิด Feature รายตัวได้ใน **ทุก Edition** และกำหนดชื่อที่แสดงใน Studio ได้ เช่น `Universal CAD Studio Pro - Factory A`.

เมื่อ Studio Activate แล้ว ชื่อโปรแกรมและฟังก์ชันที่มองเห็น/ใช้งานได้จะอ้างตาม License ที่เซ็นไว้

## รองรับลง Windows ใหม่

Suite v1.0.1 ใช้ Hardware-stable Machine ID จาก System UUID, Baseboard Serial, BIOS Serial และ Processor ID โดย **ไม่ใช้ Windows MachineGuid เป็นส่วนหลัก** ดังนั้นการลง Windows ใหม่บนฮาร์ดแวร์เดิมจะได้ Machine ID เดิมในเครื่อง Windows ปกติที่อ่าน Hardware ID ได้

หลังลง Windows ใหม่:

- Studio: เปิดโปรแกรมแล้ว Machine ID จะเดิม จาก Customer License Tool สามารถออก `.ucadlic` ให้ Machine ID เดิมซ้ำได้โดยไม่กิน Seat เพิ่ม
- Customer License Host: ใช้ `Export Recovery Backup (.ucadhost)` ก่อนลง Windows ใหม่ แล้ว `Restore Recovery Backup` หลังติดตั้งใหม่ เพื่อกู้ delegated signing key และ Seat ledger
- Recovery Backup ถูกเข้ารหัส AES-256-GCM ด้วย Recovery Password และปฏิเสธการ Restore บน License Host คนละเครื่อง

กรณีฮาร์ดแวร์หลัก เช่น motherboard ถูกเปลี่ยน Machine ID อาจเปลี่ยนและถือเป็นเครื่องใหม่ตามนโยบาย licensing

## Owner Universal License

Master License Manager สามารถสร้าง **Owner Universal License (`.ucadlic`)** สำหรับเจ้าของผลิตภัณฑ์:

- ใช้ได้ทุกเครื่อง
- เปิดทุก Feature
- ไม่จำกัด Seats
- กำหนดวันเริ่ม/หมดอายุได้
- เซ็นด้วย Master signing key เดิม

นี่เป็น Universal License ไม่ใช่การแจก raw Master private key ดังนั้น private signing key ยังไม่ออกจากเครื่องของเจ้าของผลิตภัณฑ์ ถ้าไฟล์ Owner Universal License หลุด ผู้ที่ได้ไฟล์สามารถใช้สิทธิ์ตามช่วงวันที่ของไฟล์นั้นได้ จึงควรเก็บเป็นความลับระดับเดียวกับ Master Key

## License compatibility

Suite v1.0.1 ยังคง product ID และ Ed25519 public verification key เดิมจาก Desktop v0.26/v0.27 และมี Legacy Machine-ID compatibility สำหรับ License รุ่นเดิมบน Windows installation เดิม

License ใหม่ของ Suite v1.0.1 ใช้ entitlement chain + delegated License Host key และ Hardware-stable Machine ID

## Validation

- Existing license-core cryptography: PASS
- Offline entitlement chain: PASS
- Windows reinstall Machine-ID simulation: PASS
- Customer License Host encrypted recovery: PASS
- Owner Universal License any-machine/all-feature verification: PASS
- Public-package secret audit: PASS
- PWA typecheck: 102 modules PASS
- Security lint policy: PASS
- Engine regression: 53/53 PASS
- Production build + verifier: PASS (45 precache assets)

## Offline security limitation

ระบบนี้ทำงาน Offline 100% ตามข้อกำหนด จึงไม่มี server กลางตรวจ global state การ Restore disk image/VM snapshot ก่อนการใช้ Seat เป็นข้อจำกัดเชิงหลักการของระบบ Offline ทั้งหมด ระบบนี้ลดความเสี่ยงด้วย Host-bound delegated key, encrypted ledger, Recovery Backup และ cryptographic signature แต่ไม่สามารถรับประกัน global one-time state แบบ server-backed ได้ 100%
