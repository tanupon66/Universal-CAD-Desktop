# Repository bootstrap — Universal CAD Suite v1.0.1

Target repository: `tanupon66/Universal-CAD-Desktop`

Recommended visibility: **Private**

Suite release tag: `suite-v1.0.1`
Engine: `0.26.0`

GitHub Actions must run the complete validation gate and build three Windows x64 NSIS installers:

1. Universal CAD Studio
2. Universal CAD Customer License Tool
3. Universal CAD Master License Manager

Administrator signing secrets are never stored in GitHub.
