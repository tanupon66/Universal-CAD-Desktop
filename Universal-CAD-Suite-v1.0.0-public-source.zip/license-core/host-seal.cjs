'use strict';
const crypto = require('node:crypto');

const HOST_ENROLLMENT_SCHEMA = 'ucad-host-enrollment-v1';
const HOST_SEAL_SCHEMA = 'ucad-host-seal-v1';

function b64url(buffer) { return Buffer.from(buffer).toString('base64url'); }
function fromB64url(text) { return Buffer.from(String(text || ''), 'base64url'); }
function fingerprintPublicKey(publicKeyPem) {
  return crypto.createHash('sha256').update(String(publicKeyPem || '').trim()).digest('hex');
}
function normalizeHostId(value) { return String(value || '').trim().toUpperCase().replace(/\s+/g, ''); }

function createEnrollmentCode({ hostId, publicKeyPem }) {
  const payload = {
    schema: HOST_ENROLLMENT_SCHEMA,
    hostId: normalizeHostId(hostId),
    publicKeyPem: String(publicKeyPem || '').trim(),
    fingerprint: fingerprintPublicKey(publicKeyPem),
  };
  if (!payload.hostId.startsWith('UCAD-HOST-')) throw new Error('License Host ID is invalid.');
  crypto.createPublicKey(payload.publicKeyPem);
  return b64url(Buffer.from(JSON.stringify(payload), 'utf8'));
}

function parseEnrollmentCode(code) {
  let payload;
  try { payload = JSON.parse(fromB64url(code).toString('utf8')); }
  catch { throw new Error('Enrollment Code is invalid.'); }
  if (!payload || payload.schema !== HOST_ENROLLMENT_SCHEMA) throw new Error('Enrollment Code format is not supported.');
  payload.hostId = normalizeHostId(payload.hostId);
  if (!payload.hostId.startsWith('UCAD-HOST-')) throw new Error('License Host ID is invalid.');
  crypto.createPublicKey(payload.publicKeyPem);
  const fp = fingerprintPublicKey(payload.publicKeyPem);
  if (payload.fingerprint !== fp) throw new Error('Enrollment Code fingerprint mismatch.');
  return payload;
}

function deriveSealKey(sharedSecret, salt) {
  return crypto.hkdfSync('sha256', sharedSecret, salt, Buffer.from('Universal CAD delegated issuer v1', 'utf8'), 32);
}

function sealForHost(plaintext, hostPublicKeyPem) {
  const recipient = crypto.createPublicKey(hostPublicKeyPem);
  const { publicKey, privateKey } = crypto.generateKeyPairSync('x25519');
  const secret = crypto.diffieHellman({ privateKey, publicKey: recipient });
  const salt = crypto.randomBytes(16);
  const key = deriveSealKey(secret, salt);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(Buffer.from(String(plaintext), 'utf8')), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    schema: HOST_SEAL_SCHEMA,
    ephemeralPublicKeyPem: publicKey.export({ type: 'spki', format: 'pem' }),
    salt: b64url(salt), iv: b64url(iv), tag: b64url(tag), ciphertext: b64url(ciphertext),
  };
}

function unsealForHost(sealed, hostPrivateKeyPem) {
  if (!sealed || sealed.schema !== HOST_SEAL_SCHEMA) throw new Error('Sealed issuer format is not supported.');
  const privateKey = crypto.createPrivateKey(hostPrivateKeyPem);
  const ephemeral = crypto.createPublicKey(sealed.ephemeralPublicKeyPem);
  const secret = crypto.diffieHellman({ privateKey, publicKey: ephemeral });
  const salt = fromB64url(sealed.salt);
  const key = deriveSealKey(secret, salt);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, fromB64url(sealed.iv));
  decipher.setAuthTag(fromB64url(sealed.tag));
  const plain = Buffer.concat([decipher.update(fromB64url(sealed.ciphertext)), decipher.final()]);
  return plain.toString('utf8');
}

module.exports = {
  HOST_ENROLLMENT_SCHEMA,
  HOST_SEAL_SCHEMA,
  fingerprintPublicKey,
  normalizeHostId,
  createEnrollmentCode,
  parseEnrollmentCode,
  sealForHost,
  unsealForHost,
};
