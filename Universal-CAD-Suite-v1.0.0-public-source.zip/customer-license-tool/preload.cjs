'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('customerLicenseApi',{
  hostInfo:()=>ipcRenderer.invoke('customer:host-info'),
  copyEnrollment:()=>ipcRenderer.invoke('customer:copy-enrollment'),
  list:()=>ipcRenderer.invoke('customer:list'),
  importEntitlement:()=>ipcRenderer.invoke('customer:import-entitlement'),
  issue:(input)=>ipcRenderer.invoke('customer:issue',input),
  exportRecovery:(input)=>ipcRenderer.invoke('customer:export-recovery',input),
  importRecovery:(input)=>ipcRenderer.invoke('customer:import-recovery',input),
  appInfo:()=>ipcRenderer.invoke('customer:info'),
});
