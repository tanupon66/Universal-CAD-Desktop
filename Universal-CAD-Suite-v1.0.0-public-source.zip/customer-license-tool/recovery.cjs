'use strict';
const crypto = require('node:crypto');

const RECOVERY_SCHEMA = 'ucad-license-host-recovery-v1';

function deriveKey(password, salt) {
  const pass = String(password || '');
  if (pass.length < 10) throw new Error('Recovery Password ต้องยาวอย่างน้อย 10 ตัวอักษร');
  return crypto.scryptSync(pass, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

function createRecoveryBundle({ hostRecord, ledger, password }) {
  if (!hostRecord?.hostId || !hostRecord?.privateKeyPem || !hostRecord?.publicKeyPem) throw new Error('License Host identity ไม่สมบูรณ์');
  const payload = {
    schema: 'ucad-license-host-recovery-payload-v1',
    hostId: String(hostRecord.hostId),
    hostRecord,
    ledger,
    exportedAt: new Date().toISOString(),
  };
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = deriveKey(password, salt);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(Buffer.from(JSON.stringify(payload), 'utf8')), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    schema: RECOVERY_SCHEMA,
    kdf: 'scrypt-N32768-r8-p1',
    cipher: 'AES-256-GCM',
    hostId: payload.hostId,
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    tag: tag.toString('base64'),
    ciphertext: ciphertext.toString('base64'),
  };
}

function openRecoveryBundle(document, password) {
  if (!document || document.schema !== RECOVERY_SCHEMA) throw new Error('Recovery Backup format ไม่รองรับ');
  const salt = Buffer.from(String(document.salt || ''), 'base64');
  const key = deriveKey(password, salt);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(String(document.iv || ''), 'base64'));
  decipher.setAuthTag(Buffer.from(String(document.tag || ''), 'base64'));
  let payload;
  try {
    payload = JSON.parse(Buffer.concat([
      decipher.update(Buffer.from(String(document.ciphertext || ''), 'base64')),
      decipher.final(),
    ]).toString('utf8'));
  } catch {
    throw new Error('Recovery Password ไม่ถูกต้อง หรือไฟล์ Backup เสียหาย');
  }
  if (!payload || payload.schema !== 'ucad-license-host-recovery-payload-v1') throw new Error('Recovery payload ไม่รองรับ');
  if (String(payload.hostId) !== String(document.hostId)) throw new Error('Recovery host binding ไม่ถูกต้อง');
  return payload;
}

module.exports = { RECOVERY_SCHEMA, createRecoveryBundle, openRecoveryBundle };
