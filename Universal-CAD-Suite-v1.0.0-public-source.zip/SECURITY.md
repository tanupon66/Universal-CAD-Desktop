# Universal CAD Suite v1.0.0 — Security

The repository/installers must never contain:

- Master Password
- Ed25519 private Master signing key
- encrypted Master Key document
- generated Owner Universal `.ucadlic`
- customer `.ucadent`, `.ucadlic`, or `.ucadhost` recovery files

## Trust boundaries

- **Master License Manager**: owner-only. Imports the encrypted Master Key locally into Electron `userData`; requires Master Password when signing.
- **Customer License Tool**: customer-side. Receives only a Master-signed entitlement and a delegated private signing key sealed cryptographically to that License Host. It cannot alter Seats, Edition, Features, customer, or validity signed by the Master.
- **Universal CAD Studio**: contains only the public Master verification key and accepts a valid chain of signatures.

## Owner Universal License

Owner Universal License is an intentionally powerful Master-signed `.ucadlic` usable on any machine with all features. It is safer than distributing the raw private key, but if the license file itself leaks it grants its signed rights until expiry. Store it as a high-value secret.

## Offline limitation

100% offline licensing cannot provide an absolute global consumed-seat ledger against full disk/VM snapshot rollback. The suite uses host-bound delegated keys, encrypted local seat ledger, hardware-bound machine licenses, and encrypted host recovery to make ordinary copying/tampering ineffective, but global one-time state requires a trusted online/hardware authority.
