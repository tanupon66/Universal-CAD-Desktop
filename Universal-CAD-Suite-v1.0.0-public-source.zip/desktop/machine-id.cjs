'use strict';

const crypto = require('node:crypto');
const os = require('node:os');
const { execFileSync } = require('node:child_process');

function tryCommand(command, args) {
  try {
    return String(execFileSync(command, args, {
      windowsHide: true,
      encoding: 'utf8',
      timeout: 5000,
      stdio: ['ignore', 'pipe', 'ignore'],
    }) || '').trim();
  } catch { return ''; }
}

function normalizeHardwareValue(value) {
  const text = String(value || '').trim().toUpperCase().replace(/\s+/g, ' ');
  if (!text) return '';
  const compact = text.replace(/[\s-]/g, '');
  const blocked = new Set([
    'TOBEFILLEDBYOEM', 'DEFAULTSTRING', 'SYSTEMSERIALNUMBER', 'NONE', 'UNKNOWN',
    'NOTSPECIFIED', 'NOTAPPLICABLE', '0000000000000000', '00000000000000000000000000000000',
    'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF',
  ]);
  if (blocked.has(compact)) return '';
  return text;
}

function powershellJson(script) {
  const out = tryCommand('powershell.exe', [
    '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
    `$ErrorActionPreference='SilentlyContinue'; ${script} | ConvertTo-Json -Compress`,
  ]);
  if (!out) return {};
  try { return JSON.parse(out); } catch { return {}; }
}

function windowsHardwareFacts() {
  const facts = powershellJson(`
    $csp = Get-CimInstance Win32_ComputerSystemProduct;
    $bb  = Get-CimInstance Win32_BaseBoard | Select-Object -First 1;
    $bios = Get-CimInstance Win32_BIOS | Select-Object -First 1;
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1;
    [PSCustomObject]@{
      systemUuid = $csp.UUID;
      baseboardSerial = $bb.SerialNumber;
      biosSerial = $bios.SerialNumber;
      processorId = $cpu.ProcessorId
    }
  `);
  return {
    systemUuid: normalizeHardwareValue(facts.systemUuid),
    baseboardSerial: normalizeHardwareValue(facts.baseboardSerial),
    biosSerial: normalizeHardwareValue(facts.biosSerial),
    processorId: normalizeHardwareValue(facts.processorId),
  };
}

function windowsMachineGuid() {
  const out = tryCommand('reg.exe', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid']);
  const match = out.match(/MachineGuid\s+REG_\w+\s+([^\r\n]+)/i);
  return match ? normalizeHardwareValue(match[1]) : '';
}

function fallbackFacts() {
  const macs = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const item of list || []) {
      if (item && !item.internal && item.mac && item.mac !== '00:00:00:00:00:00') macs.push(item.mac.toLowerCase());
    }
  }
  return {
    hostname: normalizeHardwareValue(os.hostname()),
    arch: normalizeHardwareValue(os.arch()),
    platform: normalizeHardwareValue(os.platform()),
    macs: macs.sort(),
  };
}

function machineSeedFromFacts(facts, machineGuid = '') {
  const stable = [
    ['UUID', normalizeHardwareValue(facts?.systemUuid)],
    ['BOARD', normalizeHardwareValue(facts?.baseboardSerial)],
    ['BIOS', normalizeHardwareValue(facts?.biosSerial)],
    ['CPU', normalizeHardwareValue(facts?.processorId)],
  ].filter(([, value]) => value);

  // Windows reinstall changes MachineGuid, so it is deliberately excluded whenever
  // at least two hardware-bound identifiers are available.
  if (stable.length >= 2) return `win-hwv2|${stable.map(([k, v]) => `${k}:${v}`).join('|')}`;
  if (stable.length === 1) {
    const guid = normalizeHardwareValue(machineGuid);
    return `win-hwv2-fallback|${stable[0][0]}:${stable[0][1]}|GUID:${guid}`;
  }
  return `win-guid-fallback|GUID:${normalizeHardwareValue(machineGuid)}`;
}

function legacyWindowsSeed() {
  const guid = windowsMachineGuid();
  const facts = windowsHardwareFacts();
  const bios = normalizeHardwareValue(facts.systemUuid);
  return `win|${guid}|${bios}`;
}

function computeLegacyMachineId() {
  if (process.platform === 'win32') return formatMachineIdFromSeed(legacyWindowsSeed());
  return computeMachineId();
}

function machineSeed() {
  if (process.platform === 'win32') {
    const facts = windowsHardwareFacts();
    return machineSeedFromFacts(facts, windowsMachineGuid());
  }
  const f = fallbackFacts();
  return `fallback|${f.platform}|${f.arch}|${f.hostname}|${f.macs.join(',')}`;
}

function formatMachineIdFromSeed(seed) {
  const hash = crypto.createHash('sha256').update(String(seed)).digest('hex').toUpperCase();
  const body = hash.slice(0, 24).match(/.{1,4}/g).join('-');
  return `UCAD-${body}`;
}

function computeMachineId() { return formatMachineIdFromSeed(machineSeed()); }

module.exports = {
  computeMachineId,
  machineSeed,
  machineSeedFromFacts,
  formatMachineIdFromSeed,
  windowsHardwareFacts,
  normalizeHardwareValue,
  computeLegacyMachineId,
  legacyWindowsSeed,
};
