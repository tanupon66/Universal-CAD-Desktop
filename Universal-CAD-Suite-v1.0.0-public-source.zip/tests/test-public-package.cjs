'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');
const ROOT = path.join(__dirname, '..');
const forbiddenNames = [/UCAD_MASTER_PASSWORD/i, /master-key\.enc\.json$/i, /private-key\.pem$/i, /owner-universal.*\.ucadlic$/i];
function walk(dir) {
  const out=[];
  for (const entry of fs.readdirSync(dir,{withFileTypes:true})) {
    if (['node_modules','release','.git'].includes(entry.name)) continue;
    const p=path.join(dir,entry.name);
    if (entry.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
}
for (const file of walk(ROOT)) {
  const rel=path.relative(ROOT,file).replace(/\\/g,'/');
  for (const re of forbiddenNames) assert.ok(!re.test(rel), `forbidden secret/material present: ${rel}`);
}
for (const rel of ['electron-builder.customer.yml','electron-builder.customer-tool.yml','electron-builder.master-manager.yml']) {
  const cfg=fs.readFileSync(path.join(ROOT,rel),'utf8');
  assert.match(cfg,/directories:\s*[\r\n]+\s*app:\s*\./,`${rel} must package from suite root`);
  assert.ok(!cfg.includes('master-key.enc.json'),`${rel} must not bundle imported Master Key`);
}
const studioBuilder=fs.readFileSync(path.join(ROOT,'electron-builder.customer.yml'),'utf8');
assert.ok(studioBuilder.includes('app/*.js'),'Studio builder must include all PWA runtime JavaScript modules');
assert.ok(studioBuilder.includes('license-core/*.cjs'),'Studio must contain public verification logic');
const master=fs.readFileSync(path.join(ROOT,'master-license-manager/main.cjs'),'utf8');
assert.ok(master.includes("app.getPath('userData')"),'Master Manager must store imported key in local userData');
assert.ok(master.includes('master:import-key'),'Master Manager must support explicit local key import');
assert.ok(master.includes('master:generate-owner'),'Master Manager must support Owner Universal license issuance');
const customer=fs.readFileSync(path.join(ROOT,'customer-license-tool/main.cjs'),'utf8');
assert.ok(customer.includes('customer:export-recovery') && customer.includes('customer:import-recovery'),'Customer Tool must support offline host recovery');
const publicKey=fs.readFileSync(path.join(ROOT,'desktop/public-key.pem'),'utf8');
assert.match(publicKey,/BEGIN PUBLIC KEY/);
console.log('public-package security tests: PASS');
